# HR Onboarding & Offboarding Automation System
### TechCorp Solutions — Smart Employee Lifecycle Management (v2.0.0)

A full-stack HR automation system with:
- **FastAPI** backend with 8 REST API routers
- **React + Vite + Tailwind** frontend dashboard (9 pages)
- **SQLite** database (auto-created, auto-seeded)
- **Groq LLM** chatbot with RAG (policy retrieval) + CAG (live employee context)
- **Role-based access provisioning** (6 roles, automatic system access)
- **Approval workflow** for high-privilege roles
- **Asset tracking** (laptops, ID cards)
- **Full audit trail** for every action
- **Email simulation** (stored in DB, no real SMTP needed)
- **Active Directory simulation** (no Windows DC needed)
- **Phase 3 — Offboarding Engine** (AD cleanup, access revocation, role-specific exit checklists)
- **Phase 4 — Smart Features** (LLM Chatbot, RAG, CAG, auto-RBAC, auto-assets, search)

---

## Project Structure

```
hr_onboarding/
├── backend/
│   ├── main.py                  ← FastAPI app entry point
│   ├── database.py              ← SQLite connection
│   ├── models.py                ← All 9 DB table models
│   ├── seed.py                  ← Auto-seeds dummy data on startup
│   ├── requirements.txt
│   ├── .env                     ← Environment variables
│   ├── engines/
│   │   ├── onboarding.py        ← Core onboarding pipeline
│   │   ├── ad_simulator.py      ← Simulated Active Directory
│   │   ├── email_simulator.py   ← Simulated email sending
│   │   ├── rbac.py              ← Role-based access control
│   │   └── chatbot.py           ← LLM chatbot + intent parser
│   ├── routers/
│   │   ├── employees.py         ← GET /api/employees/
│   │   ├── onboard.py           ← POST /api/onboard/
│   │   ├── approvals.py         ← GET/PATCH /api/approvals/
│   │   ├── logs.py              ← GET /api/logs/
│   │   ├── chatbot.py           ← POST /api/chat/
│   │   ├── assets.py            ← GET /api/assets/
│   │   └── roles.py             ← GET /api/roles/
│   └── rag/
│       └── rag_engine.py        ← RAG (FAISS) + CAG context builder
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx              ← Router + layout
│   │   ├── api.js               ← All Axios API calls
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx    ← Stats + charts
│   │   │   ├── Employees.jsx    ← Search + detail drawer
│   │   │   ├── OnboardForm.jsx  ← Onboarding form
│   │   │   ├── Approvals.jsx    ← Approve/reject requests
│   │   │   ├── AuditLogs.jsx    ← Full audit trail
│   │   │   ├── Assets.jsx       ← Asset inventory
│   │   │   ├── Chatbot.jsx      ← AI assistant
│   │   │   └── EmailLogs.jsx    ← Simulated emails
│   │   └── components/
│   │       ├── Sidebar.jsx      ← Navigation
│   │       └── ui.jsx           ← Shared components
│   ├── package.json
│   └── vite.config.js
│
└── data/
    └── dummy_data.json          ← All seed data (roles, employees, assets, policies)
```

---

## How to Run

### Prerequisites
- Python 3.11+
- Node.js 18+
- pip

---

### Step 1 — Set up Backend

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate (Windows)
venv\Scripts\activate

# Activate (Mac/Linux)
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Copy env file
copy .env .env.local     # Windows
# cp .env .env.local     # Mac/Linux
```

---

### Step 2 — Configure .env

Open `backend/.env` and set:

```env
GROQ_API_KEY=your_groq_key_here    # Optional — get free at console.groq.com
DATABASE_URL=sqlite:///./hr_onboarding.db
COMPANY_NAME=TechCorp Solutions
COMPANY_DOMAIN=techcorp.com
LLM_MODEL=llama-3.3-70b-versatile
```

> **Note:** GROQ_API_KEY is optional. The chatbot works without it using a rule-based fallback.

---

### Step 3 — Start Backend

```bash
# From the backend/ folder with venv activated
uvicorn main:app --reload --port 8000
```

You should see:
```
✅ HR Onboarding System running at http://localhost:8000
📖 API docs: http://localhost:8000/docs
🌱 Seeding database with dummy data...
✅ Seeded 6 employees, 6 roles, 16 assets
```

---

### Step 4 — Set up and Start Frontend

Open a **new terminal window**:

```bash
cd frontend

# Install Node packages
npm install

# Start dev server
npm run dev
```

You should see:
```
  VITE v6.0.5  ready in 300ms
  ➜  Local:   http://localhost:5173/
```

---

### Step 5 — Open the App

Go to: **http://localhost:5173**

You'll see the dashboard with 6 pre-seeded employees, charts, and all features ready.

---

## Quick Test — Try These

### 1. Onboard an employee via Form
- Click **Onboard** in sidebar
- Fill: Name = "Priya Sharma", Department = "Engineering", Role = Developer
- Click **Onboard Employee**
- See the success screen with all provisioned systems

### 2. Test Approval Workflow
- Same form, but select Role = **Admin**
- An approval request is created instead
- Go to **Approvals** → click Approve
- Employee gets fully onboarded automatically

### 3. Test AI Chatbot
- Click **AI Assistant** in sidebar
- Type: `Onboard Rahul Gupta as developer in Engineering`
- The bot parses the command and onboards automatically
- Or ask: `What is the leave policy?`

### 4. Check Audit Trail
- Go to **Audit Logs** — every single action is logged
- Go to **Email Logs** — see the welcome email content
- Go to **Assets** — see laptop and ID card assignments

---

## API Documentation

Interactive docs available at: **http://localhost:8000/docs**

Key endpoints:
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/onboard/ | Onboard new employee |
| GET | /api/employees/ | List + search employees |
| GET | /api/employees/stats | Dashboard stats |
| GET | /api/employees/{id} | Full employee profile |
| GET | /api/approvals/ | List approval requests |
| PATCH | /api/approvals/{id} | Approve or reject |
| GET | /api/logs/audit | Audit trail |
| GET | /api/logs/emails | Email logs |
| POST | /api/chat/ | AI chatbot |
| GET | /api/assets/ | Asset inventory |
| GET | /api/roles/ | All roles + permissions |

---

## Roles & System Access

| Role | Level | Systems Provisioned |
|------|-------|---------------------|
| admin | High | AD, AWS, GitHub, Jira, HRMS, Slack, Email, VPN, Confluence |
| developer | Medium | GitHub, AWS, Jira, Slack, Email, VPN, Confluence |
| hr_manager | Medium | HRMS, Payroll, Slack, Email, Confluence, BambooHR |
| finance | Medium | SAP, Payroll, Slack, Email, QuickBooks |
| sales | Low | Salesforce, Slack, Email, Zoom, HubSpot |
| intern | Minimal | GitHub (read), Slack (read), Email |

> **Approval required for:** admin, finance, hr_manager

---

## AI Features

### Chatbot Commands (Examples)
```
"Onboard Rahul Sharma as developer in Engineering"
"Add Priya to HR team as hr_manager"
"Create intern account for Amit in Sales"
"What is the leave policy?"
"What access does a developer get?"
"What is the password policy?"
```

### RAG (Retrieval-Augmented Generation)
- 6 company policies embedded using `sentence-transformers`
- FAISS vector index for semantic search
- Top-3 relevant policy chunks injected into LLM context
- Answers policy questions accurately

### CAG (Cache-Augmented Generation)
- Live employee list injected into every LLM request
- Last 25 audit log actions included as context
- LLM can answer: "How many engineers do we have?" in real-time

---

## Troubleshooting

**Backend won't start:**
```bash
# Make sure venv is activated
venv\Scripts\activate   # Windows
# Then retry: uvicorn main:app --reload --port 8000
```

**Frontend shows blank:**
```bash
# Make sure backend is running first on port 8000
# Check browser console for errors
# Make sure npm install completed successfully
```

**Chatbot not working:**
- Without GROQ_API_KEY: rule-based fallback still handles onboarding commands
- With GROQ_API_KEY: full LLM responses with policy Q&A

**Port already in use:**
```bash
# Backend on different port:
uvicorn main:app --reload --port 8001
# Then update frontend/vite.config.js proxy target to :8001
```

**sentence-transformers slow first run:**
- Model downloads ~90MB on first chatbot use
- Subsequent runs use cached model
- RAG gracefully disabled if install fails

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.11+, FastAPI, Uvicorn |
| ORM | SQLAlchemy 2.0 |
| Database | SQLite (dev) / PostgreSQL (prod) |
| Validation | Pydantic v2 |
| Frontend | React 18, Vite 6, Tailwind CSS 3 |
| Charts | Recharts |
| Icons | Lucide React |
| HTTP | Axios |
| LLM | Groq API (llama-3.3-70b-versatile) |
| RAG | sentence-transformers + FAISS |
| Logging | Loguru |
| Toasts | react-hot-toast |

---

## Coming Next — Offboarding Module

Phase 2 will add:
- Disable AD account (6 cleanup steps)
- Revoke all system access
- Asset return tracking
- Role-specific exit checklist
- Offboard email simulation
- Full audit trail

---

*HR Onboarding System v1.0 — TechCorp Solutions*
