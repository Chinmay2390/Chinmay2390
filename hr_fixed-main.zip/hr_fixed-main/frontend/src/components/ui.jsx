// StatusBadge
export function StatusBadge({ status }) {
  const map = {
    active:           'badge-active',
    pending_approval: 'badge-pending',
    disabled:         'badge-disabled',
  }
  const labels = {
    active:           'Active',
    pending_approval: 'Pending Approval',
    disabled:         'Disabled',
  }
  return <span className={map[status] || 'badge-pending'}>{labels[status] || status}</span>
}

// RoleBadge
export function RoleBadge({ role }) {
  const map = {
    admin:      'badge-admin',
    developer:  'badge-developer',
    hr_manager: 'badge-hr',
    finance:    'badge-finance',
    sales:      'badge-sales',
    intern:     'badge-intern',
  }
  return (
    <span className={map[role] || 'badge-intern'}>
      {(role || 'N/A').replace('_', ' ')}
    </span>
  )
}

// SystemBadge (access level)
export function SystemBadge({ system, level }) {
  const levelColor = {
    admin:        'bg-red-100 text-red-700',
    full_control: 'bg-purple-100 text-purple-700',
    write:        'bg-blue-100 text-blue-700',
    read:         'bg-slate-100 text-slate-600',
    developer:    'bg-teal-100 text-teal-700',
    standard:     'bg-gray-100 text-gray-600',
  }
  return (
    <div className="flex items-center justify-between px-3 py-1.5 bg-slate-50 rounded-lg border border-slate-100">
      <span className="text-sm text-slate-700 font-medium">{system}</span>
      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${levelColor[level] || 'bg-slate-100 text-slate-600'}`}>
        {level}
      </span>
    </div>
  )
}

// PageHeader
export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="flex items-start justify-between mb-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
        {subtitle && <p className="text-slate-500 text-sm mt-1">{subtitle}</p>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  )
}

// StatCard
export function StatCard({ label, value, icon: Icon, color = 'blue', sub }) {
  const colors = {
    blue:   { bg: 'bg-blue-50',    text: 'text-blue-600',   icon: 'text-blue-500' },
    green:  { bg: 'bg-emerald-50', text: 'text-emerald-600',icon: 'text-emerald-500' },
    amber:  { bg: 'bg-amber-50',   text: 'text-amber-600',  icon: 'text-amber-500' },
    purple: { bg: 'bg-purple-50',  text: 'text-purple-600', icon: 'text-purple-500' },
    slate:  { bg: 'bg-slate-50',   text: 'text-slate-600',  icon: 'text-slate-500' },
  }
  const c = colors[color] || colors.blue
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-slate-500 text-sm font-medium">{label}</p>
          <p className={`text-3xl font-bold mt-1 ${c.text}`}>{value}</p>
          {sub && <p className="text-slate-400 text-xs mt-1">{sub}</p>}
        </div>
        {Icon && (
          <div className={`${c.bg} p-3 rounded-xl`}>
            <Icon size={22} className={c.icon} />
          </div>
        )}
      </div>
    </div>
  )
}

// LoadingSpinner
export function LoadingSpinner({ text = 'Loading...' }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3">
      <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      <p className="text-slate-500 text-sm">{text}</p>
    </div>
  )
}

// EmptyState
export function EmptyState({ icon: Icon, title, subtitle }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3 text-center">
      {Icon && <Icon size={40} className="text-slate-300" />}
      <p className="font-medium text-slate-500">{title}</p>
      {subtitle && <p className="text-slate-400 text-sm">{subtitle}</p>}
    </div>
  )
}

// ActionLogRow
export function ActionLogRow({ action, system, status, details, time, performed_by }) {
  const statusClass = status === 'success'
    ? 'bg-emerald-100 text-emerald-700'
    : status === 'pending'
    ? 'bg-amber-100 text-amber-700'
    : 'bg-red-100 text-red-700'

  return (
    <div className="flex items-start gap-3 py-3 border-b border-slate-50 last:border-0">
      <div className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${
        status === 'success' ? 'bg-emerald-400' :
        status === 'pending' ? 'bg-amber-400' : 'bg-red-400'
      }`} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-mono text-xs font-semibold text-slate-700">{action}</span>
          <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${statusClass}`}>{status}</span>
          <span className="text-xs text-slate-400">{system}</span>
        </div>
        {details && <p className="text-xs text-slate-500 mt-0.5 truncate">{details}</p>}
      </div>
      <div className="text-right flex-shrink-0">
        {time && <p className="text-xs text-slate-400">{new Date(time).toLocaleTimeString()}</p>}
        {performed_by && <p className="text-xs text-slate-300">{performed_by}</p>}
      </div>
    </div>
  )
}
