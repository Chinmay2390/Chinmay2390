import { NavLink } from 'react-router-dom'
import { useEffect, useState } from 'react'
import {
  LayoutDashboard, Users, UserPlus, UserX, GitBranch, CheckSquare,
  ClipboardList, Monitor, MessageSquare, Mail, Cloud, Wifi, WifiOff,
  Shield, Archive, RefreshCw
} from 'lucide-react'
import axios from 'axios'

const nav = [
  { to: '/dashboard', icon: LayoutDashboard, label: 'Dashboard',      section: 'OVERVIEW' },
  { to: '/employees', icon: Users,           label: 'Employees',      section: 'WORKFORCE' },
  { to: '/onboard',   icon: UserPlus,        label: 'Joiner',         section: 'WORKFORCE' },
  { to: '/mover',     icon: GitBranch,       label: 'Mover',          section: 'WORKFORCE' },
  { to: '/offboard',  icon: UserX,           label: 'Leaver (Active)',section: 'WORKFORCE' },
  { to: '/leaver',    icon: Archive,         label: 'Offboarded',     section: 'WORKFORCE' },
  { to: '/approvals', icon: CheckSquare,     label: 'Approvals',      section: 'WORKFLOW' },
  { to: '/azure',     icon: Cloud,           label: 'Azure AD',       section: 'INTEGRATIONS' },
  { to: '/assets',    icon: Monitor,         label: 'Assets',         section: 'INTEGRATIONS' },
  { to: '/logs',      icon: ClipboardList,   label: 'Audit Logs',     section: 'COMPLIANCE' },
  { to: '/emails',    icon: Mail,            label: 'Email Logs',     section: 'COMPLIANCE' },
  { to: '/chatbot',   icon: MessageSquare,   label: 'AI Assistant',   section: 'AI' },
]

export default function Sidebar() {
  const [online, setOnline]       = useState(false)
  const [azureMode, setAzureMode] = useState('SIM')
  const [syncing, setSyncing]     = useState(false)

  const checkStatus = () => {
    axios.get('http://localhost:8000/health').then(() => setOnline(true)).catch(() => setOnline(false))
    axios.get('http://localhost:8000/api/azure/status').then(r => {
      setAzureMode(r.data.use_real_graph ? 'REAL' : 'SIM')
    }).catch(() => {})
  }

  useEffect(() => { checkStatus() }, [])

  const doSync = async () => {
    setSyncing(true)
    try {
      await axios.post('http://localhost:8000/api/sync-azure')
      window.location.reload()
    } catch { } finally { setSyncing(false) }
  }

  const sections = [...new Set(nav.map(n => n.section))]

  return (
    <aside className="w-56 flex-shrink-0 bg-slate-900 flex flex-col h-screen">
      <div className="px-4 py-5 border-b border-slate-700">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <Shield size={16} className="text-white" />
          </div>
          <div>
            <p className="text-white font-bold text-sm leading-none">JML Platform</p>
            <p className="text-slate-400 text-xs mt-0.5">Enterprise IAM</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 px-3">
        {sections.map(section => (
          <div key={section} className="mb-4">
            <p className="text-slate-500 text-xs font-semibold px-2 mb-1.5">{section}</p>
            {nav.filter(n => n.section === section).map(({ to, icon: Icon, label }) => (
              <NavLink key={to} to={to}
                className={({ isActive }) =>
                  `flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm mb-0.5 transition-all ${
                    isActive ? 'bg-blue-600 text-white font-medium' : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`
                }>
                <Icon size={15} />
                {label}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div className="px-4 py-3 border-t border-slate-700 space-y-2">
        <div className="flex items-center gap-2">
          {online ? <Wifi size={12} className="text-green-400" /> : <WifiOff size={12} className="text-red-400" />}
          <span className="text-xs text-slate-400">{online ? 'Backend connected' : 'Backend offline'}</span>
        </div>
        <div className="flex items-center gap-2">
          <Cloud size={12} className={azureMode === 'REAL' ? 'text-green-400' : 'text-amber-400'} />
          <span className="text-xs text-slate-400">Azure: {azureMode === 'REAL' ? '🔴 Real' : '🟡 Sim'}</span>
        </div>
        {azureMode === 'REAL' && (
          <button onClick={doSync} disabled={syncing}
            className="w-full flex items-center gap-1.5 text-xs text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 px-2 py-1.5 rounded-lg transition-all">
            <RefreshCw size={11} className={syncing ? 'animate-spin' : ''} />
            {syncing ? 'Syncing…' : 'Sync Azure AD'}
          </button>
        )}
        <p className="text-slate-600 text-xs">v3.1 · JML Enterprise</p>
      </div>
    </aside>
  )
}
