import { useState, useEffect } from 'react'
import { getEmployees, transferEmployee, getMoverHistory } from '../api'
import toast from 'react-hot-toast'
import { GitBranch, Loader2, CheckCircle2, ChevronDown, ArrowRight, History } from 'lucide-react'

const ROLES = ['developer','admin','hr_manager','finance','sales','intern']
const DEPTS = ['Engineering','IT-Admin','HR','Finance','Sales','Operations','Cybersecurity','Marketing','Legal','Internship']

export default function Mover() {
  const [employees, setEmployees] = useState([])
  const [selected, setSelected]   = useState(null)
  const [form, setForm]           = useState({ to_department:'Engineering', to_role:'developer', to_manager:'', effective_date:'', reason:'Internal transfer' })
  const [loading, setLoading]     = useState(false)
  const [result, setResult]       = useState(null)
  const [history, setHistory]     = useState([])
  const [tab, setTab]             = useState('form')
  const f = (k,v) => setForm(p => ({...p,[k]:v}))

  useEffect(() => {
    getEmployees({}).then(r => setEmployees((r.data||[]).filter(e => e.status === 'active')))
    getMoverHistory().then(r => setHistory(r.data?.events || []))
  }, [])

  const handleSubmit = async () => {
    if (!selected) return toast.error('Select an employee')
    setLoading(true)
    try {
      const r = await transferEmployee({ employee_id: selected.id, ...form })
      setResult(r.data)
      toast.success(`${selected.name} transferred ✅`)
      setTab('result')
      getMoverHistory().then(r => setHistory(r.data?.events || []))
    } catch(e) {
      toast.error(e.response?.data?.detail || e.response?.data?.message || 'Transfer failed')
    } finally { setLoading(false) }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
          <GitBranch size={18} className="text-purple-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-900">Department Transfer (Mover)</h1>
          <p className="text-sm text-slate-500">Azure AD groups · Teams · SharePoint access auto-updated</p>
        </div>
        <div className="ml-auto flex gap-2">
          {['form','history'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`text-sm px-4 py-2 rounded-xl transition-all ${tab === t ? 'bg-purple-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
              {t === 'form' ? '✏️ Transfer' : <span className="flex items-center gap-1"><History size={13}/>History</span>}
            </button>
          ))}
        </div>
      </div>

      {tab === 'form' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h2 className="font-semibold text-slate-800">Transfer Details</h2>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Employee *</label>
              <div className="relative">
                <select className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-purple-400"
                  value={selected?.id||''} onChange={e => setSelected(employees.find(em=>em.id===parseInt(e.target.value))||null)}>
                  <option value="">— Select active employee —</option>
                  {employees.map(e=><option key={e.id} value={e.id}>{e.name} — {e.department} / {e.role}</option>)}
                </select>
                <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </div>

            {selected && (
              <div className="bg-slate-50 rounded-xl p-3 text-sm flex items-center gap-4">
                <div><p className="text-xs text-slate-400">Current Department</p><p className="font-semibold text-slate-700">{selected.department}</p></div>
                <ArrowRight size={16} className="text-slate-400" />
                <div><p className="text-xs text-slate-400">Current Role</p><p className="font-semibold text-slate-700">{selected.role}</p></div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              {[['to_department','New Department',DEPTS],['to_role','New Role',ROLES]].map(([key,label,opts])=>(
                <div key={key}>
                  <label className="block text-sm font-medium text-slate-700 mb-1">{label} *</label>
                  <div className="relative">
                    <select value={form[key]} onChange={e=>f(key,e.target.value)}
                      className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-purple-400">
                      {opts.map(o=><option key={o}>{o}</option>)}
                    </select>
                    <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              ))}
            </div>

            {[['to_manager','New Manager','Manager name (optional)'],['effective_date','Effective Date',''],['reason','Reason','Internal transfer / promotion']].map(([key,label,ph])=>(
              <div key={key}>
                <label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>
                <input type={key==='effective_date'?'date':'text'} value={form[key]} onChange={e=>f(key,e.target.value)} placeholder={ph}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400" />
              </div>
            ))}

            <button onClick={handleSubmit} disabled={loading||!selected}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2 disabled:opacity-50 transition-all">
              {loading ? <Loader2 size={16} className="animate-spin" /> : <GitBranch size={16} />}
              {loading ? 'Transferring…' : 'Transfer Employee'}
            </button>
          </div>

          {/* Right: result or steps info */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            {result ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2 mb-4">
                  <CheckCircle2 size={18} className="text-green-500" />
                  <span className="font-semibold text-slate-800">Transfer Complete</span>
                </div>
                {(result.steps||[]).map((s,i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-xl text-sm ${s.status==='success'?'bg-green-50':'bg-red-50'}`}>
                    <span>{s.status==='success'?'✅':'❌'}</span>
                    <div>
                      <p className="font-medium text-slate-700">{s.step?.replace(/_/g,' ')}</p>
                      {s.details && <p className="text-xs text-slate-500 mt-0.5">{s.details}</p>}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-3">
                <h3 className="font-semibold text-slate-800 mb-4">What happens on transfer</h3>
                {['Azure AD department & job title updated','Removed from old dept Azure AD group','Added to new dept group (LAB Engineering Group)','Teams channel membership updated','SharePoint access adjusted','Audit log created','Email notification sent to employee & manager'].map((s,i)=>(
                  <div key={i} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl text-sm text-slate-600">
                    <span className="w-5 h-5 bg-purple-100 text-purple-600 rounded-full text-xs flex items-center justify-center font-bold">{i+1}</span>
                    {s}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {tab === 'history' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100">
            <span className="font-semibold text-slate-800">Transfer History ({history.length})</span>
          </div>
          {history.length === 0 ? (
            <div className="text-center py-16 text-slate-400">
              <History size={36} className="mx-auto mb-3 opacity-30" />
              <p>No transfers recorded yet</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead><tr className="bg-slate-50 border-b border-slate-100">
                {['Employee','From','To','Effective','Reason','Status'].map(h=>(
                  <th key={h} className="text-left px-4 py-3 font-medium text-slate-500">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {history.map((h,i)=>(
                  <tr key={i} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="px-4 py-3 font-medium text-slate-800">{h.employee_name||h.employee_id}</td>
                    <td className="px-4 py-3 text-slate-500">{h.from_department} / {h.from_role}</td>
                    <td className="px-4 py-3 text-slate-700">{h.to_department} / {h.to_role}</td>
                    <td className="px-4 py-3 text-slate-500">{h.effective_date||'—'}</td>
                    <td className="px-4 py-3 text-slate-500">{h.reason}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${h.status==='completed'?'bg-green-100 text-green-700':'bg-amber-100 text-amber-700'}`}>
                        {h.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}
    </div>
  )
}
