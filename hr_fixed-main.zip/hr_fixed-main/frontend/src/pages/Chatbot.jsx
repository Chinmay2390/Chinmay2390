import { useState, useRef, useEffect } from 'react'
import { Send, Bot, User, Zap, Loader, ChevronDown } from 'lucide-react'
import { sendChat } from '../api'
import { PageHeader } from '../components/ui'

const EXAMPLES = [
  "Onboard Priya Sharma as developer in Engineering",
  "Add Rahul Gupta to HR team as hr_manager",
  "Offboard Alice Johnson — resignation, last day 2026-05-15",
  "Transfer Bob Williams to Finance as finance",
  "What is the leave policy?",
  "What systems does a developer get access to?",
  "Create intern account for Amit in Sales",
  "What is the password policy?",
]

function Bubble({ msg }) {
  const isBot = msg.role === 'assistant'
  const lines  = (msg.text || '').split('\n')
  return (
    <div className={`flex gap-2.5 ${isBot ? '' : 'flex-row-reverse'}`}>
      <div className={`w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center text-white text-xs font-bold ${isBot ? 'bg-blue-600' : 'bg-slate-700'}`}>
        {isBot ? <Bot size={14}/> : <User size={14}/>}
      </div>
      <div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm ${isBot ? 'bg-white border border-slate-100 shadow-sm text-slate-800' : 'bg-blue-600 text-white'}`}>
        {lines.map((line, i) => {
          // Bold markdown **text**
          const parts = line.split(/(\*\*[^*]+\*\*)/g)
          return (
            <p key={i} className={i > 0 ? 'mt-1' : ''}>
              {parts.map((p, j) =>
                p.startsWith('**') ? <strong key={j}>{p.slice(2,-2)}</strong> : p
              )}
            </p>
          )
        })}
        {msg.action && (
          <div className={`mt-2 pt-2 border-t ${isBot ? 'border-slate-100' : 'border-blue-500'}`}>
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
              msg.action === 'onboard'  ? 'bg-green-100 text-green-700' :
              msg.action === 'offboard' ? 'bg-red-100 text-red-700' :
              msg.action === 'mover'    ? 'bg-purple-100 text-purple-700' :
              'bg-blue-100 text-blue-700'
            }`}>⚡ {msg.action}</span>
            {msg.success !== undefined && (
              <span className={`ml-2 text-xs ${msg.success ? 'text-green-600' : 'text-red-600'}`}>
                {msg.success ? '✅ Done' : '❌ Failed'}
              </span>
            )}
          </div>
        )}
        <p className={`text-xs mt-1.5 ${isBot ? 'text-slate-400' : 'text-blue-200'}`}>
          {msg.time?.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' })}
        </p>
      </div>
    </div>
  )
}

export default function Chatbot() {
  const WELCOME = "👋 Hi! I'm your HR AI Assistant.\n\nI can **onboard**, **offboard**, and **transfer** employees from natural language commands, or answer HR policy questions.\n\nTry:\n• \"Onboard Priya Sharma as developer in Engineering\"\n• \"Offboard Alice Johnson — resignation, last day 2026-05-15\"\n• \"Transfer Bob to Finance as finance\""
  const [messages, setMessages] = useState([{ role: 'assistant', text: WELCOME, time: new Date() }])
  const [input, setInput]   = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef(null)

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior:'smooth' }) }, [messages])

  const send = async (msg) => {
    const text = (msg || input).trim()
    if (!text || loading) return
    setInput('')
    const userMsg = { role:'user', text, time: new Date() }
    setMessages(p => [...p, userMsg])
    setLoading(true)
    try {
      const history = messages.slice(-6).map(m => ({ role: m.role, content: m.text }))
      const res  = await sendChat(text, history)
      const d    = res.data
      let reply  = d.reply || 'No response.'
      let action = null, success = null

      if (d.executed && d.execution_result) {
        const r = d.execution_result
        success = r.status === 'success'
        action  = d.action_type || 'action'
        if (success) {
          const name = r.employee_name || r.name || ''
          if (action === 'onboard') reply += `\n\n✅ **${name}** has been onboarded successfully.`
          else if (action === 'offboard') reply += `\n\n✅ **${name}** has been offboarded. AD steps: ${r.ad_steps_completed || 0}, M365 steps: ${r.m365_steps_completed || 0}.`
          else if (action === 'mover') reply += `\n\n✅ **${name}** transferred to ${r.to_department || '?'} as ${r.to_role || '?'}.`
        } else {
          reply += `\n\n❌ Action failed: ${r.error || r.message || 'Unknown error'}`
        }
      }
      setMessages(p => [...p, { role:'assistant', text: reply, time: new Date(), action, success }])
    } catch(e) {
      setMessages(p => [...p, { role:'assistant', text:'❌ Sorry, I could not connect to the backend. Please ensure the server is running.', time: new Date() }])
    } finally { setLoading(false) }
  }

  return (
    <div className="flex gap-6 h-[calc(100vh-5rem)]">
      {/* Main chat */}
      <div className="flex-1 flex flex-col bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-3">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center">
            <Bot size={16} className="text-white"/>
          </div>
          <div>
            <p className="font-semibold text-slate-900">AI Assistant</p>
            <p className="text-xs text-slate-500">Natural language HR commands + policy Q&A</p>
          </div>
          <span className="ml-auto flex items-center gap-1.5 text-xs bg-green-100 text-green-700 px-2.5 py-1 rounded-full font-medium">
            <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
            Online
          </span>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {messages.map((m,i) => <Bubble key={i} msg={m}/>)}
          {loading && (
            <div className="flex gap-2.5">
              <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                <Bot size={14} className="text-white"/>
              </div>
              <div className="bg-white border border-slate-100 rounded-2xl px-4 py-3">
                <Loader size={14} className="animate-spin text-slate-400"/>
              </div>
            </div>
          )}
          <div ref={bottomRef}/>
        </div>

        <div className="px-4 py-3 border-t border-slate-100">
          <div className="flex gap-2">
            <textarea
              className="flex-1 border border-slate-200 rounded-xl px-3 py-2.5 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-400"
              rows={2}
              placeholder="Type a message or command..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if(e.key==='Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
            />
            <button onClick={() => send()} disabled={loading||!input.trim()}
              className="w-10 h-10 bg-blue-600 hover:bg-blue-700 disabled:opacity-40 rounded-xl flex items-center justify-center text-white transition-all self-end">
              <Send size={15}/>
            </button>
          </div>
          <p className="text-xs text-slate-400 mt-1.5 px-1">Press Enter to send · Shift+Enter for new line</p>
        </div>
      </div>

      {/* Sidebar */}
      <div className="w-64 flex-shrink-0 space-y-4">
        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3 flex items-center gap-1.5">
            <Zap size={12}/> Try these
          </p>
          <div className="space-y-1.5">
            {EXAMPLES.map((ex,i) => (
              <button key={i} onClick={() => send(ex)}
                className="w-full text-left text-xs text-slate-600 hover:text-blue-700 hover:bg-blue-50 px-3 py-2 rounded-lg transition-all">
                "{ex}"
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-4">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">How it works</p>
          <div className="space-y-2">
            {[
              ['🧠','Powered by Groq Llama 3.3'],
              ['📋','Reads live employee data'],
              ['⚡','Auto-provisions on command'],
              ['🚫','Triggers real offboarding'],
              ['🔄','Handles transfers (Mover)'],
              ['📜','Answers from company policies'],
            ].map(([icon,text],i) => (
              <div key={i} className="flex items-start gap-2 text-xs text-slate-600">
                <span>{icon}</span><span>{text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
