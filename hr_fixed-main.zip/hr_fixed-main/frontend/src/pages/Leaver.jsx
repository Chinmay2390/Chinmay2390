import { useState, useEffect } from 'react'
import { getLeavers, getLeaverChecklist, completeLeaverItem, deleteFromAzure } from '../api'
import toast from 'react-hot-toast'
import {
  Archive, CheckCircle2, Circle, AlertTriangle, ChevronDown,
  Loader2, Trash2, ClipboardCheck, RefreshCw, UserX, Shield
} from 'lucide-react'

const CATEGORY_ICONS = {
  'Code & Repos':'💻','Access':'🔐','Assets':'📦','Data':'🗂️',
  'Communication':'💬','HR Data':'📋','Finance':'💰','CRM':'🤝',
  'Admin':'⚙️','Security':'🛡️','Compliance':'📜','Sign-off':'✅',
}

export default function Leaver() {
  const [leavers, setLeavers]       = useState([])
  const [selected, setSelected]     = useState(null)
  const [checklist, setChecklist]   = useState(null)
  const [loading, setLoading]       = useState(true)
  const [clLoading, setClLoading]   = useState(false)
  const [deleting, setDeleting]     = useState(false)
  const [tab, setTab]               = useState('list')

  const load = () => {
    setLoading(true)
    getLeavers().then(r => setLeavers(r.data)).catch(() => toast.error('Could not load leavers'))
      .finally(() => setLoading(false))
  }
  useEffect(() => { load() }, [])

  const openChecklist = async (emp) => {
    setSelected(emp)
    setClLoading(true)
    setTab('checklist')
    try {
      const r = await getLeaverChecklist(emp.id)
      setChecklist(r.data)
    } catch { toast.error('Could not load checklist') }
    finally { setClLoading(false) }
  }

  const toggleItem = async (itemId) => {
    try {
      await completeLeaverItem(itemId, { completed_by: 'hr_staff' })
      setChecklist(prev => {
        const items = prev.items.map(i =>
          i.id === itemId ? { ...i, is_completed: true, completed_at: new Date().toISOString(), completed_by: 'hr_staff' } : i
        )
        const done = items.filter(i => i.is_completed).length
        return { ...prev, items, completed: done, progress_pct: Math.round(done / items.length * 100) }
      })
      toast.success('Marked complete ✓')
    } catch { toast.error('Failed to update') }
  }

  const handleDeleteFromAzure = async () => {
    if (!selected) return
    if (!window.confirm(`⚠️ This will permanently DELETE ${selected.name} from Azure AD. This cannot be undone. Confirm?`)) return
    setDeleting(true)
    try {
      const r = await deleteFromAzure(selected.id, { confirmed_by: 'hr_admin' })
      const d = r.data
      if (d.status === 'success') {
        const msg = d.hard_deleted
          ? `${selected.name} permanently deleted from Azure AD ✅`
          : d.soft_deleted
            ? `${selected.name} soft-deleted (will purge in 30 days) ✅`
            : `${selected.name} deleted from Azure AD ✅`
        toast.success(msg)
        load()
        setTab('list')
        setSelected(null)
      } else if (d.status === 'blocked') {
        toast.error(d.message)
      } else if (d.status === 'skipped') {
        toast.success(d.message)
        load(); setTab('list'); setSelected(null)
      } else {
        // Show specific error message — especially 403 permissions
        toast.error(d.message || d.error || 'Deletion failed — check backend logs')
      }
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Deletion failed')
    } finally { setDeleting(false) }
  }

  const grouped = checklist?.items?.reduce((acc, i) => {
    if (!acc[i.category]) acc[i.category] = []
    acc[i.category].push(i)
    return acc
  }, {}) || {}

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center">
            <Archive size={20} className="text-slate-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-slate-900">Offboarded Employees</h1>
            <p className="text-sm text-slate-500">Manage exit checklists · Archive mailbox · Delete from Azure AD</p>
          </div>
        </div>
        <div className="flex gap-2">
          {tab === 'checklist' && (
            <button onClick={() => { setTab('list'); setSelected(null); setChecklist(null) }}
              className="text-sm text-slate-600 border border-slate-200 rounded-xl px-4 py-2 hover:bg-slate-50">
              ← Back to list
            </button>
          )}
          <button onClick={load} className="flex items-center gap-1.5 text-sm text-slate-600 border border-slate-200 rounded-xl px-4 py-2 hover:bg-slate-50">
            <RefreshCw size={14} /> Refresh
          </button>
        </div>
      </div>

      {/* ── LIST TAB ── */}
      {tab === 'list' && (
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          {loading ? (
            <div className="flex justify-center py-20"><Loader2 className="animate-spin text-slate-400" /></div>
          ) : leavers.length === 0 ? (
            <div className="text-center py-20">
              <Archive size={40} className="mx-auto mb-3 text-slate-300" />
              <p className="text-slate-500 font-medium">No offboarded employees yet</p>
              <p className="text-sm text-slate-400 mt-1">Offboarded users will appear here</p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-medium text-slate-500">Employee</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Department</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Offboarded</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Checklist</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Assets</th>
                  <th className="text-right px-4 py-3 font-medium text-slate-500">Actions</th>
                </tr>
              </thead>
              <tbody>
                {leavers.map(e => (
                  <tr key={e.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center text-red-600 text-xs font-bold flex-shrink-0">
                          {(e.name||'?')[0]}
                        </div>
                        <div>
                          <p className="font-medium text-slate-800">{e.name}</p>
                          <p className="text-xs text-slate-400">{e.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{e.department}</td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {e.disabled_at ? new Date(e.disabled_at).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-1.5 bg-slate-100 rounded-full w-20">
                          <div className="h-full bg-green-400 rounded-full" style={{ width: `${e.checklist_pct}%` }} />
                        </div>
                        <span className="text-xs text-slate-500">{e.checklist_done}/{e.checklist_total}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {e.assets_pending > 0
                        ? <span className="text-xs bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full">{e.assets_pending} pending</span>
                        : <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Returned</span>}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => openChecklist(e)}
                        className="text-xs bg-blue-600 text-white px-3 py-1.5 rounded-lg hover:bg-blue-700 transition-all">
                        Manage →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* ── CHECKLIST TAB ── */}
      {tab === 'checklist' && selected && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: employee info + actions */}
          <div className="space-y-4">
            <div className="bg-white rounded-2xl border border-slate-100 p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600 text-lg font-bold">
                  {(selected.name||'?')[0]}
                </div>
                <div>
                  <p className="font-bold text-slate-900">{selected.name}</p>
                  <p className="text-sm text-slate-500">{selected.department}</p>
                  <p className="text-xs text-slate-400 font-mono">{selected.azure_upn}</p>
                </div>
              </div>
              <div className="text-xs space-y-1.5 text-slate-600">
                <div className="flex justify-between">
                  <span>Offboarded:</span>
                  <span className="font-medium">{selected.disabled_at ? new Date(selected.disabled_at).toLocaleDateString() : '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Checklist:</span>
                  <span className="font-medium">{selected.checklist_done}/{selected.checklist_total} ({selected.checklist_pct}%)</span>
                </div>
                <div className="flex justify-between">
                  <span>Assets pending:</span>
                  <span className={`font-medium ${selected.assets_pending > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                    {selected.assets_pending > 0 ? `${selected.assets_pending} pending` : 'All returned ✓'}
                  </span>
                </div>
              </div>
            </div>

            {/* Offboarding flow steps */}
            <div className="bg-white rounded-2xl border border-slate-100 p-5">
              <p className="font-semibold text-slate-800 text-sm mb-3">Offboarding Flow</p>
              <div className="space-y-2">
                {[
                  { label: 'Account Disabled',   done: true,                           icon: '🔒' },
                  { label: 'Sessions Revoked',    done: true,                           icon: '🚫' },
                  { label: 'Exit Checklist',      done: selected.checklist_pct === 100, icon: '📋' },
                  { label: 'Assets Recovered',    done: selected.assets_pending === 0,  icon: '📦' },
                  { label: 'Mailbox Archived',    done: false,                          icon: '📧' },
                  { label: 'Azure AD Deleted',    done: !selected.azure_object_id,      icon: '🗑️' },
                ].map(({ label, done, icon }) => (
                  <div key={label} className={`flex items-center gap-2 text-xs py-1.5 px-2.5 rounded-lg ${done ? 'bg-green-50 text-green-700' : 'bg-slate-50 text-slate-500'}`}>
                    <span>{icon}</span>
                    <span className="flex-1">{label}</span>
                    {done ? <CheckCircle2 size={13} /> : <Circle size={13} />}
                  </div>
                ))}
              </div>

              {/* Delete from Azure button */}
              {selected.azure_object_id && !selected.azure_object_id.startsWith('sim-') && (
                <button onClick={handleDeleteFromAzure} disabled={deleting || selected.assets_pending > 0}
                  className={`w-full mt-4 flex items-center justify-center gap-2 text-xs font-medium py-2.5 rounded-xl transition-all ${
                    selected.assets_pending > 0
                      ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      : 'bg-red-600 text-white hover:bg-red-700'
                  }`}>
                  {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
                  {selected.assets_pending > 0 ? 'Recover assets first' : 'Delete from Azure AD'}
                </button>
              )}
              {selected.assets_pending > 0 && (
                <p className="text-xs text-orange-600 mt-2 text-center">
                  ⚠️ Mark all assets returned before deleting from Azure
                </p>
              )}
            </div>
          </div>

          {/* Right: checklist */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
                <span className="font-semibold text-slate-800">Exit Checklist — {selected.name}</span>
                <div className="flex items-center gap-2">
                  <div className="w-24 h-1.5 bg-slate-100 rounded-full">
                    <div className="h-full bg-green-400 rounded-full transition-all"
                      style={{ width: `${checklist?.progress_pct || 0}%` }} />
                  </div>
                  <span className="text-xs text-slate-500">{checklist?.progress_pct || 0}%</span>
                </div>
              </div>

              {clLoading ? (
                <div className="flex justify-center py-16"><Loader2 className="animate-spin text-slate-400" /></div>
              ) : !checklist?.items?.length ? (
                <div className="text-center py-16">
                  <ClipboardCheck size={36} className="mx-auto mb-3 text-slate-300" />
                  <p className="text-slate-500">No checklist items found</p>
                  <p className="text-xs text-slate-400 mt-1">This user may have been offboarded before v3.1</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-50">
                  {Object.entries(grouped).map(([cat, items]) => (
                    <div key={cat}>
                      <div className="px-5 py-2.5 bg-slate-50/60">
                        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                          {CATEGORY_ICONS[cat] || '📌'} {cat}
                        </span>
                      </div>
                      {items.map(item => (
                        <div key={item.id}
                          className={`flex items-start gap-3 px-5 py-3 hover:bg-slate-50/60 transition-colors ${item.is_completed ? 'opacity-60' : ''}`}>
                          <button onClick={() => !item.is_completed && toggleItem(item.id)}
                            className={`mt-0.5 flex-shrink-0 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                              item.is_completed ? 'bg-green-500 border-green-500' : 'border-slate-300 hover:border-green-400'
                            }`}>
                            {item.is_completed && <CheckCircle2 size={12} className="text-white" />}
                          </button>
                          <div className="flex-1">
                            <p className={`text-sm ${item.is_completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                              {item.item}
                            </p>
                            {item.is_completed && (
                              <p className="text-xs text-slate-400 mt-0.5">
                                {item.auto ? '⚡ Auto-completed' : `✓ ${item.completed_by}`}
                                {item.completed_at && ` · ${new Date(item.completed_at).toLocaleString()}`}
                              </p>
                            )}
                          </div>
                          {!item.is_completed && (
                            <button onClick={() => toggleItem(item.id)}
                              className="text-xs text-blue-600 hover:underline whitespace-nowrap">
                              Mark done
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
