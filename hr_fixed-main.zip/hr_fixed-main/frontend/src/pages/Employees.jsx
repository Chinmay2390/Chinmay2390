import { useEffect, useState } from 'react'
import { Search, Users, ChevronDown, X, Shield, Monitor } from 'lucide-react'
import { getEmployees } from '../api'
import { StatusBadge, RoleBadge, SystemBadge, LoadingSpinner, EmptyState, PageHeader, ActionLogRow } from '../components/ui'
import { useNavigate } from 'react-router-dom'

const DEPARTMENTS = ['Engineering','HR','Finance','Sales','IT','Marketing','Legal','Operations']
const ROLES       = ['admin','developer','hr_manager','finance','sales','intern']
const STATUSES    = ['active','pending_approval']

export default function Employees() {
  const [employees, setEmployees] = useState([])
  const [loading, setLoading]     = useState(true)
  const [search, setSearch]       = useState('')
  const [dept, setDept]           = useState('')
  const [role, setRole]           = useState('')
  const [status, setStatus]       = useState('')
  const [selected, setSelected]   = useState(null)
  const navigate = useNavigate()

  const fetch = () => {
    setLoading(true)
    getEmployees({ search, department: dept, role, status })
      .then(r => setEmployees(r.data))
      .finally(() => setLoading(false))
  }

  useEffect(() => { fetch() }, [search, dept, role, status])

  return (
    <div className="fade-in space-y-5">
      <PageHeader title="Employees" subtitle={`${employees.length} employee${employees.length !== 1 ? 's' : ''} found`}>
        <button className="btn-primary" onClick={() => navigate('/onboard')}>+ Onboard New</button>
      </PageHeader>

      {/* Filters */}
      <div className="card p-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="relative md:col-span-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className="input pl-9" placeholder="Search name, email, ID..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="input" value={dept} onChange={e => setDept(e.target.value)}>
            <option value="">All Departments</option>
            {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <select className="input" value={role} onChange={e => setRole(e.target.value)}>
            <option value="">All Roles</option>
            {ROLES.map(r => <option key={r} value={r}>{r.replace('_',' ')}</option>)}
          </select>
          <select className="input" value={status} onChange={e => setStatus(e.target.value)}>
            <option value="">All Statuses</option>
            {STATUSES.map(s => <option key={s} value={s}>{s.replace('_',' ')}</option>)}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {loading ? (
          <LoadingSpinner />
        ) : employees.length === 0 ? (
          <EmptyState icon={Users} title="No employees found" subtitle="Try adjusting your search or filters" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/60">
                  <th className="text-left px-5 py-3.5 font-medium text-slate-500">Employee</th>
                  <th className="text-left px-4 py-3.5 font-medium text-slate-500">ID</th>
                  <th className="text-left px-4 py-3.5 font-medium text-slate-500">Department</th>
                  <th className="text-left px-4 py-3.5 font-medium text-slate-500">Role</th>
                  <th className="text-left px-4 py-3.5 font-medium text-slate-500">Location</th>
                  <th className="text-left px-4 py-3.5 font-medium text-slate-500">Status</th>
                  <th className="text-left px-4 py-3.5 font-medium text-slate-500">Joined</th>
                  <th className="px-4 py-3.5" />
                </tr>
              </thead>
              <tbody>
                {employees.map(emp => (
                  <tr key={emp.id}
                    className="border-b border-slate-50 hover:bg-blue-50/30 transition-colors cursor-pointer"
                    onClick={() => setSelected(emp)}>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center
                                        text-blue-700 text-xs font-bold flex-shrink-0">
                          {emp.name.split(' ').map(n => n[0]).join('').slice(0,2)}
                        </div>
                        <div>
                          <p className="font-medium text-slate-800">{emp.name}</p>
                          <p className="text-slate-400 text-xs">{emp.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 font-mono text-xs text-slate-500">{emp.employee_id}</td>
                    <td className="px-4 py-3.5 text-slate-600">{emp.department}</td>
                    <td className="px-4 py-3.5"><RoleBadge role={emp.role} /></td>
                    <td className="px-4 py-3.5 text-slate-500 text-xs">{emp.location}</td>
                    <td className="px-4 py-3.5"><StatusBadge status={emp.status} /></td>
                    <td className="px-4 py-3.5 text-slate-400 text-xs">
                      {emp.created_at ? new Date(emp.created_at).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-4 py-3.5">
                      <button className="text-blue-600 hover:underline text-xs font-medium"
                        onClick={e => { e.stopPropagation(); setSelected(emp) }}>View</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Detail drawer */}
      {selected && <EmployeeDrawer emp={selected} onClose={() => setSelected(null)} />}
    </div>
  )
}

function EmployeeDrawer({ emp, onClose }) {
  const [detail, setDetail] = useState(null)

  useEffect(() => {
    import('../api').then(({ getEmployee }) => {
      getEmployee(emp.id).then(r => setDetail(r.data))
    })
  }, [emp.id])

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg bg-white h-full shadow-2xl overflow-y-auto slide-in">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100 sticky top-0 bg-white z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center
                            text-blue-700 font-bold text-sm">
              {emp.name.split(' ').map(n => n[0]).join('').slice(0,2)}
            </div>
            <div>
              <p className="font-semibold text-slate-900">{emp.name}</p>
              <p className="text-xs text-slate-500">{emp.employee_id}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <X size={18} className="text-slate-500" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Info grid */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Email',      value: emp.email },
              { label: 'Department', value: emp.department },
              { label: 'Role',       value: emp.role?.replace('_',' ') },
              { label: 'Manager',    value: emp.manager },
              { label: 'Location',   value: emp.location },
              { label: 'Phone',      value: emp.phone },
              { label: 'AD User',    value: emp.ad_username },
              { label: 'Status',     value: emp.status },
            ].map(({ label, value }) => (
              <div key={label} className="bg-slate-50 rounded-lg p-3">
                <p className="text-xs text-slate-400 font-medium">{label}</p>
                <p className="text-sm text-slate-700 mt-0.5 truncate">{value || '—'}</p>
              </div>
            ))}
          </div>

          {/* System Access */}
          {detail?.access && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Shield size={15} className="text-blue-600" />
                <p className="font-semibold text-slate-800 text-sm">System Access ({detail.access.filter(a=>a.active).length} active)</p>
              </div>
              <div className="space-y-1.5">
                {detail.access.filter(a => a.active).map((a, i) => (
                  <SystemBadge key={i} system={a.system} level={a.level} />
                ))}
                {detail.access.filter(a=>a.active).length === 0 &&
                  <p className="text-slate-400 text-sm">No active access</p>}
              </div>
            </div>
          )}

          {/* Assets */}
          {detail?.assets && detail.assets.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Monitor size={15} className="text-purple-600" />
                <p className="font-semibold text-slate-800 text-sm">Assigned Assets</p>
              </div>
              <div className="space-y-1.5">
                {detail.assets.filter(a => a.active).map((a, i) => (
                  <div key={i} className="flex items-center justify-between px-3 py-2 bg-purple-50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-purple-900">{a.tag}</p>
                      <p className="text-xs text-purple-600">{a.type} — {a.model}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent logs */}
          {detail?.logs && detail.logs.length > 0 && (
            <div>
              <p className="font-semibold text-slate-800 text-sm mb-3">Recent Activity</p>
              {detail.logs.slice(0,6).map((l, i) => (
                <ActionLogRow key={i}
                  action={l.action} system={l.system}
                  status={l.status} details={null} time={l.time} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
