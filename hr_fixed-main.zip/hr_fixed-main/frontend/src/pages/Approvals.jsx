// src/pages/Approvals.jsx
import { useEffect, useState } from 'react'
import { CheckCircle, XCircle, Clock, RefreshCw } from 'lucide-react'
import toast from 'react-hot-toast'
import { getApprovals, actOnApproval } from '../api'
import { PageHeader, LoadingSpinner, EmptyState } from '../components/ui'

export default function Approvals() {
  const [approvals, setApprovals] = useState([])
  const [loading, setLoading]     = useState(true)
  const [acting, setActing]       = useState(null)

  const fetch = () => {
    setLoading(true)
    getApprovals().then(r => setApprovals(r.data)).finally(() => setLoading(false))
  }
  useEffect(() => { fetch() }, [])

  const act = async (id, action) => {
    setActing(id)
    try {
      const res = await actOnApproval(id, { action, approver: 'hr_director' })
      toast.success(`Request ${action} successfully`)
      fetch()
    } catch {
      toast.error('Action failed')
    } finally {
      setActing(null)
    }
  }

  const pending  = approvals.filter(a => a.status === 'pending')
  const resolved = approvals.filter(a => a.status !== 'pending')

  return (
    <div className="fade-in space-y-5">
      <PageHeader title="Approval Requests" subtitle="Review and approve high-privilege onboarding requests">
        <button onClick={fetch} className="btn-secondary flex items-center gap-2">
          <RefreshCw size={14} /> Refresh
        </button>
      </PageHeader>

      {loading ? <LoadingSpinner /> : (
        <>
          {/* Pending */}
          <div className="card overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
              <Clock size={16} className="text-amber-500" />
              <h2 className="font-semibold text-slate-800">Pending ({pending.length})</h2>
            </div>
            {pending.length === 0 ? (
              <EmptyState icon={CheckCircle} title="No pending approvals" subtitle="All clear!" />
            ) : (
              <div className="divide-y divide-slate-50">
                {pending.map(a => (
                  <div key={a.id} className="flex items-center justify-between px-5 py-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-slate-800">{a.employee_name}</p>
                        <span className="text-xs font-mono text-slate-400">{a.employee_id}</span>
                      </div>
                      <p className="text-sm text-slate-500 mt-0.5">{a.reason}</p>
                      <p className="text-xs text-slate-400 mt-1">
                        Requested by {a.requested_by} · {new Date(a.created_at).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <button
                        disabled={acting === a.id}
                        onClick={() => act(a.id, 'rejected')}
                        className="btn-danger flex items-center gap-1.5 text-xs py-1.5">
                        <XCircle size={13} /> Reject
                      </button>
                      <button
                        disabled={acting === a.id}
                        onClick={() => act(a.id, 'approved')}
                        className="btn-success flex items-center gap-1.5 text-xs py-1.5">
                        {acting === a.id
                          ? <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          : <CheckCircle size={13} />}
                        Approve
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Resolved */}
          {resolved.length > 0 && (
            <div className="card overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-100">
                <h2 className="font-semibold text-slate-800">Resolved ({resolved.length})</h2>
              </div>
              <div className="divide-y divide-slate-50">
                {resolved.map(a => (
                  <div key={a.id} className="flex items-center justify-between px-5 py-3.5">
                    <div>
                      <p className="font-medium text-slate-800 text-sm">{a.employee_name}</p>
                      <p className="text-xs text-slate-400">{a.reason}</p>
                    </div>
                    <div className="text-right">
                      <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
                        a.status === 'approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                      }`}>{a.status}</span>
                      <p className="text-xs text-slate-400 mt-1">{a.approver}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
