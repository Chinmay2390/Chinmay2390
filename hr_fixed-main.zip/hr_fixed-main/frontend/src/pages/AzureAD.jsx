import { useState, useEffect } from 'react'
import { getAzureStatus, testAzureConnection, getAzureUsers, getAzureGroups, azureOnboard, getRoleGroupMapping } from '../api'
import toast from 'react-hot-toast'
import { Cloud, CheckCircle2, XCircle, Loader2, Users, Shield, UserPlus, RefreshCw, ChevronDown, Zap } from 'lucide-react'

const ROLES = ['developer', 'admin', 'hr_manager', 'finance', 'sales', 'intern']
const DEPTS = ['Engineering', 'IT-Admin', 'HR', 'Finance', 'Sales', 'Operations', 'Internship']

export default function AzureAD() {
  const [status, setStatus]     = useState(null)
  const [connTest, setConnTest] = useState(null)
  const [users, setUsers]       = useState([])
  const [groups, setGroups]     = useState([])
  const [roleMap, setRoleMap]   = useState({})
  const [tab, setTab]           = useState('status')
  const [loading, setLoading]   = useState(false)
  const [form, setForm]         = useState({ name: '', email: '', department: 'Engineering', role: 'developer', manager: '', phone: '' })
  const [onboardResult, setOnboardResult] = useState(null)

  useEffect(() => {
    getAzureStatus().then(r => setStatus(r.data)).catch(() => {})
    getRoleGroupMapping().then(r => setRoleMap(r.data.mapping || {})).catch(() => {})
  }, [])

  const loadUsers = async () => {
    setLoading(true)
    try { const r = await getAzureUsers(20); setUsers(r.data.users || []) }
    catch { toast.error('Could not load users') }
    finally { setLoading(false) }
  }

  const loadGroups = async () => {
    setLoading(true)
    try { const r = await getAzureGroups(); setGroups(r.data.groups || []) }
    catch { toast.error('Could not load groups') }
    finally { setLoading(false) }
  }

  const runConnectionTest = async () => {
    setLoading(true)
    setConnTest(null)
    try { const r = await testAzureConnection(); setConnTest(r.data) }
    catch (e) { setConnTest({ status: 'failed', error: e.message }) }
    finally { setLoading(false) }
  }

  const handleOnboard = async () => {
    if (!form.name) return toast.error('Name is required')
    setLoading(true)
    setOnboardResult(null)
    try {
      const r = await azureOnboard(form)
      setOnboardResult(r.data)
      toast.success(r.data.status === 'success' ? 'User created in Azure AD ✅' : 'Partial — check steps')
    } catch (e) { toast.error(e.response?.data?.detail || 'Azure onboarding failed') }
    finally { setLoading(false) }
  }

  const isReal = status?.use_real_graph

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
          <Cloud size={20} className="text-blue-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-900">Azure AD Management</h1>
          <p className="text-sm text-slate-500">Microsoft Entra ID · User provisioning · Group management</p>
        </div>
        {status && (
          <span className={`ml-auto text-xs font-semibold px-3 py-1.5 rounded-full ${
            isReal ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
          }`}>
            {isReal ? '🔴 REAL Azure AD' : '🟡 SIMULATED'}
          </span>
        )}
      </div>

      {/* Mode banner */}
      {status && !isReal && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex items-center gap-3">
          <span className="text-amber-600 text-lg">🟡</span>
          <div className="text-sm">
            <span className="font-semibold text-amber-800">Simulation mode — </span>
            <span className="text-amber-700">no real Azure calls. Set <code className="bg-amber-100 px-1 rounded">USE_REAL_GRAPH=true</code> in <code className="bg-amber-100 px-1 rounded">backend/.env</code> to connect to your tenant.</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 p-1 rounded-xl w-fit flex-wrap">
        {[
          { key: 'status', label: 'Connection', icon: Shield },
          { key: 'onboard', label: 'Provision User', icon: UserPlus },
          { key: 'users', label: 'AD Users', icon: Users },
          { key: 'groups', label: 'Groups', icon: Cloud },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => { setTab(key); if (key === 'users') loadUsers(); if (key === 'groups') loadGroups(); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === key ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}>
            <Icon size={14} />{label}
          </button>
        ))}
      </div>

      {/* ── STATUS TAB ── */}
      {tab === 'status' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
            <h2 className="font-semibold text-slate-800">Configuration</h2>
            <div className="space-y-3">
              {[
                ['Mode', status?.mode, isReal ? 'green' : 'amber'],
                ['Tenant ID', status?.tenant_id, 'blue'],
                ['Client ID', status?.client_id, 'blue'],
                ['Tenant Domain', status?.tenant_domain, status?.tenant_domain === 'not set' ? 'red' : 'green'],
              ].map(([label, value, color]) => (
                <div key={label} className="flex items-center justify-between py-2 border-b border-slate-100 last:border-0">
                  <span className="text-sm text-slate-500">{label}</span>
                  <span className={`text-sm font-medium text-${color}-700 bg-${color}-50 px-2 py-0.5 rounded`}>{value || 'Loading…'}</span>
                </div>
              ))}
            </div>

            <button onClick={runConnectionTest} disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white font-semibold py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all">
              {loading ? <Loader2 size={15} className="animate-spin" /> : <Zap size={15} />}
              {isReal ? 'Test Real Connection' : 'Test Simulated Connection'}
            </button>

            {connTest && (
              <div className={`rounded-xl p-4 border ${connTest.status === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {connTest.status === 'success' ? <CheckCircle2 size={16} className="text-green-600" /> : <XCircle size={16} className="text-red-600" />}
                  <span className="font-semibold text-sm">{connTest.status === 'success' ? 'Connection successful ✅' : 'Connection failed ❌'}</span>
                </div>
                <p className="text-xs text-slate-600">{connTest.message || connTest.error || connTest.hint || ''}</p>
              </div>
            )}
          </div>

          {/* Role → Group mapping */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6">
            <h2 className="font-semibold text-slate-800 mb-4">Role → Azure AD Group Mapping</h2>
            <div className="space-y-3">
              {Object.entries(roleMap).map(([role, groups]) => (
                <div key={role} className="border border-slate-100 rounded-xl p-3">
                  <p className="text-sm font-semibold text-slate-700 capitalize mb-2">{role.replace('_', ' ')}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {(groups || []).map(g => (
                      <span key={g} className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{g}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── PROVISION USER TAB ── */}
      {tab === 'onboard' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h2 className="font-semibold text-slate-800">Provision User in Azure AD</h2>
            <p className="text-xs text-slate-500">This creates the user directly in Azure AD. For full HR onboarding (DB + assets + email), use the Onboard page instead.</p>

            {[
              { key: 'name', label: 'Full Name *', placeholder: 'Alice Johnson' },
              { key: 'manager', label: 'Manager Name', placeholder: 'Display name in Azure AD (or leave blank)' },
              { key: 'phone', label: 'Mobile Phone', placeholder: '+91-9999999999' },
            ].map(({ key, label, placeholder }) => (
              <div key={key}>
                <label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>
                <input value={form[key]} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
                  placeholder={placeholder}
                  className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
              </div>
            ))}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Department</label>
                <div className="relative">
                  <select value={form.department} onChange={e => setForm(p => ({ ...p, department: e.target.value }))}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-400">
                    {DEPTS.map(d => <option key={d}>{d}</option>)}
                  </select>
                  <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Role</label>
                <div className="relative">
                  <select value={form.role} onChange={e => setForm(p => ({ ...p, role: e.target.value }))}
                    className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-400">
                    {ROLES.map(r => <option key={r}>{r}</option>)}
                  </select>
                  <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Groups preview */}
            {roleMap[form.role] && (
              <div className="bg-blue-50 rounded-xl p-3">
                <p className="text-xs font-semibold text-blue-700 mb-1.5">Groups that will be assigned:</p>
                <div className="flex flex-wrap gap-1">
                  {[`SG-${form.department.replace(' ', '-')}`, ...(roleMap[form.role] || [])].filter((v, i, a) => a.indexOf(v) === i).map(g => (
                    <span key={g} className="text-xs bg-white text-blue-600 border border-blue-200 px-2 py-0.5 rounded-full">{g}</span>
                  ))}
                </div>
              </div>
            )}

            <button onClick={handleOnboard} disabled={loading || !form.name}
              className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2 transition-all">
              {loading ? <Loader2 size={16} className="animate-spin" /> : <Cloud size={16} />}
              {isReal ? 'Create in Azure AD' : 'Simulate Azure Provisioning'}
            </button>
          </div>

          {/* Result */}
          <div>
            {onboardResult ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4">
                <div className="flex items-center gap-2">
                  {onboardResult.status === 'success' ? <CheckCircle2 size={18} className="text-green-600" /> : <XCircle size={18} className="text-amber-500" />}
                  <span className="font-semibold text-slate-800">
                    {onboardResult.status === 'success' ? 'Provisioning Complete' : 'Partial Success'}
                  </span>
                  <span className={`ml-auto text-xs px-2 py-0.5 rounded-full font-medium ${onboardResult.real ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                    {onboardResult.real ? 'REAL' : 'SIMULATED'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  {[
                    ['Object ID', onboardResult.azure_object_id],
                    ['UPN', onboardResult.upn],
                    ['Temp Password', onboardResult.temp_password],
                    ['Steps Done', `${onboardResult.completed}/${onboardResult.steps?.length}`],
                  ].map(([k, v]) => (
                    <div key={k} className="bg-slate-50 rounded-lg p-2.5">
                      <p className="text-slate-400">{k}</p>
                      <p className="font-mono font-semibold text-slate-800 text-xs mt-0.5 truncate">{String(v || '—')}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-1.5">
                  <p className="text-xs font-semibold text-slate-600">Step Results</p>
                  {(onboardResult.steps || []).map((step, i) => (
                    <div key={i} className={`flex items-start gap-2 p-2 rounded-lg text-xs ${step.status === 'success' ? 'bg-green-50' : 'bg-red-50'}`}>
                      <span className="mt-0.5">{step.status === 'success' ? '✅' : '❌'}</span>
                      <div>
                        <span className="font-medium text-slate-700">{step.step?.replace(/_/g, ' ')}</span>
                        {step.real !== undefined && <span className={`ml-1 text-xs ${step.real ? 'text-green-600' : 'text-amber-600'}`}>[{step.real ? 'REAL' : 'SIM'}]</span>}
                        <p className="text-slate-500 mt-0.5">{step.message || step.error || ''}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400">
                <Cloud size={40} className="mx-auto mb-3 opacity-20" />
                <p className="font-medium">Provisioning results will appear here</p>
                <p className="text-sm mt-1">Fill the form and click provision</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── USERS TAB ── */}
      {tab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <span className="font-semibold text-slate-800">Azure AD Users</span>
            <button onClick={loadUsers} className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline">
              <RefreshCw size={13} />Refresh
            </button>
          </div>
          {loading ? (
            <div className="flex items-center justify-center py-16 gap-2 text-slate-400"><Loader2 size={20} className="animate-spin" />Loading…</div>
          ) : users.length === 0 ? (
            <div className="py-16 text-center text-slate-400"><Users size={36} className="mx-auto mb-2 opacity-20" /><p>Click Refresh to load users</p></div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-slate-50 text-xs text-slate-500 font-medium">
                <tr>
                  {['Display Name', 'UPN / Login', 'Department', 'Status'].map(h => (
                    <th key={h} className="px-4 py-3 text-left">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="px-4 py-3 font-medium text-slate-800">{u.displayName}</td>
                    <td className="px-4 py-3 text-slate-500 font-mono text-xs">{u.userPrincipalName}</td>
                    <td className="px-4 py-3 text-slate-500">{u.department || '—'}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${u.accountEnabled !== false ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {u.accountEnabled !== false ? 'Active' : 'Disabled'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* ── GROUPS TAB ── */}
      {tab === 'groups' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <span className="font-semibold text-slate-800">Security Groups</span>
            <button onClick={loadGroups} className="flex items-center gap-1.5 text-sm text-blue-600 hover:underline">
              <RefreshCw size={13} />Refresh
            </button>
          </div>
          {loading ? (
            <div className="flex items-center justify-center py-16 gap-2 text-slate-400"><Loader2 size={20} className="animate-spin" />Loading…</div>
          ) : groups.length === 0 ? (
            <div className="py-16 text-center text-slate-400"><Shield size={36} className="mx-auto mb-2 opacity-20" /><p>Click Refresh to load groups</p></div>
          ) : (
            <div className="divide-y divide-slate-100">
              {groups.map((g, i) => (
                <div key={i} className="flex items-center px-5 py-3 hover:bg-slate-50">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0 mr-3">
                    <Shield size={14} className="text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{g.displayName}</p>
                    <p className="text-xs text-slate-400 font-mono">{g.id}</p>
                  </div>
                  {g.memberCount !== undefined && (
                    <span className="ml-auto text-xs text-slate-400">{g.memberCount} members</span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
