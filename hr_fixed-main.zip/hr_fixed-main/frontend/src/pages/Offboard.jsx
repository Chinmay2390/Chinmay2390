import { useState, useEffect, useRef } from 'react'
import { getActiveEmployees, offboardEmployee, getExitChecklist, completeChecklistItem, resolveAzureUser } from '../api'
import toast from 'react-hot-toast'
import {
  UserX, CheckCircle2, Circle, AlertTriangle, ChevronDown,
  Loader2, ShieldOff, PackageOpen, ClipboardCheck, Zap, Brain,
  RefreshCw, AlertCircle, TrendingUp
} from 'lucide-react'

const REASONS = [
  { value: 'resignation',  label: 'Resignation' },
  { value: 'termination',  label: 'Termination' },
  { value: 'retirement',   label: 'Retirement' },
  { value: 'contract_end', label: 'Contract End' },
]

const CATEGORY_ICONS = {
  'Code & Repos':  '💻', 'Access': '🔐', 'Assets': '📦',
  'Data':          '🗂️', 'Communication': '💬', 'HR Data': '📋',
  'Finance':       '💰', 'CRM': '🤝', 'Admin': '⚙️',
  'Security':      '🛡️', 'Compliance': '📜', 'Sign-off': '✅',
}

const RISK_COLORS = {
  low:      { bg: 'bg-green-50',  border: 'border-green-200',  text: 'text-green-700',  badge: 'bg-green-100 text-green-800' },
  medium:   { bg: 'bg-yellow-50', border: 'border-yellow-200', text: 'text-yellow-700', badge: 'bg-yellow-100 text-yellow-800' },
  high:     { bg: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-700', badge: 'bg-orange-100 text-orange-800' },
  critical: { bg: 'bg-red-50',    border: 'border-red-200',    text: 'text-red-700',    badge: 'bg-red-100 text-red-800' },
}

export default function Offboard() {
  const [employees, setEmployees]   = useState([])
  const [selected, setSelected]     = useState(null)
  const [lastDay, setLastDay]       = useState('')
  const [reason, setReason]         = useState('resignation')
  const [loading, setLoading]       = useState(false)
  const [result, setResult]         = useState(null)
  const [checklist, setChecklist]   = useState(null)
  const [tab, setTab]               = useState('form')
  const pollRef                     = useRef(null)

  useEffect(() => {
    getActiveEmployees().then(r => setEmployees(r.data)).catch(() => {})
    return () => clearInterval(pollRef.current)
  }, [])

  // Auto-refresh checklist every 8s while on checklist tab
  useEffect(() => {
    clearInterval(pollRef.current)
    if (tab === 'checklist' && checklist?.employee_id) {
      pollRef.current = setInterval(() => {
        getExitChecklist(checklist.employee_id)
          .then(r => setChecklist(r.data))
          .catch(() => {})
      }, 8000)
    }
    return () => clearInterval(pollRef.current)
  }, [tab, checklist?.employee_id])

  const handleSubmit = async () => {
    if (!selected) return toast.error('Select an employee')
    if (!lastDay)  return toast.error('Enter last working day')
    setLoading(true)
    try {
      // ── Resolve real Azure Object ID before offboarding ──────────
      // Stored IDs may be sim-xxx (from seed data) or wrong UPN.
      // The backend will also resolve independently, but passing the
      // real ID here skips the extra lookup and ensures correctness.
      let azureObjectId = null
      try {
        const azRes = await resolveAzureUser(selected.name)
        if (azRes.data?.found && azRes.data?.id) {
          azureObjectId = azRes.data.id
        }
      } catch (_) { /* non-fatal — backend will resolve */ }

      const res = await offboardEmployee(selected.id, {
        last_day: lastDay,
        reason,
        performed_by: 'hr_system',
        azure_object_id: azureObjectId,   // pass real ID if found
      })
      setResult(res.data)
      toast.success(`${selected.name} offboarded`)
      setEmployees(p => p.filter(e => e.id !== selected.id))
      const cl = await getExitChecklist(selected.id)
      setChecklist(cl.data)
      setTab('checklist')
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Offboarding failed')
    } finally { setLoading(false) }
  }

  const toggleItem = async (itemId) => {
    try {
      await completeChecklistItem(itemId, { completed_by: 'hr_staff' })
      setChecklist(prev => {
        const items = prev.items.map(i =>
          i.id === itemId ? { ...i, is_completed: true, completed_at: new Date().toISOString(), completed_by: 'hr_staff', auto: false } : i
        )
        const done = items.filter(i => i.is_completed).length
        return { ...prev, items, completed: done, progress_pct: Math.round(done / items.length * 100) }
      })
      toast.success('Marked complete ✓')
    } catch { toast.error('Failed') }
  }

  const risk = result?.risk || {}
  const riskColors = RISK_COLORS[risk.risk_level] || RISK_COLORS.low
  const grouped = checklist?.items?.reduce((acc, item) => {
    if (!acc[item.category]) acc[item.category] = []
    acc[item.category].push(item)
    return acc
  }, {})

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
          <UserX size={20} className="text-red-600" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-slate-900">Offboard Employee</h1>
          <p className="text-sm text-slate-500">AI risk scoring · M365 integration · Auto exit checklist · Real email alerts</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-slate-100 p-1 rounded-xl w-fit">
        {[
          { key: 'form',      label: 'Offboard',     icon: UserX },
          { key: 'checklist', label: 'Exit Checklist', icon: ClipboardCheck },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setTab(key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === key ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}>
            <Icon size={15} />{label}
            {key === 'checklist' && checklist && (
              <span className={`text-xs px-1.5 py-0.5 rounded-full font-bold ${
                checklist.completed === checklist.total ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
              }`}>{checklist.completed}/{checklist.total}</span>
            )}
          </button>
        ))}
      </div>

      {/* ── FORM TAB ── */}
      {tab === 'form' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
            <h2 className="font-semibold text-slate-800">Offboarding Details</h2>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Select Employee</label>
              <div className="relative">
                <select className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-red-400"
                  value={selected?.id || ''}
                  onChange={e => setSelected(employees.find(em => em.id === parseInt(e.target.value)) || null)}>
                  <option value="">— Select active employee —</option>
                  {employees.map(e => (
                    <option key={e.id} value={e.id}>{e.name} — {e.role} ({e.department})</option>
                  ))}
                </select>
                <ChevronDown size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Last Working Day</label>
              <input type="date" value={lastDay} onChange={e => setLastDay(e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-red-400" />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Reason</label>
              <div className="grid grid-cols-2 gap-2">
                {REASONS.map(r => (
                  <button key={r.value} onClick={() => setReason(r.value)}
                    className={`px-3 py-2 rounded-xl text-sm font-medium border transition-all ${
                      reason === r.value ? 'border-red-500 bg-red-50 text-red-700' : 'border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}>{r.label}</button>
                ))}
              </div>
            </div>

            <div className="flex gap-3 bg-amber-50 border border-amber-200 rounded-xl p-3">
              <AlertTriangle size={16} className="text-amber-600 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-amber-700">
                Triggers <strong>LLM risk analysis</strong>, AD cleanup, M365 block, RBAC revocation,
                auto-exit checklist, and {import.meta.env.VITE_USE_REAL_EMAIL === 'true' ? 'real Gmail email' : 'email simulation'}.
              </p>
            </div>

            <button onClick={handleSubmit} disabled={loading || !selected || !lastDay}
              className="w-full bg-red-600 hover:bg-red-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-semibold py-3 rounded-xl transition-all flex items-center justify-center gap-2">
              {loading ? <><Loader2 size={16} className="animate-spin" />Processing…</> : <><UserX size={16} />Offboard Employee</>}
            </button>
          </div>

          <div className="space-y-4">
            {/* Pipeline */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5">
              <h3 className="font-semibold text-slate-800 mb-4 text-sm flex items-center gap-2">
                <Zap size={15} className="text-purple-500" /> Automated Pipeline
              </h3>
              <div className="space-y-2.5">
                {[
                  { icon: Brain,         color: 'purple', label: 'AI Risk Analysis',        desc: 'Groq LLM scores insider threat risk (0–100) from audit signals' },
                  { icon: ShieldOff,     color: 'red',    label: 'AD Cleanup (6 steps)',     desc: 'Disable account, reset password, remove groups, move OU, clear sessions, OOF' },
                  { icon: ShieldOff,     color: 'orange', label: 'M365 Block',              desc: 'Block sign-in, revoke all sessions, remove MFA, set out-of-office' },
                  { icon: ShieldOff,     color: 'blue',   label: 'RBAC Revocation',         desc: 'All system access revoked — GitHub, AWS, Jira, Slack, VPN…' },
                  { icon: ClipboardCheck,color: 'green',  label: 'Auto Exit Checklist',     desc: 'Role-specific checklist auto-generated; system items auto-checked instantly' },
                  { icon: PackageOpen,   color: 'slate',  label: 'Asset Return Flagging',   desc: 'Laptop + ID card flagged pending; HR confirms physical return via checklist' },
                ].map(({ icon: Icon, color, label, desc }) => (
                  <div key={label} className="flex gap-3 items-start">
                    <div className={`w-6 h-6 rounded-md bg-${color}-100 flex items-center justify-center flex-shrink-0 mt-0.5`}>
                      <Icon size={12} className={`text-${color}-600`} />
                    </div>
                    <div><p className="text-xs font-semibold text-slate-700">{label}</p>
                      <p className="text-xs text-slate-400 leading-tight">{desc}</p></div>
                  </div>
                ))}
              </div>
            </div>

            {/* Result + risk card */}
            {result && (
              <div className="space-y-3">
                {/* Risk badge */}
                <div className={`rounded-2xl border p-4 ${riskColors.bg} ${riskColors.border}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <TrendingUp size={16} className={riskColors.text} />
                      <span className={`font-semibold text-sm ${riskColors.text}`}>AI Risk Assessment</span>
                    </div>
                    <span className={`text-xs font-bold px-2 py-1 rounded-full uppercase ${riskColors.badge}`}>
                      {risk.risk_level || 'N/A'} • {risk.risk_score ?? '—'}/100
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">{risk.summary || '—'}</p>
                  {risk.risk_factors?.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1">
                      {risk.risk_factors.slice(0, 3).map(f => (
                        <span key={f} className="text-xs bg-white/70 px-2 py-0.5 rounded-full text-slate-600">{f}</span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Summary */}
                <div className="bg-green-50 border border-green-200 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-green-600" />
                    <span className="font-semibold text-green-800 text-sm">Offboarding Complete</span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5 text-xs">
                    {[
                      ['Employee', result.name],
                      ['Last Day', result.last_day],
                      ['AD Steps', result.ad_steps_completed],
                      ['M365 Steps', result.m365_steps_completed],
                      ['Systems Revoked', result.systems_revoked?.length],
                      ['Checklist Auto', `${result.checklist_auto_completed}/${result.checklist_items}`],
                      ['Email', result.email_status],
                      ['Azure Blocked', result.m365_steps_completed > 0 ? '✅ Yes' : '⚠️ Check logs'],
                    ].map(([k, v]) => (
                      <div key={k} className="bg-white rounded-lg p-2">
                        <p className="text-slate-400">{k}</p>
                        <p className="font-semibold text-slate-800 capitalize truncate">{String(v)}</p>
                      </div>
                    ))}
                  </div>
                  <button onClick={() => setTab('checklist')}
                    className="w-full bg-green-600 text-white text-xs font-medium py-2 rounded-lg hover:bg-green-700 transition-all">
                    View Exit Checklist →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── CHECKLIST TAB ── */}
      {tab === 'checklist' && (
        <div className="space-y-4">
          {!checklist?.items?.length ? (
            <div className="text-center py-20 text-slate-400">
              <ClipboardCheck size={40} className="mx-auto mb-3 opacity-30" />
              <p className="font-medium">No exit checklist yet</p>
              <p className="text-sm">Offboard an employee first</p>
            </div>
          ) : (
            <>
              {/* Progress + auto-refresh indicator */}
              <div className="bg-white rounded-2xl border border-slate-200 p-5">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="font-semibold text-slate-800">Exit Checklist Progress</span>
                    {checklist.auto_completed > 0 && (
                      <span className="ml-2 text-xs text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
                        <Zap size={10} className="inline mr-0.5" />{checklist.auto_completed} auto-completed
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-400 flex items-center gap-1">
                      <RefreshCw size={10} />auto-refresh 8s
                    </span>
                    <span className={`text-sm font-bold ${checklist.completed === checklist.total ? 'text-green-600' : 'text-amber-600'}`}>
                      {checklist.progress_pct}% · {checklist.completed}/{checklist.total}
                    </span>
                  </div>
                </div>
                <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all duration-700 ${
                    checklist.completed === checklist.total ? 'bg-green-500' : 'bg-gradient-to-r from-blue-500 to-purple-500'
                  }`} style={{ width: `${checklist.progress_pct}%` }} />
                </div>
                {checklist.completed < checklist.total && (
                  <p className="text-xs text-amber-600 mt-2 flex items-center gap-1">
                    <AlertCircle size={12} />
                    {checklist.total - checklist.completed} item(s) still pending — check Assets and Sign-off sections
                  </p>
                )}
              </div>

              {/* Grouped checklist */}
              {Object.entries(grouped || {}).map(([category, items]) => (
                <div key={category} className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                  <div className="px-5 py-3 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
                    <span>{CATEGORY_ICONS[category] || '📌'}</span>
                    <span className="font-semibold text-slate-700 text-sm">{category}</span>
                    <span className="text-xs text-slate-400 ml-auto">
                      {items.filter(i => i.is_completed).length}/{items.length}
                    </span>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {items.map(item => (
                      <div key={item.id} className="flex items-center gap-3 px-5 py-3">
                        <button onClick={() => !item.is_completed && toggleItem(item.id)}
                          className={`flex-shrink-0 transition-colors ${
                            item.is_completed ? 'text-green-500 cursor-default' : 'text-slate-300 hover:text-slate-500'
                          }`}>
                          {item.is_completed ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                        </button>
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm ${item.is_completed ? 'line-through text-slate-400' : 'text-slate-700'}`}>
                            {item.item}
                          </p>
                          {item.is_completed && (
                            <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                              {item.auto && <span className="text-purple-500"><Zap size={10} className="inline" /> auto</span>}
                              {!item.auto && item.completed_by}
                              {item.completed_at && ` · ${new Date(item.completed_at).toLocaleDateString()}`}
                            </p>
                          )}
                        </div>
                        {!item.is_completed && (
                          <button onClick={() => toggleItem(item.id)}
                            className="text-xs text-blue-600 hover:underline flex-shrink-0">Mark done</button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  )
}
