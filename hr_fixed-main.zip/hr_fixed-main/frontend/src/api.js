import axios from 'axios'

const api = axios.create({ baseURL: 'http://localhost:8000/api' })

// Employees
export const getEmployees     = (params)   => api.get('/employees/', { params })
export const getEmployee      = (id)       => api.get(`/employees/${id}`)

// Onboarding
export const onboardEmployee  = (data)     => api.post('/onboard/', data)
export const executeApproval  = (id)       => api.post(`/onboard/execute/${id}`)

// Approvals
export const getApprovals     = (status)   => api.get('/approvals/', { params: { status } })
export const approveRequest   = (id, data) => api.post(`/approvals/${id}/approve`, data)
export const rejectRequest    = (id, data) => api.post(`/approvals/${id}/reject`, data)

// Audit Logs — GET /logs/ now works (aliases /logs/audit)
export const getLogs          = (params)   => api.get('/logs/', { params })
export const getAuditLogs     = (params)   => api.get('/logs/', { params })

// Assets
export const getAssets        = ()         => api.get('/assets/')
export const getAssetSummary  = ()         => api.get('/assets/summary').catch(() => ({ data: {} }))

// Email logs
export const getEmailLogs     = ()         => api.get('/logs/emails/')

// Chatbot — fixed: router prefix is /chatbot not /chat
export const sendChatMessage  = (msg, hist) => api.post('/chatbot/', { message: msg, history: hist || [] })
export const sendChat         = (msg, hist) => sendChatMessage(msg, hist)

// Roles
export const getRoles         = ()         => api.get('/roles/')

// Offboarding
export const getActiveEmployees    = ()             => api.get('/offboard/active')
export const offboardEmployee      = (id, data)     => api.post(`/offboard/${id}`, data)
export const getExitChecklist      = (id)           => api.get(`/offboard/${id}/checklist`)
export const completeChecklistItem = (itemId, data) => api.patch(`/offboard/checklist/${itemId}`, data)
export const getOffboardAlerts     = ()             => api.get('/offboard/alerts')
export const getEmployeeRisk       = (id)           => api.get(`/offboard/${id}/risk`)

// Leaver (offboarded users)
export const getLeavers            = ()             => api.get('/leaver/')
export const getLeaverChecklist    = (id)           => api.get(`/leaver/${id}/checklist`)
export const completeLeaverItem    = (itemId, data) => api.patch(`/leaver/checklist/${itemId}`, data)
export const deleteFromAzure       = (id, data)     => api.post(`/leaver/${id}/delete-from-azure`, data)

// Azure AD
export const getAzureStatus        = ()         => api.get('/azure/status')
export const testAzureConnection   = ()         => api.get('/azure/test-connection')
export const getAzureUsers         = (limit=20) => api.get(`/azure/users?limit=${limit}`)
export const getAzureGroups        = ()         => api.get('/azure/groups')
export const azureOnboard          = (data)     => api.post('/azure/onboard', data)
export const getRoleGroupMapping   = ()         => api.get('/azure/role-groups')
export const resolveAzureUser      = (name)     => api.get(`/azure/resolve/${encodeURIComponent(name)}`)

// Manual Azure sync
export const syncAzure             = ()         => api.post('/sync-azure')

// Mover
export const transferEmployee      = (data)     => api.post('/mover/transfer', data)
export const getMoverHistory       = (id)       => api.get('/mover/history', { params: id ? { employee_id: id } : {} })

// Aliases
export const actOnApproval  = (id, action, data) =>
  action === 'approve' ? approveRequest(id, data) : rejectRequest(id, data)

export default api
