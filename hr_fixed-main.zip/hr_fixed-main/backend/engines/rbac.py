from sqlalchemy.orm import Session
from models import Role, RolePermission, Employee, EmployeeAccess, AuditLog
from datetime import datetime


def _log(db, emp_id, action, system, by, status, details):
    db.add(AuditLog(
        employee_id=emp_id, action=action, system=system,
        performed_by=by, status=status, details=details
    ))


def provision_access(db: Session, employee: Employee,
                     role: Role, performed_by: str = "system") -> list:
    """Grant all system permissions defined by the role."""
    perms = db.query(RolePermission).filter(RolePermission.role_id == role.id).all()
    provisioned = []
    for perm in perms:
        db.add(EmployeeAccess(
            employee_id=employee.id,
            system=perm.system,
            access_level=perm.permission,
            is_active=True
        ))
        _log(db, employee.id, "GRANT_ACCESS", perm.system, performed_by,
             "success", f"Granted '{perm.permission}' on {perm.system}")
        provisioned.append({"system": perm.system, "level": perm.permission})
    return provisioned


def assign_assets(db: Session, employee: Employee) -> list:
    """Auto-assign one available laptop and one ID card."""
    from models import Asset, AssetAssignment
    assigned = []
    for asset_type in ["Laptop", "ID Card"]:
        asset = db.query(Asset).filter(
            Asset.asset_type == asset_type,
            Asset.status == "available"
        ).first()
        if asset:
            asset.status = "assigned"
            db.add(AssetAssignment(
                asset_id=asset.id,
                employee_id=employee.id,
                is_active=True
            ))
            assigned.append({"asset_tag": asset.asset_tag, "type": asset_type, "model": asset.model})
    return assigned


def revoke_all_access(db: Session, employee, performed_by: str = "system") -> list:
    """Revoke all active system access for offboarding."""
    revoked = []
    for acc in employee.access_list:
        if acc.is_active:
            acc.is_active = False
            _log(db, employee.id, "REVOKE_ACCESS", acc.system, performed_by,
                 "success", f"Revoked '{acc.access_level}' on {acc.system}")
            revoked.append({"system": acc.system, "level": acc.access_level})
    return revoked


def return_assets(db: Session, employee) -> list:
    """Mark all assigned assets as available (returned)."""
    from models import Asset
    returned = []
    for assignment in employee.assets:
        if assignment.is_active:
            assignment.is_active = False
            asset = db.query(Asset).filter(Asset.id == assignment.asset_id).first()
            if asset:
                asset.status = "available"
                returned.append({"asset_tag": asset.asset_tag, "type": asset.asset_type})
    return returned
