"""
Email Engine — Real Gmail SMTP + simulator fallback
----------------------------------------------------
SET USE_REAL_EMAIL=true in .env to send real emails via Gmail.
SET USE_REAL_EMAIL=false (default) to use the DB simulator.

Gmail setup:
  1. Enable 2FA on the Gmail account
  2. Create an App Password: myaccount.google.com/apppasswords
  3. Add GMAIL_ADDRESS + GMAIL_APP_PASSWORD to .env
"""
import os, smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from sqlalchemy.orm import Session
from models import EmailLog

USE_REAL   = os.getenv("USE_REAL_EMAIL", "false").lower() == "true"
GMAIL_ADDR = os.getenv("GMAIL_ADDRESS", "")
GMAIL_PASS = os.getenv("GMAIL_APP_PASSWORD", "")
FROM_NAME  = os.getenv("EMAIL_FROM_NAME", "TechCorp HR Automation")
COMPANY    = os.getenv("COMPANY_NAME", "TechCorp Solutions")
DOMAIN     = os.getenv("COMPANY_DOMAIN", "techcorp.com")
SEC_EMAIL  = os.getenv("SECURITY_TEAM_EMAIL", "")


def send_email(db: Session, to: str, subject: str, body: str, related_emp: str = "") -> dict:
    """Unified send — real SMTP or simulator based on env flag."""
    _save_to_db(db, to, subject, body, related_emp)

    if USE_REAL and GMAIL_ADDR and GMAIL_PASS:
        return _send_real(to, subject, body)
    return {"status": "simulated", "to": to, "subject": subject}


def _send_real(to: str, subject: str, body: str) -> dict:
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = f"{FROM_NAME} <{GMAIL_ADDR}>"
        msg["To"]      = to
        msg.attach(MIMEText(body, "plain"))

        ctx = ssl.create_default_context()
        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=ctx) as server:
            server.login(GMAIL_ADDR, GMAIL_PASS)
            server.sendmail(GMAIL_ADDR, to, msg.as_string())
        return {"status": "sent", "to": to, "subject": subject}
    except Exception as e:
        return {"status": "failed", "error": str(e), "to": to}


def _save_to_db(db: Session, to: str, subject: str, body: str, emp: str):
    status = "sent" if (USE_REAL and GMAIL_ADDR and GMAIL_PASS) else "simulated"
    db.add(EmailLog(
        to_address=to, subject=subject, body=body,
        status=status, related_emp=emp
    ))
    db.flush()


# ── High-level senders ──────────────────────────────────────────

def send_welcome_email(db, name, email, emp_id, role, department):
    subject = f"Welcome to {COMPANY}, {name.split()[0]}!"
    body = f"""Dear {name},

Welcome to {COMPANY}! We're delighted to have you on board.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
YOUR EMPLOYEE DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Employee ID  : {emp_id}
Work Email   : {email}
Role         : {role.replace('_', ' ').title()}
Department   : {department}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your system access has been provisioned. Please collect your
laptop and ID card from the IT desk on your first day.

HR Team — {COMPANY}
{'[REAL EMAIL SENT via Gmail]' if USE_REAL else '[SIMULATED — No real email sent]'}"""
    return send_email(db, email, subject, body, name)


def send_approval_request_email(db, emp_name, emp_id, role, requested_by):
    subject = f"[ACTION REQUIRED] Onboarding approval for {emp_name}"
    approver = f"hr.director@{DOMAIN}"
    body = f"""Dear HR Director,

An onboarding request requires your approval.

Employee : {emp_name}
Role     : {role.replace('_', ' ').title()}
Requested: {requested_by}
Ref ID   : {emp_id}

Please log in to the HR System to approve or reject.

HR Automation — {COMPANY}"""
    return send_email(db, approver, subject, body, emp_name)


def send_offboard_email(db, name, email, emp_id, role, last_day, reason):
    subject = f"[TechCorp] Your offboarding — {name}"
    body = f"""Dear {name},

Your employment transition from {COMPANY} has been processed.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OFFBOARDING DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Employee ID  : {emp_id}
Role         : {role.replace('_', ' ').title()}
Last Day     : {last_day}
Reason       : {reason.replace('_', ' ').title()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ACTION REQUIRED:
• Return your laptop and ID card to the IT desk within 2 days
• Your system access has been revoked immediately
• Your AD account has been disabled

Thank you for your contributions to {COMPANY}.

HR Team — {COMPANY}
{'[REAL EMAIL SENT via Gmail]' if USE_REAL else '[SIMULATED — No real email sent]'}"""
    return send_email(db, email, subject, body, name)


def send_security_alert(db, name, emp_id, risk_score, risk_summary):
    """Alert security team when high-risk offboarding is detected."""
    if not SEC_EMAIL:
        return {"status": "skipped", "reason": "SECURITY_TEAM_EMAIL not set"}
    subject = f"[SECURITY ALERT] High-risk offboarding — {name} (Score: {risk_score})"
    body = f"""SECURITY TEAM ALERT

High-risk employee offboarding has been triggered.

Employee : {name}
ID       : {emp_id}
Risk Score: {risk_score}/100
Timestamp : {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC

RISK SUMMARY:
{risk_summary}

RECOMMENDED ACTIONS:
1. Verify all system access is fully revoked
2. Review last 30 days of audit logs
3. Check for any unusual data transfers
4. Ensure device has been wiped if applicable

HR Automation System — {COMPANY}"""
    return send_email(db, SEC_EMAIL, subject, body, name)


# ── Email generation helper (kept here for unified import) ──────
def generate_unique_email(name: str, db) -> str:
    """Generate a unique company email from employee name."""
    from models import Employee
    parts = name.lower().split()
    base  = f"{parts[0]}.{parts[-1]}@{DOMAIN}"
    email, n = base, 1
    while db.query(Employee).filter(Employee.email == email).first():
        email = f"{parts[0]}.{parts[-1]}{n}@{DOMAIN}"
        n += 1
    return email
