"""
routers/system_status.py
Returns which integrations are REAL vs SIMULATED.
Used by the frontend status bar so users always know what's live.
"""
import os
from fastapi import APIRouter

router = APIRouter(prefix="/status", tags=["system"])


@router.get("/")
def get_system_status():
    """
    Returns the current integration mode for every subsystem.
    Frontend displays this as a live status bar.
    """
    groq_key   = os.getenv("GROQ_API_KEY", "")
    use_email  = os.getenv("USE_REAL_EMAIL", "false").lower() == "true"
    use_graph  = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    use_ad     = os.getenv("USE_REAL_AD",    "false").lower() == "true"
    db_url     = os.getenv("DATABASE_URL", "sqlite:///./hr_onboarding.db")

    has_groq   = bool(groq_key) and groq_key != "your_groq_api_key_here"
    is_sqlite  = "sqlite" in db_url.lower()
    gmail_set  = bool(os.getenv("GMAIL_ADDRESS", "")) and os.getenv("GMAIL_ADDRESS") != "your_gmail@gmail.com"

    return {
        "database": {
            "mode":    "SQLite (Dummy DB)" if is_sqlite else "PostgreSQL (Production)",
            "real":    not is_sqlite,
            "url":     "sqlite:///hr_onboarding.db" if is_sqlite else "postgresql://...",
            "note":    "Running on local SQLite dummy database — all data is simulated" if is_sqlite
                       else "Connected to production PostgreSQL",
        },
        "active_directory": {
            "mode":  "Real Windows AD" if use_ad else "Simulated (Dummy)",
            "real":  use_ad,
            "note":  "Connected to real Active Directory via WinRM" if use_ad
                     else "AD operations are simulated — no real AD connected. Set USE_REAL_AD=true to connect.",
        },
        "microsoft_365": {
            "mode":  "Real Microsoft Graph" if use_graph else "Simulated (Dummy)",
            "real":  use_graph,
            "note":  "Connected to real Microsoft 365 via Graph API" if use_graph
                     else "M365 steps are simulated. Set USE_REAL_GRAPH=true + Azure credentials to connect.",
        },
        "email": {
            "mode":  "Real Gmail SMTP" if (use_email and gmail_set) else "Simulated (Stored in DB)",
            "real":  use_email and gmail_set,
            "note":  "Sending real emails via Gmail SMTP" if (use_email and gmail_set)
                     else "Emails are stored in the database — visible in Email Logs page. Set USE_REAL_EMAIL=true to send real emails.",
        },
        "llm_chatbot": {
            "mode":  "Groq Llama 3.3 70B (Live AI)" if has_groq else "Rule-based (No API Key)",
            "real":  has_groq,
            "note":  "Using Groq AI for chatbot + risk analysis" if has_groq
                     else "No GROQ_API_KEY set — using rule-based fallback. Get free key at console.groq.com",
        },
        "overall": {
            "fully_simulated": not any([use_ad, use_graph, use_email and gmail_set]),
            "production_ready": all([not is_sqlite, use_ad, use_graph, use_email, has_groq]),
        }
    }
