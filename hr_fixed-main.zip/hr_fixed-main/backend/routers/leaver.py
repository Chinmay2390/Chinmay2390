"""
routers/leaver.py — Offboarded (Disabled) Users
================================================
List offboarded employees, their exit checklists, and trigger
final Azure AD deletion after assets are recovered.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from database import get_db
from models import Employee, ExitChecklist, AuditLog
from datetime import datetime

router = APIRouter(prefix="/leaver", tags=["leaver"])


class DeleteFromAzureRequest(BaseModel):
    confirmed_by: str = "hr_admin"


@router.get("/")
def list_offboarded(db: Session = Depends(get_db)):
    """List all disabled/offboarded employees with checklist progress."""
    emps = db.query(Employee).filter(Employee.status == "disabled").order_by(Employee.disabled_at.desc()).all()
    result = []
    for e in emps:
        checklist = db.query(ExitChecklist).filter(ExitChecklist.employee_id == e.id).all()
        total = len(checklist)
        done  = sum(1 for i in checklist if i.is_completed)
        result.append({
            "id":              e.id,
            "employee_id":     e.employee_id,
            "name":            e.name,
            "email":           e.email,
            "department":      e.department,
            "role":            e.role_obj.name if e.role_obj else None,
            "azure_object_id": e.azure_object_id,
            "azure_upn":       e.azure_upn,
            "disabled_at":     e.disabled_at.isoformat() if e.disabled_at else None,
            "checklist_total": total,
            "checklist_done":  done,
            "checklist_pct":   round(done / total * 100) if total else 0,
            "assets_pending":  sum(1 for a in e.assets if a.is_active),
            "azure_deleted":   getattr(e, "azure_deleted", False),
        })
    return result


@router.get("/{employee_id}/checklist")
def get_leaver_checklist(employee_id: int, db: Session = Depends(get_db)):
    """Get full exit checklist for a leaver."""
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    items = db.query(ExitChecklist).filter(
        ExitChecklist.employee_id == employee_id
    ).order_by(ExitChecklist.category, ExitChecklist.id).all()
    total = len(items)
    done  = sum(1 for i in items if i.is_completed)
    return {
        "employee_id":   employee_id,
        "employee_name": emp.name,
        "department":    emp.department,
        "disabled_at":   emp.disabled_at.isoformat() if emp.disabled_at else None,
        "items":         [{
            "id":           i.id,
            "item":         i.item,
            "category":     i.category,
            "is_completed": i.is_completed,
            "completed_at": i.completed_at.isoformat() if i.completed_at else None,
            "completed_by": i.completed_by,
            "auto":         i.completed_by == "system_auto" if i.completed_by else False,
        } for i in items],
        "total": total,
        "completed": done,
        "progress_pct": round(done / total * 100) if total else 0,
    }


@router.patch("/checklist/{item_id}")
def complete_leaver_checklist_item(
    item_id: int,
    body: dict,
    db: Session = Depends(get_db)
):
    """Mark a leaver exit checklist item as completed."""
    item = db.query(ExitChecklist).filter(ExitChecklist.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Checklist item not found")
    item.is_completed = True
    item.completed_at = datetime.utcnow()
    item.completed_by = body.get("completed_by", "hr_staff")
    db.commit()
    return {"status": "updated", "item_id": item_id, "item": item.item}


@router.post("/{employee_id}/delete-from-azure")
def delete_from_azure(
    employee_id: int,
    body: DeleteFromAzureRequest,
    db: Session = Depends(get_db)
):
    """
    Final step of offboarding: permanently delete user from Azure AD.
    Should only be called after:
      ✅ Account disabled
      ✅ Assets recovered
      ✅ Mailbox archived
    """
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    if emp.status != "disabled":
        raise HTTPException(status_code=400, detail=f"{emp.name} is not offboarded yet")

    azure_id = emp.azure_object_id
    if not azure_id or azure_id.startswith("sim-"):
        return {"status": "skipped", "message": "No real Azure Object ID — skipping deletion (simulation mode)"}

    # Check assets still pending
    pending_assets = [a for a in emp.assets if a.is_active]
    if pending_assets:
        return {
            "status": "blocked",
            "message": f"Cannot delete — {len(pending_assets)} asset(s) still pending return. Mark them returned first.",
            "pending_assets": [{"tag": a.asset.asset_tag, "type": a.asset.asset_type} for a in pending_assets if a.asset]
        }

    from engines.microsoft_graph import archive_mailbox, delete_azure_user

    # 1. Archive mailbox — NON-FATAL: warnings are logged but do not block deletion
    arch = archive_mailbox(azure_id, emp.name)
    try:
        db.add(AuditLog(employee_id=emp.id, action="MAILBOX_ARCHIVED",
                        system="Microsoft 365", performed_by=body.confirmed_by,
                        status=arch.get("status", "warning"),
                        details=arch.get("message", str(arch))))
    except Exception:
        pass

    # 2. Delete from Azure AD — this is the critical step
    result = delete_azure_user(azure_id, emp.name)
    try:
        db.add(AuditLog(employee_id=emp.id, action="AZURE_USER_DELETED",
                        system="Azure AD", performed_by=body.confirmed_by,
                        status=result.get("status", "failed"),
                        details=result.get("message", result.get("error", ""))))
    except Exception:
        pass

    # Update DB regardless of soft vs hard delete — both count as deleted
    if result.get("status") == "success":
        emp.azure_object_id = None
        emp.azure_upn       = None
        emp.status          = "deleted"
    
    db.commit()
    return {
        "status": result.get("status", "failed"),
        "message": result.get("message") or result.get("error"),
        "employee": emp.name,
        "hard_deleted": result.get("hard_deleted", False),
        "soft_deleted": result.get("soft_deleted", False),
        "archive_result": arch,
        "delete_result": result,
    }
