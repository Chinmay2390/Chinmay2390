"""routers/approvals.py"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from database import get_db
from models import ApprovalRequest

router = APIRouter(prefix="/approvals", tags=["approvals"])

class ApprovalAction(BaseModel):
    action: str            # approved | rejected
    notes: Optional[str] = ""
    approver: Optional[str] = "hr_director"

@router.get("/")
def list_approvals(db: Session = Depends(get_db)):
    rows = db.query(ApprovalRequest).order_by(ApprovalRequest.created_at.desc()).all()
    return [{
        "id": a.id,
        "employee_name": a.employee.name if a.employee else "N/A",
        "employee_id":   a.employee.employee_id if a.employee else "N/A",
        "action_type":   a.action_type,
        "requested_by":  a.requested_by,
        "approver":      a.approver,
        "status":        a.status,
        "reason":        a.reason,
        "notes":         a.notes,
        "created_at":    a.created_at.isoformat(),
        "resolved_at":   a.resolved_at.isoformat() if a.resolved_at else None,
    } for a in rows]

@router.patch("/{approval_id}")
def act(approval_id: int, req: ApprovalAction, db: Session = Depends(get_db)):
    a = db.query(ApprovalRequest).filter(ApprovalRequest.id == approval_id).first()
    if not a:
        return {"error": "Not found"}
    if a.status != "pending":
        return {"error": f"Already {a.status}"}

    a.status      = req.action
    a.notes       = req.notes
    a.approver    = req.approver
    a.resolved_at = datetime.utcnow()
    db.commit()

    out = {"status": req.action, "approval_id": approval_id}
    if req.action == "approved" and a.action_type == "onboard":
        from engines.onboarding import execute_approved_onboarding
        out["execution"] = execute_approved_onboarding(db, approval_id, req.approver)
    return out
