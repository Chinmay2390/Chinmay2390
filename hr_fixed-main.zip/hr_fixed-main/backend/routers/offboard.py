"""
routers/offboard.py — Offboarding endpoints
FIX: checklist PATCH route must come BEFORE /{employee_id} routes
     otherwise FastAPI matches 'checklist' as an employee_id integer and fails
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from database import get_db
from models import Employee
from engines.offboarding import (
    offboard_employee, get_exit_checklist,
    complete_checklist_item, get_incomplete_offboardings
)

router = APIRouter(prefix="/offboard", tags=["offboarding"])


class OffboardRequest(BaseModel):
    last_day: str
    reason: str = "resignation"
    performed_by: str = "hr_system"
    azure_object_id: Optional[str] = None


class ChecklistCompleteRequest(BaseModel):
    completed_by: str = "hr_system"


# ── STATIC routes FIRST (before any /{param} routes) ─────────────

@router.get("/active")
def list_active_employees(db: Session = Depends(get_db)):
    """List all active employees available for offboarding."""
    emps = db.query(Employee).filter(Employee.status == "active").all()
    return [
        {
            "id": e.id,
            "employee_id": e.employee_id,
            "name": e.name,
            "email": e.email,
            "department": e.department,
            "role": e.role_obj.name if e.role_obj else None,
            "location": e.location,
        }
        for e in emps
    ]


@router.get("/alerts")
def offboard_alerts(db: Session = Depends(get_db)):
    """Employees offboarded but with incomplete checklists."""
    return get_incomplete_offboardings(db)


# ── CHECKLIST item PATCH — must come BEFORE /{employee_id} ───────

@router.patch("/checklist/{item_id}")
def mark_checklist_item(
    item_id: int,
    body: ChecklistCompleteRequest,
    db: Session = Depends(get_db)
):
    """Mark a single exit checklist item as completed."""
    return complete_checklist_item(db, item_id, body.completed_by)


# ── PARAMETERISED routes LAST ─────────────────────────────────────

@router.post("/{employee_id}")
def trigger_offboarding(
    employee_id: int,
    body: OffboardRequest,
    db: Session = Depends(get_db)
):
    """Trigger full offboarding pipeline for an employee."""
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail=f"Employee {employee_id} not found")

    return offboard_employee(
        db,
        employee_id=employee_id,
        last_day=body.last_day,
        reason=body.reason,
        performed_by=body.performed_by,
        azure_object_id=body.azure_object_id,
    )


@router.get("/{employee_id}/checklist")
def fetch_checklist(employee_id: int, db: Session = Depends(get_db)):
    """Get exit checklist for an offboarded employee."""
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    items = get_exit_checklist(db, employee_id)
    if not items:
        return {
            "employee_id": employee_id,
            "employee_name": emp.name,
            "message": "No exit checklist found — offboard first",
            "items": [],
            "total": 0,
            "completed": 0,
            "auto_completed": 0,
            "progress_pct": 0,
        }

    total     = len(items)
    completed = sum(1 for i in items if i["is_completed"])
    auto_done = sum(1 for i in items if i.get("auto"))
    return {
        "employee_id":    employee_id,
        "employee_name":  emp.name,
        "items":          items,
        "total":          total,
        "completed":      completed,
        "auto_completed": auto_done,
        "progress_pct":   round(completed / total * 100) if total else 0,
    }


@router.get("/{employee_id}/risk")
def get_risk(employee_id: int, db: Session = Depends(get_db)):
    """Run AI risk analysis for an employee (pre-offboarding)."""
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    from engines.risk_analyzer import analyze_risk
    return analyze_risk(emp, db)
