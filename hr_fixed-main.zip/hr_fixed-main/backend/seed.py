import json, os, uuid
from datetime import datetime
from database import SessionLocal, engine
from models import Base, Role, RolePermission, Employee, EmployeeAccess, Asset, AssetAssignment, AuditLog, M365Access

DATA_FILE = os.path.join(os.path.dirname(__file__), "../data/dummy_data.json")

def seed_data(db):
    if db.query(Employee).count() > 0:
        return

    try:
        with open(DATA_FILE) as f:
            data = json.load(f)
    except Exception:
        data = {}

    # Roles
    roles_data = data.get("roles", [
        {"id":1,"name":"admin",     "level":"high",   "description":"Full administrator","permissions":{"Active Directory":"full_control","AWS":"admin","GitHub":"admin","Jira":"admin","HRMS":"admin","Slack":"admin","Email":"admin","VPN":"admin"}},
        {"id":2,"name":"developer", "level":"medium", "description":"Software developer","permissions":{"GitHub":"write","AWS":"developer","Jira":"write","Slack":"write","Email":"standard","VPN":"read"}},
        {"id":3,"name":"hr_manager","level":"medium", "description":"HR operations",     "permissions":{"HRMS":"full_access","Slack":"write","Email":"standard"}},
        {"id":4,"name":"finance",   "level":"high",   "description":"Finance team",       "permissions":{"Finance System":"full_access","Slack":"write","Email":"standard"}},
        {"id":5,"name":"sales",     "level":"standard","description":"Sales team",        "permissions":{"CRM":"write","Slack":"write","Email":"standard"}},
        {"id":6,"name":"intern",    "level":"low",    "description":"Intern access",      "permissions":{"GitHub":"read","Slack":"read","Email":"basic"}},
    ])

    role_map = {}
    for rd in roles_data:
        role = db.query(Role).filter(Role.name == rd["name"]).first()
        if not role:
            role = Role(name=rd["name"], level=rd.get("level","standard"), description=rd.get("description",""))
            db.add(role); db.flush()
            for sys, perm in rd.get("permissions", {}).items():
                db.add(RolePermission(role_id=role.id, system=sys, permission=perm))
        role_map[rd["name"]] = role

    # Assets
    asset_specs = [
        ("LAPTOP","Dell XPS 15","SN-001"),("LAPTOP","Dell XPS 15","SN-002"),
        ("LAPTOP","MacBook Pro","SN-003"),("LAPTOP","MacBook Pro","SN-004"),
        ("LAPTOP","HP EliteBook","SN-005"),("LAPTOP","HP EliteBook","SN-006"),
        ("ID Card","Standard","ID-001"),("ID Card","Standard","ID-002"),
        ("ID Card","Standard","ID-003"),("ID Card","Standard","ID-004"),
        ("VPN Token","RSA SecurID","VPN-001"),("VPN Token","RSA SecurID","VPN-002"),
        ("Access Card","Proximity","AC-001"),("Access Card","Proximity","AC-002"),
        ("Mobile Device","iPhone 14","MOB-001"),
    ]
    for i, (atype, model, sn) in enumerate(asset_specs, 1):
        tag = f"ASSET-{str(i).zfill(3)}"
        if not db.query(Asset).filter(Asset.asset_tag == tag).first():
            db.add(Asset(asset_tag=tag, asset_type=atype, model=model, serial_no=sn, status="available"))

    # Sample employees
    samples = [
        ("Samiksha Chavan",  "Engineering",   "developer",  "Senior Developer",  "Tushar Kamlaskar", "Pune",   "IN"),
        ("Rahul Sharma",     "IT-Admin",      "admin",      "IT Administrator",  "Samiksha Chavan",  "Mumbai", "IN"),
        ("Priya Desai",      "HR",            "hr_manager", "HR Manager",        "Director HR",      "Pune",   "IN"),
        ("Amit Kulkarni",    "Finance",       "finance",    "Finance Analyst",   "CFO",              "Mumbai", "IN"),
        ("Alice Johnson",    "Sales",         "sales",      "Sales Executive",   "Sales Manager",    "Delhi",  "IN"),
        ("Bob Williams",     "Engineering",   "developer",  "Junior Developer",  "Samiksha Chavan",  "Pune",   "IN"),
    ]
    depts_map = {"Engineering":"Engineering","IT-Admin":"IT-Admin","HR":"HR","Finance":"Finance","Sales":"Sales"}
    for name, dept, role_name, desig, mgr, loc, region in samples:
        role = role_map.get(role_name)
        if not role: continue
        email = name.lower().replace(" ",".")+"@techcorp.com"
        emp_id = f"EMP-{datetime.now().year}-{str(uuid.uuid4())[:6].upper()}"
        emp = Employee(
            employee_id=emp_id, name=name, email=email, department=dept,
            designation=desig, role_id=role.id, manager=mgr, location=loc,
            region=region, ad_username=name.lower().replace(" ","."),
            azure_object_id=f"sim-{str(uuid.uuid4())[:8]}",
            azure_upn=f"{name.lower().replace(' ','.')}@techcorp.onmicrosoft.com",
            status="active", mailbox_status="provisioned",
            teams_status="provisioned", sharepoint_status="provisioned",
            license_status="assigned", license_sku="M365_BUSINESS_STANDARD"
        )
        db.add(emp); db.flush()
        for perm in role.permissions:
            db.add(EmployeeAccess(employee_id=emp.id, system=perm.system, access_level=perm.permission))
        db.add(AuditLog(employee_id=emp.id, action="ONBOARD_COMPLETE", system="Seed",
                        performed_by="seed", status="success", details=f"Seeded: {name}"))
    db.commit()
    print("✅ Database seeded")
