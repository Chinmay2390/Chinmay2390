// src/pages/EmailLogs.jsx
import { useEffect, useState } from 'react'
import { Mail, RefreshCw, ChevronDown, ChevronUp } from 'lucide-react'
import { getEmailLogs } from '../api'
import { PageHeader, LoadingSpinner, EmptyState } from '../components/ui'

export default function EmailLogs() {
  const [emails, setEmails]   = useState([])
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState(null)

  const fetch = () => {
    setLoading(true)
    getEmailLogs().then(r => setEmails(r.data)).finally(() => setLoading(false))
  }
  useEffect(() => { fetch() }, [])

  return (
    <div className="fade-in space-y-5">
      <PageHeader title="Email Logs" subtitle="All simulated emails sent by the system">
        <button onClick={fetch} className="btn-secondary flex items-center gap-2">
          <RefreshCw size={14} /> Refresh
        </button>
      </PageHeader>

      <div className="card overflow-hidden">
        {loading ? <LoadingSpinner /> : emails.length === 0 ? (
          <EmptyState icon={Mail} title="No emails sent yet" subtitle="Emails appear here after onboarding" />
        ) : (
          <div className="divide-y divide-slate-50">
            {emails.map(e => (
              <div key={e.id} className="px-5 py-4">
                <div
                  className="flex items-start justify-between cursor-pointer"
                  onClick={() => setExpanded(expanded === e.id ? null : e.id)}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Mail size={15} className="text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium text-slate-800 text-sm">{e.subject}</p>
                      <p className="text-xs text-slate-500 mt-0.5">To: {e.to} · {new Date(e.sent_at).toLocaleString()}</p>
                      <span className="text-xs bg-slate-100 text-slate-500 px-2 py-0.5 rounded mt-1 inline-block">
                        {e.status}
                      </span>
                    </div>
                  </div>
                  {expanded === e.id
                    ? <ChevronUp size={16} className="text-slate-400 flex-shrink-0 mt-1" />
                    : <ChevronDown size={16} className="text-slate-400 flex-shrink-0 mt-1" />}
                </div>
                {expanded === e.id && (
                  <pre className="mt-4 bg-slate-50 rounded-xl p-4 text-xs text-slate-600 whitespace-pre-wrap font-mono border border-slate-100">
                    {e.body}
                  </pre>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
