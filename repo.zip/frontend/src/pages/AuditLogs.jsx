import { useEffect, useState } from 'react'
import { ClipboardList, RefreshCw, Search, Download } from 'lucide-react'
import { getAuditLogs } from '../api'
import { PageHeader, LoadingSpinner, EmptyState } from '../components/ui'

export default function AuditLogs() {
  const [logs, setLogs]       = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch]   = useState('')
  const [error, setError]     = useState(null)

  const fetch = () => {
    setLoading(true)
    setError(null)
    getAuditLogs({ limit: 500 })
      .then(r => setLogs(Array.isArray(r.data) ? r.data : []))
      .catch(e => setError(e.response?.data?.detail || 'Failed to load logs'))
      .finally(() => setLoading(false))
  }
  useEffect(() => { fetch() }, [])

  const filtered = logs.filter(l =>
    !search ||
    l.action?.toLowerCase().includes(search.toLowerCase()) ||
    l.employee_name?.toLowerCase().includes(search.toLowerCase()) ||
    l.system?.toLowerCase().includes(search.toLowerCase()) ||
    l.details?.toLowerCase().includes(search.toLowerCase())
  )

  const statusColor = s =>
    s === 'success' ? 'bg-emerald-100 text-emerald-700' :
    s === 'warning' ? 'bg-amber-100 text-amber-700' :
    s === 'pending' ? 'bg-blue-100 text-blue-700' : 'bg-red-100 text-red-700'

  const exportCSV = () => {
    const rows = [['Timestamp','Employee','Action','System','Status','Details'],
      ...filtered.map(l => [l.timestamp, l.employee_name, l.action, l.system, l.status, `"${(l.details||'').replace(/"/g,"'")}"`])]
    const csv = rows.map(r => r.join(',')).join('\n')
    const a = document.createElement('a')
    a.href = `data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`
    a.download = `audit-logs-${new Date().toISOString().slice(0,10)}.csv`
    a.click()
  }

  return (
    <div className="fade-in space-y-5">
      <PageHeader title="Audit Logs" subtitle={`${filtered.length} entries`}>
        <button onClick={exportCSV} className="btn-secondary flex items-center gap-2">
          <Download size={14} /> Export CSV
        </button>
        <button onClick={fetch} className="btn-secondary flex items-center gap-2">
          <RefreshCw size={14} /> Refresh
        </button>
      </PageHeader>

      <div className="card p-4">
        <div className="relative">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className="input pl-9" placeholder="Filter by action, employee, system, details..."
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3">
          ⚠️ {error} — <button onClick={fetch} className="underline ml-1">Retry</button>
        </div>
      )}

      <div className="card overflow-hidden">
        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={ClipboardList} title="No logs found"
            subtitle={search ? 'Try a different search term' : 'Audit events from onboarding, offboarding and transfers will appear here'} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50/60 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-medium text-slate-500">Timestamp</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Employee</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Action</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">System</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">By</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Status</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Details</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(l => (
                  <tr key={l.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="px-5 py-3 text-xs text-slate-400 whitespace-nowrap">
                      {new Date(l.timestamp).toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-slate-700 font-medium text-xs">{l.employee_name}</p>
                      {l.employee_id && <p className="text-slate-400 text-xs font-mono">{l.employee_id}</p>}
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                        {l.action}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500">{l.system}</td>
                    <td className="px-4 py-3 text-xs text-slate-500">{l.performed_by}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor(l.status)}`}>
                        {l.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500 max-w-xs truncate" title={l.details}>{l.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
