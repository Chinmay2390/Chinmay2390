import { useState } from 'react'
import { onboardEmployee } from '../api'
import toast from 'react-hot-toast'
import { UserPlus, ChevronDown, Loader2, CheckCircle2, Cloud, Shield, Monitor, Mail, Users, Globe } from 'lucide-react'

const ROLES = ['developer','admin','hr_manager','finance','sales','intern']
const DEPTS = ['Engineering','IT-Admin','HR','Finance','Sales','Operations','Cybersecurity','Marketing','Legal','Internship']
const REGIONS = [
  {code:'IN', label:'India'},
  {code:'US', label:'USA'},
  {code:'GB', label:'UK'},
  {code:'SG', label:'Singapore'},
  {code:'AU', label:'Australia'},
]

const DEPT_PREVIEW = {
  'Engineering':   {groups:['SG-Engineering','SG-GitHub-Users','SG-VPN-Users'],teams:['Engineering Hub'],sp:['Engineering Documents']},
  'IT-Admin':      {groups:['SG-IT-Admins','SG-All-Admin','SG-VPN-Users'],teams:['IT Operations'],sp:['IT Admin Portal']},
  'HR':            {groups:['SG-HR-Team','SG-HRMS-Access'],teams:['HR Team'],sp:['HR Policies']},
  'Finance':       {groups:['SG-Finance-Team','SG-Finance-Secure'],teams:['Finance Team'],sp:['Finance Reports']},
  'Sales':         {groups:['SG-Sales-Team','SG-CRM-Access'],teams:['Sales Team'],sp:['Sales Playbook']},
  'Cybersecurity': {groups:['SG-Security-Ops','SG-SIEM-Access','SG-VPN-Users'],teams:['SOC Team'],sp:['Security Runbooks']},
}

const APPROVAL_ROLES = ['admin','finance','hr_manager']

export default function OnboardForm() {
  const [form, setForm] = useState({
    name:'', department:'Engineering', role_name:'developer', designation:'',
    manager:'', location:'Head Office', region:'IN', phone:'',
    emergency_contact:'', joining_date:''
  })
  const [loading, setLoading] = useState(false)
  const [result, setResult]   = useState(null)

  const f = (k, v) => setForm(p => ({...p, [k]: v}))
  const needsApproval = APPROVAL_ROLES.includes(form.role_name)
  const preview = DEPT_PREVIEW[form.department] || {groups:['SG-All-Staff'], teams:[], sp:[]}

  const handleSubmit = async () => {
    if (!form.name.trim()) return toast.error('Name is required')
    if (!form.department)  return toast.error('Department is required')
    setLoading(true)
    try {
      const r = await onboardEmployee(form)
      setResult(r.data)
      toast.success(r.data.status === 'pending_approval' ? 'Approval request submitted' : `${form.name} onboarded ✅`)
    } catch (e) { toast.error(e.response?.data?.detail || 'Onboarding failed') }
    finally { setLoading(false) }
  }

  if (result) return (
    <div className="max-w-2xl mx-auto">
      <div className={`rounded-2xl border p-8 space-y-5 ${result.status === 'pending_approval' ? 'bg-amber-50 border-amber-200' : 'bg-green-50 border-green-200'}`}>
        <div className="flex items-center gap-3">
          <CheckCircle2 size={24} className={result.status === 'pending_approval' ? 'text-amber-600' : 'text-green-600'} />
          <h2 className="text-xl font-bold text-slate-900">
            {result.status === 'pending_approval' ? 'Approval Requested' : 'Onboarding Complete'}
          </h2>
        </div>

        {result.status === 'pending_approval' ? (
          <p className="text-slate-700">Role <strong>{form.role_name}</strong> requires HR Director approval. The request has been submitted and the team will be notified.</p>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              {[['Employee ID', result.employee_id], ['Email', result.email],
                ['Role', result.role], ['Department', result.department],
                ['Azure Object ID', result.azure_ad?.azure_object_id?.slice(0,16)+'...'],
                ['Temp Password', result.azure_ad?.temp_password],
              ].map(([k,v]) => (
                <div key={k} className="bg-white rounded-xl p-3">
                  <p className="text-xs text-slate-400">{k}</p>
                  <p className="font-semibold text-slate-800 font-mono text-xs mt-0.5">{v || '—'}</p>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                {label:'Azure AD', items: result.azure_ad?.steps?.length + ' steps', icon: Cloud, color:'blue'},
                {label:'Systems', items: result.systems_provisioned?.length + ' provisioned', icon: Shield, color:'green'},
                {label:'Assets', items: result.assets_assigned?.map(a=>a.type).join(', '), icon: Monitor, color:'purple'},
              ].map(({label, items, icon: Icon, color}) => (
                <div key={label} className={`bg-${color}-50 border border-${color}-200 rounded-xl p-3 text-center`}>
                  <Icon size={16} className={`text-${color}-600 mx-auto mb-1`} />
                  <p className="text-xs font-semibold text-slate-700">{label}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{items}</p>
                </div>
              ))}
            </div>
            {result.azure_ad?.steps && (
              <div className="space-y-1">
                <p className="text-xs font-semibold text-slate-600">Azure AD Steps</p>
                {result.azure_ad.steps.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <span>{s.status === 'success' ? '✅' : '❌'}</span>
                    <span className="text-slate-600 capitalize">{s.step?.replace(/_/g,' ')}</span>
                    <span className={`ml-auto ${s.real ? 'text-green-600' : 'text-amber-600'}`}>[{s.real ? 'REAL' : 'SIM'}]</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        <button onClick={() => { setResult(null); setForm({name:'',department:'Engineering',role_name:'developer',designation:'',manager:'',location:'Head Office',region:'IN',phone:'',emergency_contact:'',joining_date:''}) }}
          className="w-full border border-slate-300 text-slate-700 py-2.5 rounded-xl font-medium hover:bg-white transition-all">
          + Onboard Another Employee
        </button>
      </div>
    </div>
  )

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Form */}
      <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
            <UserPlus size={18} className="text-blue-600" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900">New Employee Onboarding</h1>
            <p className="text-sm text-slate-500">Azure AD + M365 automated provisioning</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-1">Full Name *</label>
            <input value={form.name} onChange={e => f('name', e.target.value)} placeholder="Alice Johnson"
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Designation</label>
            <input value={form.designation} onChange={e => f('designation', e.target.value)} placeholder="Software Engineer"
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Manager</label>
            <input value={form.manager} onChange={e => f('manager', e.target.value)} placeholder="Manager display name"
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Department *</label>
            <div className="relative">
              <select value={form.department} onChange={e => f('department', e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-400">
                {DEPTS.map(d => <option key={d}>{d}</option>)}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Role *</label>
            <div className="relative">
              <select value={form.role_name} onChange={e => f('role_name', e.target.value)}
                className={`w-full border rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-400 ${needsApproval ? 'border-amber-400' : 'border-slate-200'}`}>
                {ROLES.map(r => <option key={r}>{r}</option>)}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
            {needsApproval && <p className="text-xs text-amber-600 mt-1">⚠ Requires HR Director approval</p>}
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Location</label>
            <input value={form.location} onChange={e => f('location', e.target.value)} placeholder="Head Office / Pune / Mumbai"
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Region</label>
            <div className="relative">
              <select value={form.region} onChange={e => f('region', e.target.value)}
                className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm appearance-none bg-white focus:outline-none focus:ring-2 focus:ring-blue-400">
                {REGIONS.map(r => <option key={r.code} value={r.code}>{r.label}</option>)}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Joining Date</label>
            <input type="date" value={form.joining_date} onChange={e => f('joining_date', e.target.value)}
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Phone</label>
            <input value={form.phone} onChange={e => f('phone', e.target.value)} placeholder="+91-9999999999"
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Emergency Contact</label>
            <input value={form.emergency_contact} onChange={e => f('emergency_contact', e.target.value)} placeholder="Name / Phone"
              className="w-full border border-slate-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400" />
          </div>
        </div>

        <button onClick={handleSubmit} disabled={loading || !form.name}
          className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-semibold py-3 rounded-xl flex items-center justify-center gap-2 transition-all">
          {loading ? <><Loader2 size={16} className="animate-spin" />Processing…</> : <><Cloud size={16} />Onboard in Azure AD</>}
        </button>
      </div>

      {/* Preview sidebar */}
      <div className="space-y-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-5">
          <h3 className="font-semibold text-slate-800 text-sm mb-4">Access Preview</h3>
          <div className="space-y-4">
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1"><Shield size={11} /> SECURITY GROUPS</p>
              <div className="flex flex-wrap gap-1.5">
                {preview.groups.map(g => <span key={g} className="text-xs bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">{g}</span>)}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1"><Users size={11} /> TEAMS CHANNELS</p>
              <div className="flex flex-wrap gap-1.5">
                {preview.teams.map(t => <span key={t} className="text-xs bg-purple-50 text-purple-700 px-2 py-0.5 rounded-full">{t}</span>)}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1"><Globe size={11} /> SHAREPOINT SITES</p>
              <div className="flex flex-wrap gap-1.5">
                {preview.sp.map(s => <span key={s} className="text-xs bg-green-50 text-green-700 px-2 py-0.5 rounded-full">{s}</span>)}
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1"><Mail size={11} /> EXCHANGE</p>
              <span className="text-xs bg-orange-50 text-orange-700 px-2 py-0.5 rounded-full">Personal mailbox + M365 license</span>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1"><Monitor size={11} /> ASSETS</p>
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full mr-1">Laptop</span>
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">ID Card</span>
            </div>
          </div>
        </div>
        <div className="bg-slate-50 rounded-2xl border border-slate-200 p-4 text-xs text-slate-600 space-y-1.5">
          <p className="font-semibold text-slate-700">Automated Pipeline</p>
          {['Create Azure AD user account','Assign M365 license','Exchange mailbox provisioned','Add to Teams channels','Grant SharePoint access','Add to security groups','Set manager link','Provision RBAC access','Auto-assign assets','Send welcome email'].map(step => (
            <p key={step} className="flex items-center gap-1.5"><span className="text-green-500">✓</span>{step}</p>
          ))}
        </div>
      </div>
    </div>
  )
}
