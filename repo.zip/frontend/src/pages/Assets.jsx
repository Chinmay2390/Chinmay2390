// src/pages/Assets.jsx
import { useEffect, useState } from 'react'
import { Monitor, Laptop, CreditCard, Phone, RefreshCw } from 'lucide-react'
import { getAssets, getAssetSummary } from '../api'
import { PageHeader, LoadingSpinner, EmptyState } from '../components/ui'

const typeIcon = (t) => {
  if (t === 'Laptop') return Laptop
  if (t === 'ID Card') return CreditCard
  if (t === 'Mobile') return Phone
  return Monitor
}

export default function Assets() {
  const [assets, setAssets]   = useState([])
  const [summary, setSummary] = useState(null)
  const [loading, setLoading] = useState(true)
  const [filter, setFilter]   = useState('all')

  const fetch = () => {
    setLoading(true)
    Promise.all([getAssets(), getAssetSummary()])
      .then(([a, s]) => { setAssets(a.data); setSummary(s.data) })
      .finally(() => setLoading(false))
  }
  useEffect(() => { fetch() }, [])

  const filtered = assets.filter(a => filter === 'all' || a.status === filter)

  const statusColor = s =>
    s === 'available' ? 'bg-emerald-100 text-emerald-700' :
    s === 'assigned'  ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600'

  return (
    <div className="fade-in space-y-5">
      <PageHeader title="Asset Tracker" subtitle="Track laptops, ID cards and equipment">
        <button onClick={fetch} className="btn-secondary flex items-center gap-2">
          <RefreshCw size={14} /> Refresh
        </button>
      </PageHeader>

      {/* Summary cards */}
      {summary?.by_type && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Object.entries(summary.by_type).map(([type, c]) => {
            const Icon = typeIcon(type)
            return (
              <div key={type} className="card p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Icon size={16} className="text-slate-500" />
                  <p className="text-sm font-medium text-slate-700">{type}</p>
                </div>
                <p className="text-2xl font-bold text-slate-900">{c.total}</p>
                <div className="flex gap-3 mt-1.5">
                  <span className="text-xs text-emerald-600">{c.available} free</span>
                  <span className="text-xs text-blue-600">{c.assigned} used</span>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Filter tabs */}
      <div className="flex gap-2">
        {['all','available','assigned'].map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              filter === f ? 'bg-blue-600 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}>
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Asset table */}
      <div className="card overflow-hidden">
        {loading ? <LoadingSpinner /> : filtered.length === 0 ? (
          <EmptyState icon={Monitor} title="No assets found" />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50/60 border-b border-slate-100">
                  <th className="text-left px-5 py-3 font-medium text-slate-500">Asset Tag</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Type</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Model</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Serial</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Status</th>
                  <th className="text-left px-4 py-3 font-medium text-slate-500">Assigned To</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(a => (
                  <tr key={a.id} className="border-b border-slate-50 hover:bg-slate-50/50">
                    <td className="px-5 py-3 font-mono text-xs text-slate-600">{a.tag}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        {(() => { const I = typeIcon(a.type); return <I size={13} className="text-slate-400" /> })()}
                        <span className="text-slate-700 text-xs">{a.type}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-600 text-xs">{a.model}</td>
                    <td className="px-4 py-3 font-mono text-xs text-slate-400">{a.serial}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColor(a.status)}`}>
                        {a.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-500">{a.assigned_to || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
