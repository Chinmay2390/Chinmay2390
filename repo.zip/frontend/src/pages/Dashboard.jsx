import { useState, useEffect } from 'react'
import { getEmployees, getApprovals } from '../api'
import { Users, UserPlus, UserX, Clock, CheckCircle2, AlertCircle, 
         TrendingUp, Shield, Mail, Monitor, Database, Cloud, ArrowRight } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'
import { useNavigate } from 'react-router-dom'

const DEPT_COLORS = ['#3B82F6','#8B5CF6','#EC4899','#F59E0B','#10B981','#EF4444','#06B6D4','#84CC16']

const StatusDot = ({ status }) => {
  const colors = { provisioned:'bg-green-500', pending:'bg-amber-400', failed:'bg-red-500', active:'bg-green-500', disabled:'bg-slate-400' }
  return <span className={`inline-block w-2 h-2 rounded-full ${colors[status]||'bg-slate-300'}`} />
}

export default function Dashboard() {
  const [employees, setEmployees] = useState([])
  const [approvals, setApprovals] = useState([])
  const [loading,   setLoading]   = useState(true)
  const nav = useNavigate()

  useEffect(() => {
    Promise.all([getEmployees(), getApprovals()]).then(([e,a]) => {
      setEmployees(e.data?.employees || e.data || [])
      setApprovals(a.data?.approvals || a.data || [])
    }).finally(() => setLoading(false))
  }, [])

  const active   = employees.filter(e => e.status === 'active')
  const pending  = employees.filter(e => e.status === 'pending_approval')
  const disabled = employees.filter(e => e.status === 'disabled')
  const pendingApprovals = approvals.filter(a => a.status === 'pending')

  const byDept = Object.entries(employees.reduce((acc,e) => {
    const d = e.department||'Unknown'
    acc[d] = (acc[d]||0)+1; return acc
  }, {})).map(([dept,count]) => ({dept,count})).sort((a,b)=>b.count-a.count)

  const byRole = Object.entries(employees.reduce((acc,e) => {
    const r = e.role||'Unknown'
    acc[r] = (acc[r]||0)+1; return acc
  }, {})).map(([role,count]) => ({name:role,value:count}))

  const recent = [...employees].sort((a,b)=>new Date(b.created_at||0)-new Date(a.created_at||0)).slice(0,6)

  const StatCard = ({icon:Icon, label, value, sub, color, onClick}) => (
    <div onClick={onClick} className={`bg-white rounded-2xl border border-slate-100 p-5 shadow-sm hover:shadow-md transition-all ${onClick?'cursor-pointer hover:border-blue-200':''}`}>
      <div className="flex items-center justify-between mb-3">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${color}`}>
          <Icon size={18} className="text-white" />
        </div>
        {onClick && <ArrowRight size={14} className="text-slate-300" />}
      </div>
      <p className="text-2xl font-bold text-slate-900">{loading?'—':value}</p>
      <p className="text-sm font-medium text-slate-700 mt-0.5">{label}</p>
      {sub && <p className="text-xs text-slate-400 mt-0.5">{sub}</p>}
    </div>
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">JML Operations Dashboard</h1>
        <p className="text-sm text-slate-500 mt-1">Joiner · Mover · Leaver — Real-time employee lifecycle overview</p>
      </div>

      {/* Stats Row 1 */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users}     label="Total Employees"     value={employees.length} color="bg-blue-500"   sub={`${active.length} active`} onClick={()=>nav('/employees')} />
        <StatCard icon={UserPlus}  label="Pending Onboarding"  value={pending.length}   color="bg-amber-500"  sub="awaiting approval" onClick={()=>nav('/approvals')} />
        <StatCard icon={Clock}     label="Open Approvals"       value={pendingApprovals.length} color="bg-purple-500" sub="requires action" onClick={()=>nav('/approvals')} />
        <StatCard icon={UserX}     label="Offboarded"          value={disabled.length}  color="bg-red-500"    sub="this period" onClick={()=>nav('/offboard')} />
      </div>

      {/* Azure / M365 Status Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Cloud,    label: 'Azure AD Accounts',   key: 'azure_object_id',   color: 'text-blue-600',   bg: 'bg-blue-50' },
          { icon: Mail,     label: 'Mailboxes Active',     key: 'mailbox_status',    color: 'text-green-600',  bg: 'bg-green-50' },
          { icon: Monitor,  label: 'Teams Provisioned',    key: 'teams_status',      color: 'text-purple-600', bg: 'bg-purple-50' },
          { icon: Shield,   label: 'SharePoint Access',    key: 'sharepoint_status', color: 'text-orange-600', bg: 'bg-orange-50' },
        ].map(({ icon: Icon, label, key, color, bg }) => {
          const count = key === 'azure_object_id'
            ? active.filter(e => e[key]).length
            : active.filter(e => e[key] === 'provisioned').length
          const pct = active.length ? Math.round(count / active.length * 100) : 0
          return (
            <div key={label} className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
              <div className={`w-9 h-9 ${bg} rounded-xl flex items-center justify-center mb-3`}>
                <Icon size={16} className={color} />
              </div>
              <p className="text-xl font-bold text-slate-900">{loading?'—':count}<span className="text-sm font-normal text-slate-400 ml-1">/ {active.length}</span></p>
              <p className="text-sm text-slate-600">{label}</p>
              <div className="h-1.5 bg-slate-100 rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-green-400 rounded-full transition-all" style={{width:`${pct}%`}} />
              </div>
            </div>
          )
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dept bar chart */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
          <h3 className="font-semibold text-slate-800 mb-4 text-sm">Employees by Department</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={byDept} barSize={28}>
              <XAxis dataKey="dept" tick={{fontSize:11}} />
              <YAxis tick={{fontSize:11}} />
              <Tooltip />
              <Bar dataKey="count" radius={[6,6,0,0]}>
                {byDept.map((_,i) => <Cell key={i} fill={DEPT_COLORS[i%DEPT_COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Role pie */}
        <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-sm">
          <h3 className="font-semibold text-slate-800 mb-4 text-sm">By Role</h3>
          <ResponsiveContainer width="100%" height={130}>
            <PieChart>
              <Pie data={byRole} cx="50%" cy="50%" innerRadius={35} outerRadius={60}
                   dataKey="value" nameKey="name">
                {byRole.map((_,i) => <Cell key={i} fill={DEPT_COLORS[i%DEPT_COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1 mt-2">
            {byRole.slice(0,4).map((r,i) => (
              <div key={r.name} className="flex items-center gap-2 text-xs text-slate-600">
                <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{background:DEPT_COLORS[i%DEPT_COLORS.length]}} />
                <span className="capitalize flex-1">{r.name.replace('_',' ')}</span>
                <span className="font-semibold">{r.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent joiners + Pending approvals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent joiners */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <span className="font-semibold text-slate-800 text-sm">Recent Joiners</span>
            <button onClick={()=>nav('/onboard')} className="text-xs text-blue-600 hover:underline flex items-center gap-1">
              Onboard new <ArrowRight size={11} />
            </button>
          </div>
          <div className="divide-y divide-slate-100">
            {loading ? <div className="px-5 py-8 text-center text-slate-400 text-sm">Loading…</div> :
            recent.length === 0 ? <div className="px-5 py-8 text-center text-slate-400 text-sm">No employees yet</div> :
            recent.map(e => (
              <div key={e.id} className="flex items-center gap-3 px-5 py-3">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {(e.name||'?')[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 truncate">{e.name}</p>
                  <p className="text-xs text-slate-400">{e.department} · {e.role}</p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <StatusDot status={e.status} />
                  <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${
                    e.status==='active'?'bg-green-100 text-green-700':
                    e.status==='pending_approval'?'bg-amber-100 text-amber-700':'bg-slate-100 text-slate-500'
                  }`}>{e.status?.replace('_',' ')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pending approvals */}
        <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <span className="font-semibold text-slate-800 text-sm">Pending Approvals</span>
            {pendingApprovals.length > 0 && (
              <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-semibold">
                {pendingApprovals.length} waiting
              </span>
            )}
          </div>
          <div className="divide-y divide-slate-100">
            {loading ? <div className="px-5 py-8 text-center text-slate-400 text-sm">Loading…</div> :
            pendingApprovals.length === 0 ?
              <div className="px-5 py-8 text-center">
                <CheckCircle2 size={28} className="mx-auto mb-2 text-green-400" />
                <p className="text-sm text-slate-500">All caught up! No pending approvals.</p>
              </div> :
            pendingApprovals.slice(0,5).map(a => (
              <div key={a.id} className="px-5 py-3 flex items-start gap-3">
                <AlertCircle size={16} className="text-amber-500 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">{a.reason?.split(' requires')[0] || 'Approval required'}</p>
                  <p className="text-xs text-slate-400">Requested by {a.requested_by} · {new Date(a.created_at).toLocaleDateString()}</p>
                </div>
                <button onClick={()=>nav('/approvals')} className="text-xs text-blue-600 hover:underline whitespace-nowrap">Review →</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
