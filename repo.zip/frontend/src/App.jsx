import { Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import Sidebar    from './components/Sidebar'
import Dashboard  from './pages/Dashboard'
import Employees  from './pages/Employees'
import OnboardForm from './pages/OnboardForm'
import Mover      from './pages/Mover'
import Offboard   from './pages/Offboard'
import Leaver     from './pages/Leaver'
import Approvals  from './pages/Approvals'
import Assets     from './pages/Assets'
import AuditLogs  from './pages/AuditLogs'
import EmailLogs  from './pages/EmailLogs'
import Chatbot    from './pages/Chatbot'
import AzureAD    from './pages/AzureAD'

export default function App() {
  return (
    <>
      <Toaster position="top-right" toastOptions={{ style: { fontSize:'13px', borderRadius:'12px' } }} />
      <div className="flex h-screen bg-slate-50 overflow-hidden">
        <Sidebar />
        <main className="flex-1 overflow-y-auto p-6">
          <Routes>
            <Route path="/"          element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/employees" element={<Employees />} />
            <Route path="/onboard"   element={<OnboardForm />} />
            <Route path="/mover"     element={<Mover />} />
            <Route path="/offboard"  element={<Offboard />} />
            <Route path="/leaver"    element={<Leaver />} />
            <Route path="/approvals" element={<Approvals />} />
            <Route path="/azure"     element={<AzureAD />} />
            <Route path="/assets"    element={<Assets />} />
            <Route path="/logs"      element={<AuditLogs />} />
            <Route path="/emails"    element={<EmailLogs />} />
            <Route path="/chatbot"   element={<Chatbot />} />
          </Routes>
        </main>
      </div>
    </>
  )
}
