from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.orm import Session
from database import get_db
from engines.onboarding import onboard_employee, execute_approved_onboarding

router = APIRouter(prefix="/onboard", tags=["onboarding"])


class OnboardRequest(BaseModel):
    name:              str
    department:        str
    role_name:         str
    designation:       Optional[str] = ""
    manager:           Optional[str] = "TBD"
    location:          Optional[str] = "Head Office"
    region:            Optional[str] = "IN"
    phone:             Optional[str] = ""
    emergency_contact: Optional[str] = ""
    joining_date:      Optional[str] = ""
    performed_by:      Optional[str] = "hr_system"


@router.post("/")
def onboard(req: OnboardRequest, db: Session = Depends(get_db)):
    return onboard_employee(
        db, name=req.name, department=req.department, role_name=req.role_name,
        designation=req.designation or "", manager=req.manager or "TBD",
        location=req.location or "Head Office", region=req.region or "IN",
        phone=req.phone or "", emergency_contact=req.emergency_contact or "",
        joining_date=req.joining_date or "", performed_by=req.performed_by or "hr_system"
    )


@router.post("/execute/{approval_id}")
def execute_approved(approval_id: int, db: Session = Depends(get_db)):
    return execute_approved_onboarding(db, approval_id)
