"""routers/mover.py — fixed: adds /transfer endpoint for frontend"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from database import get_db
from engines.mover import move_employee, get_mover_history

router = APIRouter(prefix="/mover", tags=["mover"])

class MoverRequest(BaseModel):
    to_department:  str
    to_role:        str
    to_manager:     Optional[str] = None
    effective_date: Optional[str] = None
    reason:         str = "Internal transfer"
    performed_by:   str = "hr_system"

class MoverTransferRequest(BaseModel):
    """Frontend sends employee_id in body via /mover/transfer"""
    employee_id:    int
    to_department:  str
    to_role:        str
    to_manager:     Optional[str] = None
    effective_date: Optional[str] = None
    reason:         str = "Internal transfer"
    performed_by:   str = "hr_system"

# ── STATIC routes FIRST ──────────────────────────────────────────

@router.get("/history")
def mover_history(employee_id: Optional[int] = None, db: Session = Depends(get_db)):
    return {"events": get_mover_history(db, employee_id)}

@router.post("/transfer")
def trigger_transfer(body: MoverTransferRequest, db: Session = Depends(get_db)):
    """Body contains employee_id — used by frontend."""
    return move_employee(
        db, body.employee_id, body.to_department, body.to_role,
        body.to_manager, body.effective_date, body.reason, body.performed_by
    )

# ── PARAMETERISED routes LAST ─────────────────────────────────────

@router.post("/{employee_id}")
def trigger_move(employee_id: int, body: MoverRequest, db: Session = Depends(get_db)):
    return move_employee(
        db, employee_id, body.to_department, body.to_role,
        body.to_manager, body.effective_date, body.reason, body.performed_by
    )
