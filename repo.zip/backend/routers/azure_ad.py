"""
routers/azure_ad.py
-------------------
Endpoints for Azure AD management and onboarding testing.
All calls are real when USE_REAL_GRAPH=true, simulated otherwise.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional
from database import get_db
import os

router = APIRouter(prefix="/azure", tags=["azure-ad"])

# ⚠️  FIX: Do NOT read USE_REAL_GRAPH at import time (module level).
# Read it fresh inside each endpoint so .env changes + restart are respected.


class AzureOnboardRequest(BaseModel):
    name:         str
    email:        str
    department:   str
    role:         str
    manager:      Optional[str] = "TBD"
    location:     Optional[str] = "Head Office"
    phone:        Optional[str] = ""


class AzureOffboardRequest(BaseModel):
    azure_object_id: str
    username:        str
    last_day:        Optional[str] = ""


@router.get("/status")
def azure_status():
    """Check if Azure AD connection is configured and live."""
    use_real = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    return {
        "use_real_graph": use_real,
        "tenant_id":     os.getenv("AZURE_TENANT_ID", "not set"),
        "client_id":     os.getenv("AZURE_CLIENT_ID", "not set"),
        "tenant_domain": os.getenv("AZURE_TENANT_DOMAIN", "not set"),
        "mode":          "REAL Azure AD calls" if use_real else "SIMULATED (safe demo)"
    }


@router.get("/test-connection")
def test_connection():
    """Test if the Azure credentials can acquire a token."""
    use_real = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    if not use_real:
        return {"status": "skipped", "message": "USE_REAL_GRAPH=false — set to true to test real connection"}
    try:
        from engines.microsoft_graph import _get_token
        token = _get_token()
        return {"status": "success", "message": "Token acquired — Azure AD connection is working ✅",
                "token_preview": token[:20] + "..."}
    except Exception as e:
        return {"status": "failed", "error": str(e),
                "hint": "Check AZURE_TENANT_ID, AZURE_CLIENT_ID, AZURE_CLIENT_SECRET in .env"}


@router.get("/users")
def list_users(limit: int = 20):
    """List users in Azure AD tenant."""
    from engines.microsoft_graph import list_azure_users
    use_real = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    return {"users": list_azure_users(limit), "real": use_real}


@router.get("/groups")
def list_groups():
    """List security groups in Azure AD tenant."""
    from engines.microsoft_graph import list_azure_groups
    use_real = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    return {"groups": list_azure_groups(), "real": use_real}


@router.get("/user/{upn}")
def get_user(upn: str):
    """Get a specific user by UPN or Object ID."""
    from engines.microsoft_graph import get_user_by_upn
    result = get_user_by_upn(upn)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


@router.post("/onboard")
def azure_onboard(req: AzureOnboardRequest):
    """
    Standalone Azure AD onboarding — does NOT touch the local HR database.
    Use this to test real Azure AD user creation independently.
    """
    from engines.microsoft_graph import run_full_ad_onboarding
    result = run_full_ad_onboarding(
        name=req.name, email=req.email, department=req.department,
        role=req.role, manager=req.manager or "TBD",
        location=req.location or "Head Office", phone=req.phone or ""
    )
    return result


@router.post("/offboard")
def azure_offboard(req: AzureOffboardRequest):
    """
    Standalone Azure AD offboarding — blocks sign-in, revokes sessions, sets OOF.
    Does NOT touch the local HR database.
    """
    from engines.microsoft_graph import run_full_m365_offboarding
    use_real = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    steps = run_full_m365_offboarding(req.azure_object_id, req.username, req.last_day or "today")
    return {
        "status": "success",
        "steps": steps,
        "completed": sum(1 for s in steps if s["status"] == "success"),
        "real": use_real
    }


@router.get("/role-groups")
def role_group_mapping():
    """Show which Azure AD groups are assigned for each HR role."""
    from engines.microsoft_graph import ROLE_GROUPS
    use_real = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    return {"mapping": ROLE_GROUPS, "real": use_real}

@router.get("/resolve/{name}")
def resolve_user(name: str):
    """
    Look up a user in Azure AD by display name and return their real Object ID + UPN.
    Called before offboarding to ensure Graph API calls target the correct account.
    """
    from engines.microsoft_graph import resolve_azure_object_id
    result = resolve_azure_object_id(name=name)
    return result
