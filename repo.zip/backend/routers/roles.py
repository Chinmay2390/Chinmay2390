"""routers/roles.py"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import Role, RolePermission

router = APIRouter(prefix="/roles", tags=["roles"])

@router.get("/")
def list_roles(db: Session = Depends(get_db)):
    roles = db.query(Role).all()
    return [{
        "id":          r.id,
        "name":        r.name,
        "level":       r.level,
        "description": r.description,
        "permissions": [{"system": p.system, "level": p.permission} for p in r.permissions]
    } for r in roles]
