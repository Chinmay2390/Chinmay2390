"""routers/assets.py"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from database import get_db
from models import Asset, AssetAssignment

router = APIRouter(prefix="/assets", tags=["assets"])

@router.get("/")
def list_assets(db: Session = Depends(get_db)):
    assets = db.query(Asset).all()
    return [{
        "id":       a.id,
        "tag":      a.asset_tag,
        "type":     a.asset_type,
        "model":    a.model,
        "serial":   a.serial_no,
        "status":   a.status,
        "assigned_to": (
            db.query(AssetAssignment)
              .filter(AssetAssignment.asset_id == a.id, AssetAssignment.is_active == True)
              .first()
        ) and (
            lambda aa: aa.employee.name if aa and aa.employee else None
        )(db.query(AssetAssignment)
            .filter(AssetAssignment.asset_id == a.id, AssetAssignment.is_active == True)
            .first())
    } for a in assets]

@router.get("/summary")
def asset_summary(db: Session = Depends(get_db)):
    assets = db.query(Asset).all()
    by_type = {}
    for a in assets:
        t = a.asset_type
        if t not in by_type:
            by_type[t] = {"total": 0, "available": 0, "assigned": 0}
        by_type[t]["total"] += 1
        if a.status == "available":
            by_type[t]["available"] += 1
        elif a.status == "assigned":
            by_type[t]["assigned"] += 1
    return {"total": len(assets), "by_type": by_type}
