"""routers/logs.py — audit + email logs. GET / aliases GET /audit"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from database import get_db
from models import AuditLog, EmailLog

router = APIRouter(prefix="/logs", tags=["logs"])

def _format_logs(rows):
    return [{
        "id":           l.id,
        "employee_name": l.employee.name if l.employee else "System",
        "employee_id":   l.employee.employee_id if l.employee else None,
        "action":        l.action,
        "system":        l.system,
        "performed_by":  l.performed_by,
        "status":        l.status,
        "details":       l.details,
        "timestamp":     l.timestamp.isoformat()
    } for l in rows]

@router.get("/")
@router.get("/audit")
def audit_logs(
    limit:       int           = Query(200, le=500),
    employee_id: Optional[int] = Query(None),
    action:      Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    q = db.query(AuditLog).order_by(AuditLog.timestamp.desc())
    if employee_id:
        q = q.filter(AuditLog.employee_id == employee_id)
    if action:
        q = q.filter(AuditLog.action.ilike(f"%{action}%"))
    return _format_logs(q.limit(limit).all())

@router.get("/emails")
def email_logs(limit: int = Query(50, le=200), db: Session = Depends(get_db)):
    rows = db.query(EmailLog).order_by(EmailLog.sent_at.desc()).limit(limit).all()
    return [{
        "id":       e.id,
        "to":       e.to_address,
        "subject":  e.subject,
        "body":     e.body,
        "status":   e.status,
        "employee": e.related_emp,
        "sent_at":  e.sent_at.isoformat()
    } for e in rows]
