"""routers/chatbot.py — prefix /chatbot (fixes 404 in frontend)"""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, List
from database import get_db
from engines.chatbot import chat

router = APIRouter(prefix="/chatbot", tags=["chatbot"])

class ChatReq(BaseModel):
    message: str
    history: Optional[List] = []

@router.post("/")
def chatbot(req: ChatReq, db: Session = Depends(get_db)):
    return chat(req.message, db)
