"""
routers/employees.py  — Employee CRUD + search + stats
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from database import get_db
from models import Employee, Role
from typing import Optional

router = APIRouter(prefix="/employees", tags=["employees"])


def _serialize(e: Employee) -> dict:
    return {
        "id": e.id,
        "employee_id": e.employee_id,
        "name": e.name,
        "email": e.email,
        "department": e.department,
        "designation": e.designation,
        "role": e.role_obj.name if e.role_obj else None,
        "role_level": e.role_obj.level if e.role_obj else None,
        "role_description": e.role_obj.description if e.role_obj else None,
        "manager": e.manager,
        "location": e.location,
        "phone": e.phone,
        "emergency_contact": e.emergency_contact,
        "status": e.status,
        "ad_username": e.ad_username,
        "azure_object_id": e.azure_object_id,
        "azure_upn": e.azure_upn,
        "is_azure_real": bool(e.azure_object_id and not (e.azure_object_id or "").startswith("sim-")),
        "created_at": e.created_at.isoformat() if e.created_at else None,
        "disabled_at": e.disabled_at.isoformat() if e.disabled_at else None,
    }


@router.get("/")
def list_employees(
    search: Optional[str] = Query(None),
    department: Optional[str] = Query(None),
    role: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    q = db.query(Employee).filter(Employee.status != "deleted")
    if search:
        like = f"%{search}%"
        q = q.filter(
            Employee.name.ilike(like) |
            Employee.email.ilike(like) |
            Employee.employee_id.ilike(like) |
            Employee.department.ilike(like)
        )
    if department:
        q = q.filter(Employee.department.ilike(f"%{department}%"))
    if role:
        r = db.query(Role).filter(Role.name == role).first()
        if r:
            q = q.filter(Employee.role_id == r.id)
    if status:
        q = q.filter(Employee.status == status)
    return [_serialize(e) for e in q.order_by(Employee.created_at.desc()).all()]


@router.get("/stats")
def stats(db: Session = Depends(get_db)):
    all_emps = db.query(Employee).all()
    active   = [e for e in all_emps if e.status == "active"]
    by_dept, by_role = {}, {}
    for e in active:
        by_dept[e.department] = by_dept.get(e.department, 0) + 1
        rn = e.role_obj.name if e.role_obj else "unknown"
        by_role[rn] = by_role.get(rn, 0) + 1
    return {
        "total": len(all_emps),
        "active": len(active),
        "pending_approval": sum(1 for e in all_emps if e.status == "pending_approval"),
        "by_department": by_dept,
        "by_role": by_role
    }


@router.get("/{employee_id}")
def get_employee(employee_id: int, db: Session = Depends(get_db)):
    e = db.query(Employee).filter(Employee.id == employee_id).first()
    if not e:
        return {"error": "Not found"}
    data = _serialize(e)
    data["access"] = [
        {"system": a.system, "level": a.access_level, "active": a.is_active}
        for a in e.access_list
    ]
    data["assets"] = [
        {"tag": a.asset.asset_tag, "type": a.asset.asset_type,
         "model": a.asset.model, "active": a.is_active}
        for a in e.assets if a.asset
    ]
    data["logs"] = [
        {"action": l.action, "system": l.system,
         "status": l.status, "time": l.timestamp.isoformat()}
        for l in sorted(e.logs, key=lambda x: x.timestamp, reverse=True)[:15]
    ]
    return data
