"""
Enterprise JML Platform — Database Models
==========================================
SQLite (dev) / Azure SQL (prod) via SQLAlchemy ORM
"""
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text, Float, JSON
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base


# ── Roles ──────────────────────────────────────────────────────
class Role(Base):
    __tablename__ = "roles"
    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(50), unique=True, nullable=False)
    level       = Column(String(20))
    description = Column(String(200))
    employees   = relationship("Employee", back_populates="role_obj")
    permissions = relationship("RolePermission", back_populates="role_obj", cascade="all, delete-orphan")


class RolePermission(Base):
    __tablename__ = "role_permissions"
    id         = Column(Integer, primary_key=True)
    role_id    = Column(Integer, ForeignKey("roles.id"))
    system     = Column(String(100))
    permission = Column(String(50))
    role_obj   = relationship("Role", back_populates="permissions")


# ── Employee Master ────────────────────────────────────────────
class Employee(Base):
    __tablename__ = "employees"
    id                = Column(Integer, primary_key=True, index=True)
    employee_id       = Column(String(30), unique=True, nullable=False)
    name              = Column(String(100), nullable=False)
    email             = Column(String(150), unique=True, nullable=False)
    department        = Column(String(100))
    designation       = Column(String(100))
    role_id           = Column(Integer, ForeignKey("roles.id"))
    manager           = Column(String(100))
    location          = Column(String(100))
    region            = Column(String(50))
    phone             = Column(String(30))
    emergency_contact = Column(String(200))
    status            = Column(String(20), default="active")
    # Azure AD
    ad_username       = Column(String(100))
    azure_object_id   = Column(String(100), nullable=True)
    azure_upn         = Column(String(200), nullable=True)
    azure_groups      = Column(Text, nullable=True)
    # M365 provisioning status
    mailbox_status    = Column(String(30), default="pending")
    teams_status      = Column(String(30), default="pending")
    sharepoint_status = Column(String(30), default="pending")
    license_status    = Column(String(30), default="pending")
    license_sku       = Column(String(100), nullable=True)
    # Dates
    joining_date      = Column(String(20), nullable=True)
    created_at        = Column(DateTime, default=datetime.utcnow)
    disabled_at       = Column(DateTime, nullable=True)

    role_obj    = relationship("Role", back_populates="employees")
    access_list = relationship("EmployeeAccess", back_populates="employee", cascade="all, delete-orphan")
    logs        = relationship("AuditLog", back_populates="employee")
    assets      = relationship("AssetAssignment", back_populates="employee")
    approvals   = relationship("ApprovalRequest", back_populates="employee")
    mover_events = relationship("MoverEvent", back_populates="employee", foreign_keys="MoverEvent.employee_id")
    m365_access = relationship("M365Access", back_populates="employee", cascade="all, delete-orphan")


# ── M365 Access (Exchange, Teams, SharePoint, Shared Mailboxes) ─
class M365Access(Base):
    __tablename__ = "m365_access"
    id              = Column(Integer, primary_key=True)
    employee_id     = Column(Integer, ForeignKey("employees.id"))
    access_type     = Column(String(50))  # exchange|teams|sharepoint|shared_mailbox|license
    resource        = Column(String(200))  # mailbox/site/team name
    permission      = Column(String(50))   # read|write|full_access|member|owner
    is_active       = Column(Boolean, default=True)
    expires_at      = Column(DateTime, nullable=True)  # for temporary access
    granted_at      = Column(DateTime, default=datetime.utcnow)
    granted_by      = Column(String(100))
    employee        = relationship("Employee", back_populates="m365_access")


# ── Employee System Access (RBAC) ──────────────────────────────
class EmployeeAccess(Base):
    __tablename__ = "employee_access"
    id           = Column(Integer, primary_key=True)
    employee_id  = Column(Integer, ForeignKey("employees.id"))
    system       = Column(String(100))
    access_level = Column(String(50))
    is_active    = Column(Boolean, default=True)
    granted_at   = Column(DateTime, default=datetime.utcnow)
    employee     = relationship("Employee", back_populates="access_list")


# ── Assets ────────────────────────────────────────────────────
class Asset(Base):
    __tablename__ = "assets"
    id          = Column(Integer, primary_key=True)
    asset_tag   = Column(String(50), unique=True)
    asset_type  = Column(String(50))
    model       = Column(String(100))
    serial_no   = Column(String(100))
    status      = Column(String(20), default="available")
    assignments = relationship("AssetAssignment", back_populates="asset")


class AssetAssignment(Base):
    __tablename__ = "asset_assignments"
    id          = Column(Integer, primary_key=True)
    asset_id    = Column(Integer, ForeignKey("assets.id"))
    employee_id = Column(Integer, ForeignKey("employees.id"))
    assigned_at = Column(DateTime, default=datetime.utcnow)
    returned_at = Column(DateTime, nullable=True)
    is_active   = Column(Boolean, default=True)
    asset       = relationship("Asset", back_populates="assignments")
    employee    = relationship("Employee", back_populates="assets")


# ── Audit Log ─────────────────────────────────────────────────
class AuditLog(Base):
    __tablename__ = "audit_logs"
    id           = Column(Integer, primary_key=True, index=True)
    employee_id  = Column(Integer, ForeignKey("employees.id"), nullable=True)
    action       = Column(String(100))
    system       = Column(String(100))
    performed_by = Column(String(100), default="system")
    status       = Column(String(20))
    details      = Column(Text)
    timestamp    = Column(DateTime, default=datetime.utcnow)
    employee     = relationship("Employee", back_populates="logs")


# ── Approval Requests ─────────────────────────────────────────
class ApprovalRequest(Base):
    __tablename__ = "approval_requests"
    id             = Column(Integer, primary_key=True)
    employee_id    = Column(Integer, ForeignKey("employees.id"), nullable=True)
    action_type    = Column(String(50))
    requested_by   = Column(String(100))
    approver       = Column(String(100))
    status         = Column(String(20), default="pending")
    reason         = Column(Text)
    notes          = Column(Text)
    created_at     = Column(DateTime, default=datetime.utcnow)
    resolved_at    = Column(DateTime, nullable=True)
    payload        = Column(Text)
    # Multi-level approval tracking
    manager_status = Column(String(20), default="pending")
    hr_status      = Column(String(20), default="pending")
    it_status      = Column(String(20), default="pending")
    employee       = relationship("Employee", back_populates="approvals")


# ── Email Log ─────────────────────────────────────────────────
class EmailLog(Base):
    __tablename__ = "email_logs"
    id          = Column(Integer, primary_key=True)
    to_address  = Column(String(150))
    subject     = Column(String(250))
    body        = Column(Text)
    status      = Column(String(20), default="simulated")
    sent_at     = Column(DateTime, default=datetime.utcnow)
    related_emp = Column(String(100))


# ── Exit Checklist ────────────────────────────────────────────
class ExitChecklist(Base):
    __tablename__ = "exit_checklists"
    id           = Column(Integer, primary_key=True)
    employee_id  = Column(Integer, ForeignKey("employees.id"))
    item         = Column(String(300))
    category     = Column(String(100))
    is_completed = Column(Boolean, default=False)
    completed_at = Column(DateTime, nullable=True)
    completed_by = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=datetime.utcnow)
    employee     = relationship("Employee")


# ── Mover Events (Department Transfer) ────────────────────────
class MoverEvent(Base):
    __tablename__ = "mover_events"
    id               = Column(Integer, primary_key=True)
    employee_id      = Column(Integer, ForeignKey("employees.id"))
    from_department  = Column(String(100))
    to_department    = Column(String(100))
    from_role        = Column(String(50))
    to_role          = Column(String(50))
    from_manager     = Column(String(100))
    to_manager       = Column(String(100))
    effective_date   = Column(String(20))
    reason           = Column(Text)
    status           = Column(String(20), default="pending")
    performed_by     = Column(String(100))
    created_at       = Column(DateTime, default=datetime.utcnow)
    completed_at     = Column(DateTime, nullable=True)
    old_access_revoked = Column(Boolean, default=False)
    new_access_granted = Column(Boolean, default=False)
    employee         = relationship("Employee", back_populates="mover_events", foreign_keys=[employee_id])
