"""
Simulates Active Directory operations.
Every method returns a dict with status + message.
Replace with pywinrm / python-ldap in production.
"""
import random
from datetime import datetime


class ADSimulator:

    @staticmethod
    def create_account(username: str, department: str, email: str) -> dict:
        return {
            "status": "success",
            "message": f"AD account '{username}' created in OU={department},DC=techcorp,DC=com",
            "upn": email,
            "sam_account_name": username,
            "timestamp": datetime.utcnow().isoformat()
        }

    @staticmethod
    def set_initial_password(username: str) -> dict:
        temp_pw = f"Tc@{random.randint(100000, 999999)}"
        return {
            "status": "success",
            "message": f"Temporary password set for '{username}'",
            "temp_password": temp_pw
        }

    @staticmethod
    def add_to_department_group(username: str, department: str) -> dict:
        return {
            "status": "success",
            "message": f"Added '{username}' to security group SG-{department}"
        }

    @staticmethod
    def enable_mfa(username: str) -> dict:
        return {
            "status": "success",
            "message": f"MFA enrollment link sent to '{username}'"
        }

    @staticmethod
    def run_full_onboarding(username: str, department: str, email: str) -> list:
        return [
            {"step": "create_account",        **ADSimulator.create_account(username, department, email)},
            {"step": "set_initial_password",   **ADSimulator.set_initial_password(username)},
            {"step": "add_to_dept_group",      **ADSimulator.add_to_department_group(username, department)},
            {"step": "enable_mfa",             **ADSimulator.enable_mfa(username)},
        ]

    # ── Offboarding methods ─────────────────────────────────────────────

    @staticmethod
    def disable_account(username: str) -> dict:
        return {
            "status": "success",
            "message": f"AD account '{username}' disabled — login blocked",
            "timestamp": datetime.utcnow().isoformat()
        }

    @staticmethod
    def reset_password_random(username: str) -> dict:
        rnd_pw = f"Rnd@{random.randint(100000, 999999)}!x"
        return {
            "status": "success",
            "message": f"Password randomised for '{username}' — access revoked even if re-enabled"
        }

    @staticmethod
    def remove_from_all_groups(username: str, department: str) -> dict:
        return {
            "status": "success",
            "message": f"'{username}' removed from SG-{department} and all distribution groups"
        }

    @staticmethod
    def move_to_disabled_ou(username: str) -> dict:
        return {
            "status": "success",
            "message": f"'{username}' moved to OU=Disabled Users,DC=techcorp,DC=com"
        }

    @staticmethod
    def clear_sessions(username: str) -> dict:
        return {
            "status": "success",
            "message": f"All active sessions terminated for '{username}'"
        }

    @staticmethod
    def set_out_of_office(username: str, email: str) -> dict:
        return {
            "status": "success",
            "message": f"Out-of-office auto-reply configured for {email}"
        }

    @staticmethod
    def run_full_offboarding(username: str, department: str, email: str) -> list:
        return [
            {"step": "disable_account",        **ADSimulator.disable_account(username)},
            {"step": "reset_password_random",   **ADSimulator.reset_password_random(username)},
            {"step": "remove_from_all_groups",  **ADSimulator.remove_from_all_groups(username, department)},
            {"step": "move_to_disabled_ou",     **ADSimulator.move_to_disabled_ou(username)},
            {"step": "clear_sessions",          **ADSimulator.clear_sessions(username)},
            {"step": "set_out_of_office",       **ADSimulator.set_out_of_office(username, email)},
        ]
