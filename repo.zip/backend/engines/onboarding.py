"""
Onboarding Engine — Enterprise JML
Full Azure AD + M365 + RBAC + Asset + Email pipeline
"""
import uuid, json, os
from datetime import datetime

from sqlalchemy.orm import Session
from models import Employee, Role, AuditLog, ApprovalRequest, M365Access
from engines.email_engine import generate_unique_email, send_welcome_email, send_approval_request_email
from engines.rbac import provision_access, assign_assets
from engines.microsoft_graph import run_full_ad_onboarding

DATA_FILE = os.path.join(os.path.dirname(__file__), "../../data/dummy_data.json")

def _approval_roles():
    try:
        return json.load(open(DATA_FILE)).get("approval_required_roles", ["admin","finance","hr_manager"])
    except: return ["admin","finance","hr_manager"]


def onboard_employee(db, name, department, role_name, designation="",
                     manager="TBD", location="Head Office", region="",
                     phone="", emergency_contact="", joining_date="",
                     performed_by="hr_system") -> dict:

    role = db.query(Role).filter(Role.name == role_name.lower()).first()
    if not role:
        return {"error": f"Role '{role_name}' not found. Valid: admin, developer, hr_manager, finance, sales, intern"}

    emp_id  = f"EMP-{datetime.now().year}-{str(uuid.uuid4())[:6].upper()}"
    email   = generate_unique_email(name, db)
    ad_user = name.lower().replace(" ", ".")

    needs_approval = role_name.lower() in _approval_roles()
    status = "pending_approval" if needs_approval else "active"

    employee = Employee(
        employee_id=emp_id, name=name, email=email, department=department,
        designation=designation, role_id=role.id, manager=manager,
        location=location, region=region, phone=phone,
        emergency_contact=emergency_contact, ad_username=ad_user,
        joining_date=joining_date or datetime.utcnow().strftime("%Y-%m-%d"),
        status=status,
        mailbox_status="pending", teams_status="pending",
        sharepoint_status="pending", license_status="pending",
    )
    db.add(employee)
    db.flush()

    if needs_approval:
        payload = json.dumps({"name": name, "department": department, "role": role_name,
                               "designation": designation, "manager": manager, "location": location,
                               "region": region, "phone": phone, "joining_date": joining_date})
        approval = ApprovalRequest(
            employee_id=employee.id, action_type="onboard",
            requested_by=performed_by, approver="hr_director",
            reason=f"Onboarding {name} as {role_name} requires approval",
            payload=payload, manager_status="pending", hr_status="pending", it_status="pending"
        )
        db.add(approval)
        _log(db, employee.id, "APPROVAL_REQUESTED", "HR System", performed_by,
             "pending", f"Approval required for {role_name}")
        send_approval_request_email(db, name, emp_id, role_name, performed_by)
        db.commit()
        return {"status": "pending_approval", "employee_id": emp_id, "name": name,
                "message": f"Role '{role_name}' requires HR Director approval.",
                "approval_id": approval.id}

    return _execute_onboarding(db, employee, role, name, email, emp_id, ad_user,
                                department, manager, location, phone, designation,
                                joining_date, performed_by)


def _execute_onboarding(db, employee, role, name, email, emp_id, ad_user,
                         department, manager, location, phone, designation,
                         joining_date, performed_by) -> dict:
    from engines.microsoft_graph import DEPT_GROUPS, DEPT_TEAMS, DEPT_SHAREPOINT

    # Azure AD + M365 provisioning
    az = run_full_ad_onboarding(
        name=name, email=email, department=department, role=role.name,
        designation=designation, manager="TBD", location=location,
        phone=phone, joining_date=joining_date
    )

    if az.get("azure_object_id"):
        employee.azure_object_id = az["azure_object_id"]
    if az.get("upn"):
        employee.azure_upn = az["upn"]

    # Parse step results → update status fields
    for step in az.get("steps", []):
        sname = step.get("step", "")
        stat  = "provisioned" if step["status"] == "success" else "failed"
        if "mailbox"    in sname: employee.mailbox_status    = stat
        if "teams"      in sname: employee.teams_status      = stat
        if "sharepoint" in sname: employee.sharepoint_status = stat
        if "license"    in sname:
            employee.license_status = stat
            if step.get("sku_name"): employee.license_sku = step["sku_name"]
        _log(db, employee.id, f"AZURE_{sname.upper()}", "Azure AD", performed_by,
             step["status"], step.get("message", step.get("error", "")))

    # Store M365 access records
    from engines.microsoft_graph import DEPT_GROUPS, DEPT_TEAMS, DEPT_SHAREPOINT
    for grp in dict.fromkeys(DEPT_GROUPS.get(department, [])):
        db.add(M365Access(employee_id=employee.id, access_type="security_group",
                          resource=grp, permission="member", is_active=True, granted_by=performed_by))
    for team in DEPT_TEAMS.get(department, []):
        db.add(M365Access(employee_id=employee.id, access_type="teams",
                          resource=team, permission="member", is_active=True, granted_by=performed_by))
    for site_name, permission in DEPT_SHAREPOINT.get(department, []):
        db.add(M365Access(
            employee_id=employee.id,
            access_type="sharepoint",
            resource=site_name,
            permission=permission,
            is_active=True,
            granted_by=performed_by
        ))
    # RBAC + Assets
    provisioned = provision_access(db, employee, role, performed_by)
    assets      = assign_assets(db, employee)
    for a in assets:
        _log(db, employee.id, "ASSIGN_ASSET", "Asset Management", performed_by,
             "success", f"Assigned {a['type']}: {a['asset_tag']}")

    send_welcome_email(db, name, email, emp_id, role.name, department)
    _log(db, employee.id, "SEND_WELCOME_EMAIL", "Email System", performed_by, "success", f"Welcome email → {email}")
    _log(db, employee.id, "ONBOARD_COMPLETE", "HR System", performed_by, "success",
         f"{name} onboarded as {role.name} in {department}. Azure:{az.get('status')} | {len(provisioned)} systems | {len(assets)} assets")
    db.commit()

    return {
        "status": "success", "employee_id": emp_id, "name": name, "email": email,
        "ad_username": ad_user, "role": role.name, "department": department,
        "azure_ad": az, "systems_provisioned": provisioned, "assets_assigned": assets,
        "mailbox_status": employee.mailbox_status, "teams_status": employee.teams_status,
        "sharepoint_status": employee.sharepoint_status, "license_status": employee.license_status,
    }


def execute_approved_onboarding(db, approval_id: int, performed_by="hr_director") -> dict:
    approval = db.query(ApprovalRequest).filter(
        ApprovalRequest.id == approval_id, ApprovalRequest.status == "approved").first()
    if not approval:
        return {"error": "Approval not found or not approved"}
    employee = db.query(Employee).filter(Employee.id == approval.employee_id).first()
    if not employee or employee.status == "active":
        return {"error": "Employee not found or already active"}
    role = db.query(Role).filter(Role.id == employee.role_id).first()
    result = _execute_onboarding(db, employee, role, employee.name, employee.email,
                                  employee.employee_id, employee.ad_username,
                                  employee.department, employee.manager or "TBD",
                                  employee.location or "Head Office", employee.phone or "",
                                  employee.designation or "", employee.joining_date or "",
                                  performed_by)
    employee.status = "active"
    db.commit()
    return result


def _log(db, emp_id, action, system, by, status, details):
    db.add(AuditLog(employee_id=emp_id, action=action, system=system,
                    performed_by=by, status=status, details=details))
