"""
Risk Analyzer — LLM-powered insider threat scoring for offboarding
------------------------------------------------------------------
Uses Groq (Llama 3.3 70B) to assess departing employee risk level
based on their audit trail and dummy behavioral signals.

Risk Levels:
  0–30   → Low      → Standard offboarding
  31–59  → Medium   → Standard + extra logging
  60–84  → High     → Parallel + security team alert
  85–100 → Critical → Emergency lockdown + CISO notification
"""
import os, json, random
from datetime import datetime, timedelta
from sqlalchemy.orm import Session

GROQ_KEY = os.getenv("GROQ_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "llama-3.3-70b-versatile")

RISK_PROMPT = """You are a cybersecurity risk analyst specializing in insider threat detection during employee offboarding.

Analyze the following employee data and behavioral signals, then return a JSON risk assessment.

Return ONLY valid JSON in this exact format (no markdown, no explanation):
{
  "risk_score": <integer 0-100>,
  "risk_level": "<low|medium|high|critical>",
  "offboarding_mode": "<standard|enhanced|emergency>",
  "risk_factors": ["<factor1>", "<factor2>", ...],
  "recommended_actions": ["<action1>", "<action2>", ...],
  "summary": "<2-3 sentence plain-English risk summary>"
}

Risk level mapping:
  0-30 → low → standard
  31-59 → medium → standard  
  60-84 → high → enhanced
  85-100 → critical → emergency"""


def analyze_risk(employee, db: Session) -> dict:
    """
    Analyze offboarding risk for an employee.
    Returns rich risk assessment dict.
    """
    signals = _build_signals(employee, db)
    if GROQ_KEY and GROQ_KEY != "your_groq_api_key_here":
        try:
            return _llm_analysis(employee, signals)
        except Exception as e:
            return _rule_based_analysis(employee, signals, f"LLM error: {e}")
    return _rule_based_analysis(employee, signals)


def _build_signals(employee, db) -> dict:
    """Extract behavioral signals from audit logs + dummy data."""
    from models import AuditLog
    logs = db.query(AuditLog).filter(
        AuditLog.employee_id == employee.id
    ).order_by(AuditLog.timestamp.desc()).limit(50).all()

    # Count signal types from audit trail
    action_counts = {}
    for log in logs:
        action_counts[log.action] = action_counts.get(log.action, 0) + 1

    role_name = employee.role_obj.name if employee.role_obj else "unknown"

    # Dummy behavioral signals (in production: pull from SIEM/DLP)
    dummy_signals = _generate_dummy_signals(role_name)

    return {
        "employee_name":      employee.name,
        "role":               role_name,
        "department":         employee.department,
        "tenure_days":        (datetime.utcnow() - employee.created_at).days if employee.created_at else 0,
        "total_audit_actions": len(logs),
        "action_breakdown":   action_counts,
        "role_access_level":  employee.role_obj.level if employee.role_obj else "standard",
        **dummy_signals
    }


def _generate_dummy_signals(role: str) -> dict:
    """
    Generate realistic dummy behavioral signals for demo.
    In production: connect to SIEM/DLP/UEBA system.
    """
    # Higher-privilege roles get slightly elevated signal noise
    is_privileged = role in ["admin", "finance", "hr_manager"]
    seed = hash(role) % 100

    return {
        "dlp_alerts_30d":           random.randint(2, 8)  if is_privileged else random.randint(0, 3),
        "large_file_downloads_gb":  round(random.uniform(0.5, 6.0) if is_privileged else random.uniform(0, 2.5), 1),
        "sensitive_repo_clones":    random.randint(0, 3)  if is_privileged else random.randint(0, 1),
        "usb_events_30d":           random.randint(0, 4),
        "external_email_forwards":  random.randint(0, 5)  if is_privileged else random.randint(0, 2),
        "after_hours_logins_30d":   random.randint(2, 12),
        "cloud_upload_gb":          round(random.uniform(0.2, 4.0), 1),
        "privilege_escalation_attempts": random.randint(0, 2) if is_privileged else 0,
        "failed_logins_7d":         random.randint(0, 5),
        "new_external_contacts_30d": random.randint(0, 8),
    }


def _llm_analysis(employee, signals: dict) -> dict:
    from groq import Groq
    client = Groq(api_key=GROQ_KEY)

    user_msg = f"""Analyze offboarding risk for this employee:

EMPLOYEE:
  Name:       {signals['employee_name']}
  Role:       {signals['role']} ({signals['role_access_level']})
  Department: {signals['department']}
  Tenure:     {signals['tenure_days']} days

BEHAVIORAL SIGNALS (last 30 days):
  DLP Alerts:                {signals['dlp_alerts_30d']}
  Large File Downloads:      {signals['large_file_downloads_gb']} GB
  Sensitive Repo Clones:     {signals['sensitive_repo_clones']}
  USB Events:                {signals['usb_events_30d']}
  External Email Forwards:   {signals['external_email_forwards']}
  After-Hours Logins:        {signals['after_hours_logins_30d']}
  Cloud Uploads:             {signals['cloud_upload_gb']} GB
  Privilege Escalation Tries:{signals['privilege_escalation_attempts']}
  Failed Logins (7d):        {signals['failed_logins_7d']}
  New External Contacts:     {signals['new_external_contacts_30d']}

SYSTEM CONTEXT:
  Total Audit Actions: {signals['total_audit_actions']}
  Role-based access to: {'sensitive financial/admin systems' if signals['role_access_level'] in ['admin', 'manager'] else 'standard developer tools'}"""

    resp = client.chat.completions.create(
        model=LLM_MODEL,
        messages=[
            {"role": "system", "content": RISK_PROMPT},
            {"role": "user",   "content": user_msg}
        ],
        temperature=0.2,
        max_tokens=600
    )
    raw = resp.choices[0].message.content.strip()
    # Strip any markdown fences
    raw = raw.replace("```json", "").replace("```", "").strip()
    result = json.loads(raw)
    result["signals"] = signals
    result["analyzed_by"] = "groq_llm"
    result["analyzed_at"] = datetime.utcnow().isoformat()
    return result


def _rule_based_analysis(employee, signals: dict, note: str = "") -> dict:
    """Fallback rule-based scoring when LLM is unavailable."""
    score = 0
    factors = []

    if signals["dlp_alerts_30d"] >= 5:
        score += 25; factors.append(f"High DLP alerts: {signals['dlp_alerts_30d']} triggers")
    elif signals["dlp_alerts_30d"] >= 2:
        score += 10; factors.append(f"Moderate DLP activity: {signals['dlp_alerts_30d']} alerts")

    if signals["large_file_downloads_gb"] >= 5:
        score += 20; factors.append(f"Large file download: {signals['large_file_downloads_gb']} GB")
    elif signals["large_file_downloads_gb"] >= 2:
        score += 8

    if signals["privilege_escalation_attempts"] > 0:
        score += 20; factors.append(f"Privilege escalation attempts: {signals['privilege_escalation_attempts']}")

    if signals["sensitive_repo_clones"] >= 2:
        score += 15; factors.append(f"Sensitive repo clones: {signals['sensitive_repo_clones']}")

    if signals["external_email_forwards"] >= 4:
        score += 10; factors.append(f"External forwarding: {signals['external_email_forwards']} emails")

    if signals["usb_events_30d"] >= 3:
        score += 10; factors.append(f"USB device events: {signals['usb_events_30d']}")

    if signals["role_access_level"] in ["admin", "manager"]:
        score += 5; factors.append("Privileged role — elevated access level")

    score = min(score, 100)

    if score >= 85:   level, mode = "critical", "emergency"
    elif score >= 60: level, mode = "high",     "enhanced"
    elif score >= 31: level, mode = "medium",   "standard"
    else:             level, mode = "low",       "standard"

    actions = _recommend_actions(level, signals)
    return {
        "risk_score":          score,
        "risk_level":          level,
        "offboarding_mode":    mode,
        "risk_factors":        factors or ["No significant risk signals detected"],
        "recommended_actions": actions,
        "summary": (
            f"{signals['employee_name']} scored {score}/100 ({level} risk). "
            f"{'Immediate parallel lockdown recommended.' if level == 'critical' else 'Standard offboarding procedures apply.'}"
        ),
        "signals":    signals,
        "analyzed_by": "rule_based" + (f" ({note})" if note else ""),
        "analyzed_at": datetime.utcnow().isoformat()
    }


def _recommend_actions(level: str, signals: dict) -> list:
    base = [
        "Disable AD account immediately",
        "Revoke all system access",
        "Collect all company assets",
    ]
    if level in ["high", "critical"]:
        base += [
            "Notify CISO and security team immediately",
            "Preserve and review last 30 days of audit logs",
            "Check for unusual data transfers or downloads",
            "Verify no company data on personal devices/cloud",
        ]
    if level == "critical":
        base += [
            "Emergency parallel lockdown across all systems",
            "Legal review required before final sign-off",
            "Forensic analysis of workstation may be needed",
        ]
    if signals.get("large_file_downloads_gb", 0) >= 3:
        base.append("Review DLP logs for data exfiltration indicators")
    if signals.get("privilege_escalation_attempts", 0) > 0:
        base.append("Audit all actions performed with elevated privileges")
    return base
