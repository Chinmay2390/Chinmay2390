"""
Offboarding Engine — Phase 3 (Enhanced)
-----------------------------------------
Steps:
  1.  Risk analysis (LLM-powered)
  2.  AD offboarding cleanup (6 steps)
  3.  Microsoft Graph / M365 offboarding (4 steps)
  4.  Revoke all system access (RBAC) — AUTO-marks checklist
  5.  Flag assets for return
  6.  Build role-specific exit checklist
  7.  AUTO-mark completed actions in checklist
  8.  Send offboard email (real or simulated)
  9.  Security alert if high/critical risk
 10.  Disable employee account
"""
from datetime import datetime
from sqlalchemy.orm import Session
from models import Employee, AuditLog, ExitChecklist
from engines.ad_simulator import ADSimulator
from engines.rbac import revoke_all_access
from engines.email_engine import send_offboard_email, send_security_alert
from engines.microsoft_graph import run_full_m365_offboarding

ROLE_CHECKLISTS = {
    "developer": [
        ("Code & Repos",    "Commit and push all in-progress work",                False),
        ("Code & Repos",    "GitHub organisation membership removed",              True),
        ("Code & Repos",    "Remove personal SSH keys from GitHub",               True),
        ("Code & Repos",    "Sensitive repository access revoked",                 True),
        ("Access",          "AWS IAM keys deactivated",                            True),
        ("Access",          "Jira account deactivated and tasks reassigned",       True),
        ("Access",          "VPN certificate revoked",                             True),
        ("Access",          "Confluence access removed",                           True),
        ("Access",          "Slack workspace access removed",                      True),
        ("Access",          "M365 sign-in blocked",                               True),
        ("Assets",          "Laptop returned to IT desk",                          False),
        ("Assets",          "ID card returned to reception",                       False),
        ("Data",            "Personal files removed from company systems",         False),
        ("Communication",   "Out-of-office auto-reply configured",                 True),
        ("Sign-off",        "Exit interview completed",                            False),
    ],
    "admin": [
        ("Admin",           "Handover all admin credentials to IT",               False),
        ("Admin",           "Admin account removed from all systems",             True),
        ("Admin",           "Transfer pending admin tasks to manager",            False),
        ("Access",          "All elevated privileges revoked",                    True),
        ("Access",          "M365 admin consent removed",                         True),
        ("Access",          "Slack workspace access removed",                     True),
        ("Security",        "Security audit of admin actions completed",          False),
        ("Assets",          "Laptop returned to IT desk",                         False),
        ("Assets",          "ID card returned to reception",                      False),
        ("Data",            "Admin data backup exported",                         False),
        ("Communication",   "Out-of-office auto-reply configured",                True),
        ("Sign-off",        "Exit interview completed",                           False),
    ],
    "hr_manager": [
        ("HR Data",         "Employee files transferred to new HR manager",       False),
        ("HR Data",         "HRMS and payroll access revoked",                    True),
        ("Access",          "Slack workspace access removed",                     True),
        ("Access",          "M365 sign-in blocked",                              True),
        ("Assets",          "Laptop returned to IT desk",                         False),
        ("Assets",          "ID card returned to reception",                      False),
        ("Compliance",      "Confidentiality reminder issued",                    False),
        ("Communication",   "Out-of-office auto-reply configured",                True),
        ("Sign-off",        "Exit interview completed",                           False),
    ],
    "finance": [
        ("Finance",         "Pending financial tasks handed over",                False),
        ("Finance",         "Accounting system access revoked",                   True),
        ("Finance",         "Final expense reports submitted",                    False),
        ("Access",          "Banking portal access removed",                      True),
        ("Access",          "M365 sign-in blocked",                              True),
        ("Assets",          "Laptop returned to IT desk",                         False),
        ("Assets",          "ID card returned to reception",                      False),
        ("Compliance",      "NDA reminder and final sign-off",                    False),
        ("Communication",   "Out-of-office auto-reply configured",                True),
        ("Sign-off",        "Exit interview completed",                           False),
    ],
    "sales": [
        ("CRM",             "CRM contacts and deals transferred to manager",      False),
        ("CRM",             "Salesforce and CRM access revoked",                  True),
        ("Access",          "Slack workspace access removed",                     True),
        ("Access",          "M365 sign-in blocked",                              True),
        ("Assets",          "Laptop returned to IT desk",                         False),
        ("Assets",          "ID card returned to reception",                      False),
        ("Communication",   "Clients notified of new contact person",            False),
        ("Communication",   "Out-of-office auto-reply configured",                True),
        ("Sign-off",        "Exit interview completed",                           False),
    ],
    "intern": [
        ("Access",          "All system access revoked",                          True),
        ("Access",          "GitHub read access removed",                         True),
        ("Assets",          "Laptop returned to IT desk",                         False),
        ("Assets",          "ID card returned to reception",                      False),
        ("Communication",   "Out-of-office auto-reply configured",                True),
        ("Sign-off",        "Exit interview completed",                           False),
    ],
}

DEFAULT_CHECKLIST = [
    ("Access",        "All system access revoked",               True),
    ("Assets",        "Laptop returned to IT desk",              False),
    ("Assets",        "ID card returned to reception",           False),
    ("Communication", "Out-of-office auto-reply configured",     True),
    ("Sign-off",      "Exit interview completed",                False),
]

SYSTEM_AUTO_KEYWORDS = {
    "GitHub":          ["github", "ssh key", "repository"],
    "AWS":             ["aws", "iam"],
    "Jira":            ["jira"],
    "Slack":           ["slack"],
    "VPN":             ["vpn", "certificate"],
    "Confluence":      ["confluence"],
    "HRMS":            ["hrms", "payroll"],
    "Salesforce":      ["salesforce", "crm"],
    "Microsoft 365":   ["m365", "microsoft", "sign-in blocked"],
    "Active Directory":["ad account", "active directory"],
}


def offboard_employee(db, employee_id, last_day, reason="resignation",
                      performed_by="hr_system", azure_object_id=None):

    employee = db.query(Employee).filter(Employee.id == employee_id).first()
    if not employee:
        return {"error": f"Employee {employee_id} not found"}
    if employee.status == "disabled":
        return {"error": f"{employee.name} is already offboarded"}
    if employee.status == "pending_approval":
        return {"error": f"{employee.name} has a pending onboarding approval"}

    role_name = employee.role_obj.name if employee.role_obj else "developer"

    # 1. Risk analysis
    risk = {"risk_score": 0, "risk_level": "low", "offboarding_mode": "standard"}
    try:
        from engines.risk_analyzer import analyze_risk
        risk = analyze_risk(employee, db)
        _log(db, employee.id, "RISK_ANALYSIS_COMPLETE", "Risk Engine", performed_by,
             "success", f"Risk: {risk.get('risk_score', 0)}/100 — {risk.get('risk_level','').upper()}")
    except Exception as e:
        risk["error"] = str(e)

    # 2. AD offboarding
    ad_steps = ADSimulator.run_full_offboarding(
        employee.ad_username, employee.department, employee.email)
    for s in ad_steps:
        _log(
            db,
            employee.id,
            s.get("step", "UNKNOWN").upper(),
            "Active Directory",
            performed_by,
            s.get("status", "unknown"),
            s.get("message", "No message provided")
        )

    # 3. M365 / Graph — resolve real Azure Object ID first
    from engines.microsoft_graph import resolve_azure_object_id
    az_resolve = resolve_azure_object_id(
        name=employee.name,
        stored_id=azure_object_id or employee.azure_object_id,
        stored_upn=employee.azure_upn,
    )
    azure_id = az_resolve["id"]
    _log(db, employee.id, "AZURE_ID_RESOLVED", "Microsoft 365", performed_by,
         "success" if az_resolve.get("found") else "warning",
         f"Azure ID: {azure_id} (source: {az_resolve.get('source','unknown')}, found: {az_resolve.get('found')})")

    graph_steps = run_full_m365_offboarding(azure_id, employee.name, last_day)
    for s in graph_steps:
        _log(
            db,
            employee.id,
            f"M365_{s.get('step', 'UNKNOWN').upper()}",
            "Microsoft 365",
            performed_by,
            s.get("status", "unknown"),
            s.get("message", "No message provided")
        )

    # 4. Revoke RBAC access
    revoked = revoke_all_access(db, employee, performed_by)
    _log(db, employee.id, "ALL_ACCESS_REVOKED", "RBAC Engine", performed_by,
         "success", f"Revoked {len(revoked)} system(s)")

    # 5. Flag assets
    pending_assets = [
        {"asset_tag": a.asset.asset_tag, "type": a.asset.asset_type}
        for a in employee.assets if a.is_active and a.asset
    ]
    _log(db, employee.id, "ASSETS_PENDING_RETURN", "Asset Management",
         performed_by, "pending", f"{len(pending_assets)} asset(s) flagged for return")

    # 6. Build checklist
    template = ROLE_CHECKLISTS.get(role_name.lower(), DEFAULT_CHECKLIST)
    checklist_objs = []
    for (category, item, can_auto) in template:
        cl = ExitChecklist(employee_id=employee.id, item=item,
                           category=category, is_completed=False)
        db.add(cl)
        db.flush()
        checklist_objs.append((cl, item.lower(), can_auto))

    # 7. Auto-complete checklist items
    auto_done = _auto_complete_checklist(db, checklist_objs, revoked,
                                         ad_steps, graph_steps, performed_by)
    _log(db, employee.id, "EXIT_CHECKLIST_CREATED", "HR System", performed_by,
         "success", f"Checklist: {len(template)} items, {auto_done} auto-completed")

    # 8. Offboard email
    email_result = send_offboard_email(
        db, employee.name, employee.email,
        employee.employee_id, role_name, last_day, reason)
    _log(db, employee.id, "SEND_OFFBOARD_EMAIL", "Email System",
         performed_by, email_result.get("status", "error"),
         f"Email → {employee.email} ({email_result.get('status')})")

    # 9. Security alert for high/critical
    if risk.get("risk_level") in ["high", "critical"]:
        sec = send_security_alert(db, employee.name, employee.employee_id,
                                   risk.get("risk_score", 0), risk.get("summary", ""))
        _log(db, employee.id, "SECURITY_ALERT_SENT", "Security System",
             performed_by, sec.get("status", "error"),
             f"CISO alerted — risk: {risk.get('risk_level')}")

    # 10. Disable
    employee.status = "disabled"
    employee.disabled_at = datetime.utcnow()
    _log(db, employee.id, "OFFBOARD_COMPLETE", "HR System", performed_by,
         "success", f"{employee.name} offboarded. Risk: {risk.get('risk_level','N/A')}. "
                    f"{len(revoked)} systems revoked.")
    db.commit()

    return {
        "status": "success", "employee_id": employee.employee_id,
        "name": employee.name, "email": employee.email, "role": role_name,
        "last_day": last_day, "reason": reason, "risk": risk,
        "ad_steps_completed": len(ad_steps), "m365_steps_completed": len(graph_steps),
        "systems_revoked": revoked, "assets_pending_return": pending_assets,
        "checklist_items": len(template), "checklist_auto_completed": auto_done,
        "email_status": email_result.get("status"),
    }


def _auto_complete_checklist(db, checklist_objs, revoked, ad_steps, graph_steps, by):
    revoked_systems = {r["system"].lower() for r in revoked}
    completed_kws = set()

    for system in revoked_systems:
        for sys_name, kws in SYSTEM_AUTO_KEYWORDS.items():
            if sys_name.lower() in system or system in sys_name.lower():
                completed_kws.update(kws)

    for s in ad_steps:
        if s["status"] == "success":
            if "disable" in s["step"] or "account" in s["step"]:
                completed_kws.update(["ad account", "active directory"])
            if "out_of_office" in s["step"] or "office" in s["step"]:
                completed_kws.update(["out-of-office", "auto-reply"])

    for s in graph_steps:
        if s["status"] == "success":
            if "block_signin" in s["step"]:
                completed_kws.update(["m365", "sign-in blocked", "microsoft"])
            if "out_of_office" in s["step"]:
                completed_kws.update(["out-of-office", "auto-reply"])

    now = datetime.utcnow()
    count = 0
    for (cl_obj, item_lower, can_auto) in checklist_objs:
        if not can_auto or cl_obj.is_completed:
            continue
        if any(kw in item_lower for kw in completed_kws):
            cl_obj.is_completed = True
            cl_obj.completed_at = now
            cl_obj.completed_by = "system_auto"
            count += 1
    return count


def get_exit_checklist(db, employee_id):
    items = db.query(ExitChecklist).filter(
        ExitChecklist.employee_id == employee_id
    ).order_by(ExitChecklist.category, ExitChecklist.id).all()
    return [
        {
            "id": i.id, "item": i.item, "category": i.category,
            "is_completed": i.is_completed,
            "completed_at": i.completed_at.isoformat() if i.completed_at else None,
            "completed_by": i.completed_by,
            "auto": i.completed_by == "system_auto" if i.completed_by else False,
        }
        for i in items
    ]


def complete_checklist_item(db, item_id, completed_by="hr_system"):
    item = db.query(ExitChecklist).filter(ExitChecklist.id == item_id).first()
    if not item:
        return {"error": "Checklist item not found"}
    item.is_completed = True
    item.completed_at = datetime.utcnow()
    item.completed_by = completed_by
    db.commit()
    return {"status": "updated", "item_id": item_id, "item": item.item}


def get_incomplete_offboardings(db):
    """Dashboard alerts — disabled employees with pending checklist items."""
    disabled = db.query(Employee).filter(Employee.status == "disabled").all()
    alerts = []
    for emp in disabled:
        pending = db.query(ExitChecklist).filter(
            ExitChecklist.employee_id == emp.id,
            ExitChecklist.is_completed == False
        ).all()
        if pending:
            alerts.append({
                "employee_id": emp.employee_id, "name": emp.name,
                "department": emp.department,
                "disabled_at": emp.disabled_at.isoformat() if emp.disabled_at else None,
                "pending_items": len(pending),
                "pending_categories": list({i.category for i in pending}),
            })
    return alerts


def _log(db, emp_id, action, system, by, status, details):
    db.add(AuditLog(
        employee_id=emp_id, action=action, system=system,
        performed_by=by, status=status, details=details))
