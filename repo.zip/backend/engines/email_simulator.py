"""
Simulates email sending — stores emails in DB instead of real SMTP.
In production: replace with smtplib or SendGrid.
"""
import os
from datetime import datetime
from sqlalchemy.orm import Session
from models import EmailLog, Employee

COMPANY = os.getenv("COMPANY_NAME", "TechCorp Solutions")
DOMAIN  = os.getenv("COMPANY_DOMAIN", "techcorp.com")


def generate_unique_email(name: str, db: Session) -> str:
    parts = name.lower().split()
    base  = f"{parts[0]}.{parts[-1]}@{DOMAIN}"
    email, n = base, 1
    while db.query(Employee).filter(Employee.email == email).first():
        email = f"{parts[0]}.{parts[-1]}{n}@{DOMAIN}"
        n += 1
    return email


def send_welcome_email(db: Session, name: str, email: str,
                       emp_id: str, role: str, department: str) -> dict:
    subject = f"Welcome to {COMPANY}, {name.split()[0]}!"
    body = f"""Dear {name},

Welcome to {COMPANY}! We are thrilled to have you join us.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
YOUR EMPLOYEE DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Employee ID  : {emp_id}
Work Email   : {email}
Role         : {role.replace('_', ' ').title()}
Department   : {department}
Company      : {COMPANY}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your system access has been provisioned. Please collect your
laptop and ID card from the IT desk on your first day.

We look forward to working with you!

Warm regards,
HR Team
{COMPANY}

──────────────────────────────
[SIMULATED — No real email sent]"""

    _save(db, email, subject, body, name)
    return {"status": "simulated", "to": email, "subject": subject}


def send_approval_request_email(db: Session, emp_name: str,
                                 emp_id: str, role: str,
                                 requested_by: str) -> dict:
    subject = f"[ACTION REQUIRED] Onboarding approval for {emp_name}"
    body = f"""Dear HR Director,

An onboarding request requires your approval.

Employee : {emp_name}
Role     : {role.replace('_', ' ').title()}
Requested: {requested_by}
Ref ID   : {emp_id}

Please log in to the HR System to approve or reject.

HR Automation System — {COMPANY}
[SIMULATED — No real email sent]"""

    approver_email = f"hr.director@{DOMAIN}"
    _save(db, approver_email, subject, body, emp_name)
    return {"status": "simulated", "to": approver_email, "subject": subject}


def _save(db: Session, to: str, subject: str, body: str, emp: str):
    db.add(EmailLog(
        to_address=to, subject=subject,
        body=body, status="simulated", related_emp=emp
    ))
    db.flush()


def send_offboard_email(db: Session, name: str, email: str,
                         emp_id: str, role: str, last_day: str, reason: str) -> dict:
    subject = f"Important: Your offboarding from {COMPANY}"
    body = f"""Dear {name},

This is to inform you that your employment with {COMPANY} has been processed.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
OFFBOARDING DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Employee ID  : {emp_id}
Work Email   : {email}
Role         : {role.replace('_', ' ').title()}
Last Day     : {last_day}
Reason       : {reason.replace('_', ' ').title()}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ACTION REQUIRED:
• Return your laptop and ID card to the IT desk
• Your system access has been revoked effective immediately
• Your AD account has been disabled

Please ensure all company assets are returned within 2 business days.

We thank you for your contributions to {COMPANY}.

HR Team
{COMPANY}

──────────────────────────────
[SIMULATED — No real email sent]"""

    _save(db, email, subject, body, name)
    return {"status": "simulated", "to": email, "subject": subject}
