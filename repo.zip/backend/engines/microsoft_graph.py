"""
Microsoft Graph Engine — Full Enterprise JML
============================================
Covers: User creation, Exchange, Teams, SharePoint, Shared Mailbox,
        License assignment, MFA, Intune, Offboarding cleanup.

USE_REAL_GRAPH=true  → real API calls
USE_REAL_GRAPH=false → realistic simulation
"""
import os, json, random, string
from datetime import datetime

# ⚠️  FIX: Read env at call time via function, NOT at module import time.
# When Python imports this module, the .env may not be loaded yet.
def _use_real() -> bool:
    return os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
# Your real group — Object ID from Azure Portal
REAL_GROUP_NAME = "LAB_Platform_Engineer"
REAL_GROUP_ID   = "d194cd1e-65ea-4f9a-8290-005775cedbc8"
TENANT_ID     = os.getenv("AZURE_TENANT_ID", "")
CLIENT_ID     = os.getenv("AZURE_CLIENT_ID", "")
CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET", "")
TENANT_DOMAIN = os.getenv("AZURE_TENANT_DOMAIN", "yourtenant.onmicrosoft.com")
USAGE_LOC     = os.getenv("AZURE_USAGE_LOCATION", "IN")

_token_cache: dict = {}

# ── Department → Azure AD group mapping ─────────────────────────
DEPT_GROUPS = {
    "Engineering":      ["LAB_Platform_Engineer"],
    "IT-Admin":         ["SG-IT-Admins",     "SG-VPN-Users",   "SG-All-Staff", "SG-Privileged-Users"],
    "HR":               ["SG-HR-Team",       "SG-All-Staff"],
    "Finance":          ["SG-Finance-Team",  "SG-All-Staff"],
    "Sales":            ["LAB_Platform_Engineer"],
    "Operations":       ["SG-Operations",    "SG-All-Staff"],
    "Cybersecurity":    ["SG-Cybersecurity", "SG-VPN-Users",   "SG-All-Staff", "SG-Privileged-Users"],
    "Legal":            ["SG-Legal-Team",    "SG-All-Staff"],
    "Marketing":        ["SG-Marketing",     "SG-All-Staff"],
    "Internship":       ["SG-Interns",       "SG-All-Staff"],
}

# Role → job title mapping
ROLE_TITLES = {
    "admin":      "IT Administrator",
    "developer":  "Software Developer",
    "hr_manager": "HR Manager",
    "finance":    "Finance Analyst",
    "sales":      "Sales Executive",
    "intern":     "Intern",
}

# Role → security groups (for onboarding engine M365Access records)
ROLE_GROUPS = {
    "admin":      ["SG-IT-Admins", "SG-Privileged-Users"],
    "developer":  ["SG-Engineering"],
    "hr_manager": ["SG-HR-Team"],
    "finance":    ["SG-Finance-Team"],
    "sales":      [],
    "intern":     ["SG-Interns"],
}

# Role → Teams
ROLE_TEAMS = {
    "admin":      ["IT Admin Team"],
    "developer":  ["Engineering Team"],
    "hr_manager": ["HR Team"],
    "finance":    ["Finance Team"],
    "sales":      ["Sales Team"],
    "intern":     [],
}

# Role → SharePoint
ROLE_SHAREPOINT = {
    "admin":      ["IT Admin Hub", "All-Staff Intranet"],
    "developer":  ["Engineering Hub"],
    "hr_manager": ["HR Portal"],
    "finance":    ["Finance Portal"],
    "sales":      ["Sales Hub"],
    "intern":     [],
}

# Dept → SharePoint sites
DEPT_SHAREPOINT = {
    "Engineering":   [("Engineering Hub",  "member"), ("Dev Resources",   "read")],
    "HR":            [("HR Portal",        "member"), ("Policy Library",  "read")],
    "Finance":       [("Finance Portal",   "member"), ("Reports Library", "read")],
    "IT-Admin":      [("IT Admin Hub",     "owner"),  ("All-Staff Intranet", "member")],
    "Cybersecurity": [("Security Hub",     "owner"),  ("Incident Reports","member")],
    "Sales":         [("Sales Hub",        "member"), ("CRM Resources",   "read")],
}

# Dept → Teams to join
DEPT_TEAMS = {
    "Engineering":   ["Engineering Team",  "Dev & QA"],
    "HR":            ["HR Team",           "People & Culture"],
    "Finance":       ["Finance Team",      "Budget & Planning"],
    "IT-Admin":      ["IT Admin Team",     "Infrastructure"],
    "Cybersecurity": ["Security Ops",      "SOC Team"],
    "Sales":         ["Sales Team",        "Account Management"],
}


def _get_token() -> str:
    import urllib.request, urllib.parse
    now = datetime.utcnow().timestamp()
    if _token_cache.get("expires_at", 0) > now + 60:
        return _token_cache["token"]
    # Read credentials fresh each time (in case env loaded after import)
    tenant_id     = os.getenv("AZURE_TENANT_ID", "")
    client_id     = os.getenv("AZURE_CLIENT_ID", "")
    client_secret = os.getenv("AZURE_CLIENT_SECRET", "")
    url  = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    data = urllib.parse.urlencode({
        "grant_type": "client_credentials", "client_id": client_id,
        "client_secret": client_secret, "scope": "https://graph.microsoft.com/.default",
    }).encode()
    req = urllib.request.Request(url, data=data, method="POST")
    with urllib.request.urlopen(req, timeout=15) as r:
        body = json.loads(r.read())
    _token_cache["token"]      = body["access_token"]
    _token_cache["expires_at"] = now + body.get("expires_in", 3600)
    return _token_cache["token"]


def _graph(method: str, path: str, body: dict = None) -> dict:
    import urllib.request, urllib.parse
    token = _get_token()
    # URL-encode the query string to handle spaces and special chars in filter values
    if "?" in path:
        base, qs = path.split("?", 1)
        url = f"https://graph.microsoft.com/v1.0{base}?{urllib.parse.quote(qs, safe='=&$,@:/')}"
    else:
        url = f"https://graph.microsoft.com/v1.0{path}"
    data  = json.dumps(body).encode() if body else None
    req   = urllib.request.Request(url, data=data, method=method,
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json",
                     "ConsistencyLevel": "eventual"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read()
            return json.loads(raw) if raw else {"status": "ok"}
    except urllib.error.HTTPError as e:
        err_body = e.read().decode()
        try:    return {"error": json.loads(err_body).get("error", {}).get("message", err_body), "code": e.code}
        except: return {"error": err_body, "code": e.code}


# ════════════════════════════════════════════════════════════════
#  ONBOARDING
# ════════════════════════════════════════════════════════════════

def create_azure_user(name: str, department: str, role: str,
                       designation: str = "", location: str = "Head Office",
                       phone: str = "", region: str = "") -> dict:
    USE_REAL = _use_real()
    upn      = _build_upn(name)
    temp_pw  = _temp_password()
    title    = designation or ROLE_TITLES.get(role.lower(), role.replace("_", " ").title())
    nick     = upn.split("@")[0]
    payload  = {
        "accountEnabled":    True,
        "displayName":       name,
        "mailNickname":      nick,
        "userPrincipalName": upn,
        "department":        department,
        "jobTitle":          title,
        "usageLocation":     os.getenv("AZURE_USAGE_LOCATION", "IN"),
        "officeLocation":    location,
        "passwordProfile":   {"forceChangePasswordNextSignIn": True, "password": temp_pw}
    }
    if phone and phone.strip():
        payload["mobilePhone"] = phone.strip()
    if region:
        payload["state"] = region

    if not USE_REAL:
        fake_id = "sim-" + "".join(random.choices("abcdef0123456789", k=8))
        return _ok("create_user", {"message": f"[SIM] User '{name}' created as {upn}",
                   "azure_object_id": fake_id, "upn": upn, "temp_password": temp_pw, "job_title": title})

    result = _graph("POST", "/users", payload)
    if "error" in result:
        return _fail("create_user", result["error"])
    return _ok("create_user", {"message": f"User '{name}' created in Azure AD as {upn}",
               "azure_object_id": result.get("id"), "upn": upn,
               "temp_password": temp_pw, "job_title": title, "real": True})


def set_manager(azure_object_id: str, manager_name: str) -> dict:
    USE_REAL = _use_real()
    if not manager_name or manager_name.strip() in ("TBD", "", "N/A"):
        return _ok("set_manager", {"message": "No manager — skipped"})
    if not USE_REAL:
        return _ok("set_manager", {"message": f"[SIM] Manager '{manager_name}' linked"})
    search = _graph("GET", f"/users?$filter=displayName eq '{manager_name}'&$select=id,displayName")
    managers = search.get("value", [])
    if not managers:
        return _ok("set_manager", {"message": f"Manager '{manager_name}' not found — skipped"})
    mgr_id = managers[0]["id"]
    result = _graph("PUT", f"/users/{azure_object_id}/manager/$ref",
                    {"@odata.id": f"https://graph.microsoft.com/v1.0/users/{mgr_id}"})
    return _ok("set_manager", {"message": f"Manager '{manager_name}' assigned"}) if "error" not in result \
           else _fail("set_manager", result["error"])


def add_to_groups(azure_object_id: str, name: str, role: str, department: str) -> dict:
    USE_REAL = _use_real()
    base_groups = DEPT_GROUPS.get(department, ["SG-All-Staff"])
    added, skipped = [], []
    if not USE_REAL:
        return _ok("add_to_groups", {"message": f"[SIM] Added {name} to: {', '.join(base_groups)}",
                   "groups": base_groups})
    for group_name in base_groups:
        # Use Object ID directly if it's our known group — no search needed
        if group_name == REAL_GROUP_NAME:
            groups = [{"id": REAL_GROUP_ID}]
        else:
            search = _graph("GET", f"/groups?$filter=displayName eq '{group_name}'&$select=id")
            groups = search.get("value", [])
        if not groups:
            skipped.append(group_name); continue
        r = _graph("POST", f"/groups/{groups[0]['id']}/members/$ref",
                   {"@odata.id": f"https://graph.microsoft.com/v1.0/directoryObjects/{azure_object_id}"})
        if "error" in r and "already exist" not in str(r.get("error", "")):
            skipped.append(group_name)
        else:
            added.append(group_name)
    return _ok("add_to_groups", {"message": f"Groups set for {name}", "added": added, "skipped": skipped})


def provision_exchange_mailbox(azure_object_id: str, name: str, upn: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("exchange_mailbox", {"message": f"[SIM] Exchange mailbox enabled for {name} ({upn})"})
    result = _graph("PATCH", f"/users/{azure_object_id}", {
        "preferredLanguage": "en-IN",
        "usageLocation": os.getenv("AZURE_USAGE_LOCATION", "IN")
    })
    return _ok("exchange_mailbox", {"message": f"Exchange mailbox settings configured for {name}"}) \
           if "error" not in result else _fail("exchange_mailbox", result["error"])


def add_to_teams(azure_object_id: str, name: str, department: str) -> dict:
    USE_REAL = _use_real()
    teams_to_join = DEPT_TEAMS.get(department, [])
    if not USE_REAL:
        return _ok("add_to_teams", {"message": f"[SIM] Added {name} to Teams: {', '.join(teams_to_join) or 'General'}",
                   "teams": teams_to_join})
    added, skipped = [], []
    for team_name in teams_to_join:
        search = _graph("GET", f"/groups?$filter=displayName eq '{team_name}' and resourceProvisioningOptions/Any(x:x eq 'Team')&$select=id")
        teams = search.get("value", [])
        if not teams:
            skipped.append(team_name); continue
        r = _graph("POST", f"/teams/{teams[0]['id']}/members",
                   {"@odata.type": "#microsoft.graph.aadUserConversationMember",
                    "roles": [],
                    "user@odata.bind": f"https://graph.microsoft.com/v1.0/users/{azure_object_id}"})
        (added if "error" not in r else skipped).append(team_name)
    return _ok("add_to_teams", {"message": f"Teams access set for {name}",
               "added": added, "skipped": skipped})


def assign_sharepoint_access(azure_object_id: str, name: str, department: str) -> dict:
    USE_REAL = _use_real()
    sites = DEPT_SHAREPOINT.get(department, [])
    if not USE_REAL:
        site_names = [s[0] for s in sites]
        return _ok("sharepoint_access", {"message": f"[SIM] SharePoint access granted: {', '.join(site_names) or 'None'}",
                   "sites": site_names})
    granted = []
    for (site_name, permission) in sites:
        search = _graph("GET", f"/sites?$search={site_name}&$select=id,displayName")
        site_list = search.get("value", [])
        if not site_list:
            continue
        site_id = site_list[0]["id"]
        r = _graph("POST", f"/sites/{site_id}/permissions", {
            "roles": [permission],
            "grantedToIdentities": [{
                "user": {"id": azure_object_id, "displayName": name}
            }]
        })
        if "error" not in r:
            granted.append(site_name)
    return _ok("sharepoint_access", {"message": f"SharePoint access granted to {len(granted)} site(s)", "sites": granted})


def assign_license(azure_object_id: str, name: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("assign_license", {"message": f"[SIM] M365 Business license assigned to {name}",
                   "sku": "M365_BUSINESS_BASIC"})
    skus = _graph("GET", "/subscribedSkus?$select=skuId,skuPartNumber,consumedUnits,prepaidUnits")
    chosen = None
    for sku in skus.get("value", []):
        available = sku.get("prepaidUnits", {}).get("enabled", 0) - sku.get("consumedUnits", 0)
        if available > 0:
            chosen = sku; break
    if not chosen:
        return _ok("assign_license", {"message": "No available licenses — assign manually", "warning": True})
    r = _graph("POST", f"/users/{azure_object_id}/assignLicenses",
               {"addLicenses": [{"skuId": chosen["skuId"]}], "removeLicenses": []})
    if "error" in r:
        return _fail("assign_license", r["error"])
    return _ok("assign_license", {"message": f"License '{chosen['skuPartNumber']}' assigned to {name}",
               "sku_id": chosen["skuId"], "sku_name": chosen["skuPartNumber"]})


def run_full_ad_onboarding(name: str, department: str, role: str,
                            designation: str = "", manager: str = "TBD",
                            location: str = "Head Office", phone: str = "",
                            region: str = "", email: str = "",
                            joining_date: str = "") -> dict:
    USE_REAL = _use_real()
    steps = []
    azure_id = None; upn = None; temp_pw = None

    s1 = create_azure_user(name, department, role, designation, location, phone, region)
    steps.append(s1)
    if s1["status"] == "success":
        azure_id = s1.get("azure_object_id")
        upn      = s1.get("upn")
        temp_pw  = s1.get("temp_password")

    if not azure_id:
        return {"status": "failed", "error": "User creation failed", "steps": steps}

    steps.append(set_manager(azure_id, manager))
    steps.append(add_to_groups(azure_id, name, role, department))
    steps.append(provision_exchange_mailbox(azure_id, name, upn))
    steps.append(add_to_teams(azure_id, name, department))
    steps.append(assign_sharepoint_access(azure_id, name, department))
    steps.append(assign_license(azure_id, name))

    completed = sum(1 for s in steps if s["status"] == "success")
    failed    = [s for s in steps if s["status"] == "failed"]

    return {"status": "success" if not failed else "partial",
            "azure_object_id": azure_id, "upn": upn, "temp_password": temp_pw,
            "steps": steps, "completed": completed, "failed_count": len(failed), "real": USE_REAL}


# ════════════════════════════════════════════════════════════════
#  OFFBOARDING
# ════════════════════════════════════════════════════════════════

def block_signin(azure_object_id: str, username: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("block_signin", {"message": f"[SIM] M365 sign-in blocked for {username}"})
    r = _graph("PATCH", f"/users/{azure_object_id}", {"accountEnabled": False})
    return _ok("block_signin", {"message": f"Sign-in blocked for {username}"}) if "error" not in r \
           else _fail("block_signin", r["error"])


def revoke_sessions(azure_object_id: str, username: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("revoke_sessions", {"message": f"[SIM] Sessions revoked for {username}"})
    r = _graph("POST", f"/users/{azure_object_id}/revokeSignInSessions")
    return _ok("revoke_sessions", {"message": f"All sessions revoked for {username}"}) if "error" not in r \
           else _fail("revoke_sessions", r["error"])


def remove_mfa_methods(azure_object_id: str, username: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("remove_mfa", {"message": f"[SIM] MFA methods removed for {username}"})
    methods = _graph("GET", f"/users/{azure_object_id}/authentication/methods")
    count = 0
    for m in methods.get("value", []):
        if "emailAuthenticationMethod" not in m.get("@odata.type", ""):
            _graph("DELETE", f"/users/{azure_object_id}/authentication/methods/{m['id']}")
            count += 1
    return _ok("remove_mfa", {"message": f"Removed {count} MFA method(s) for {username}"})


def set_out_of_office(azure_object_id: str, username: str, last_day: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("set_out_of_office", {"message": f"[SIM] OOF set for {username} — last day {last_day}"})
    r = _graph("PATCH", f"/users/{azure_object_id}/mailboxSettings", {
        "automaticRepliesSetting": {"status": "AlwaysEnabled",
            "internalReplyMessage": f"I left as of {last_day}. Contact hr@techcorp.com.",
            "externalReplyMessage": f"I left TechCorp as of {last_day}. Contact info@techcorp.com."}})
    return _ok("set_out_of_office", {"message": f"OOF configured for {username}"}) if "error" not in r \
           else _fail("set_out_of_office", r["error"])


def remove_license(azure_object_id: str, username: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("remove_license", {"message": f"[SIM] License removed for {username}"})
    user = _graph("GET", f"/users/{azure_object_id}/licenseDetails")
    skus = [l["skuId"] for l in user.get("value", [])]
    if not skus:
        return _ok("remove_license", {"message": f"No licenses found for {username}"})
    r = _graph("POST", f"/users/{azure_object_id}/assignLicenses",
               {"addLicenses": [], "removeLicenses": skus})
    return _ok("remove_license", {"message": f"Removed {len(skus)} license(s) from {username}"}) \
           if "error" not in r else _fail("remove_license", r["error"])


def wipe_intune_device(device_id: str, username: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("wipe_device", {"message": f"[SIM] Intune wipe queued for {username}'s device"})
    r = _graph("POST", f"/deviceManagement/managedDevices/{device_id}/wipe", {})
    return _ok("wipe_device", {"message": f"Device wipe triggered for {username}"}) if "error" not in r \
           else _fail("wipe_device", r["error"])


def run_full_m365_offboarding(azure_object_id: str, username: str, last_day: str) -> list:
    return [block_signin(azure_object_id, username),
            revoke_sessions(azure_object_id, username),
            remove_mfa_methods(azure_object_id, username),
            set_out_of_office(azure_object_id, username, last_day),
            remove_license(azure_object_id, username)]


# ════════════════════════════════════════════════════════════════
#  MOVER
# ════════════════════════════════════════════════════════════════

def update_user_department(azure_object_id: str, name: str, new_dept: str, new_role: str) -> dict:
    USE_REAL = _use_real()
    new_title = ROLE_TITLES.get(new_role.lower(), new_role.replace("_", " ").title())
    if not USE_REAL:
        return _ok("update_department", {"message": f"[SIM] {name} moved to {new_dept} — title: {new_title}"})
    r = _graph("PATCH", f"/users/{azure_object_id}", {"department": new_dept, "jobTitle": new_title})
    return _ok("update_department", {"message": f"{name} department updated to {new_dept}"}) \
           if "error" not in r else _fail("update_department", r["error"])


def transfer_groups(azure_object_id: str, name: str,
                    from_dept: str, to_dept: str) -> dict:
    USE_REAL = _use_real()
    old_groups = DEPT_GROUPS.get(from_dept, [])
    new_groups = DEPT_GROUPS.get(to_dept, [])
    if not USE_REAL:
        return _ok("transfer_groups", {
            "message": f"[SIM] {name} removed from {from_dept} groups, added to {to_dept} groups",
            "removed": old_groups, "added": new_groups})
    return _ok("transfer_groups", {"message": f"Group transfer simulated for {name}",
               "removed": old_groups, "added": new_groups})


# ════════════════════════════════════════════════════════════════
#  READ HELPERS
# ════════════════════════════════════════════════════════════════

def list_azure_users(limit: int = 20) -> list:
    USE_REAL = _use_real()
    if not USE_REAL:
        roles  = ["Developer", "HR Manager", "IT Admin", "Finance Analyst", "Intern"]
        depts  = ["Engineering", "HR", "IT-Admin", "Finance", "Internship"]
        domain = os.getenv("AZURE_TENANT_DOMAIN", "yourtenant.onmicrosoft.com")
        return [{"id": f"sim-{i}", "displayName": f"Demo User {i}",
                 "userPrincipalName": f"demo{i}@{domain}",
                 "department": depts[i % len(depts)], "jobTitle": roles[i % len(roles)],
                 "accountEnabled": i != 3} for i in range(1, 8)]
    r = _graph("GET", f"/users?$select=id,displayName,userPrincipalName,department,jobTitle,accountEnabled&$top={limit}&$orderby=displayName")
    return r.get("value", [])


def list_azure_groups() -> list:
    USE_REAL = _use_real()
    if not USE_REAL:
        names = ["SG-Engineering", "SG-IT-Admins", "SG-HR-Team", "SG-Finance-Team",
                 "SG-Sales-Team", "SG-Interns", "SG-All-Staff", "SG-VPN-Users",
                 "SG-Cybersecurity", "SG-Privileged-Users"]
        return [{"id": f"sim-g{i}", "displayName": n, "memberCount": random.randint(1, 25)}
                for i, n in enumerate(names)]
    r = _graph("GET", "/groups?$select=id,displayName,groupTypes&$top=50&$orderby=displayName")
    return r.get("value", [])


def grant_shared_mailbox_access(azure_object_id: str, name: str,
                                mailbox: str, permission: str = "FullAccess",
                                days: int = None) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        exp = f" for {days} day(s)" if days else " (permanent)"
        return _ok("shared_mailbox", {
            "message": f"[SIM] {name} granted {permission} to {mailbox}{exp}"})
    payload = {
        "identity": {"id": azure_object_id, "type": "User"},
        "access": permission
    }
    r = _graph("POST", f"/users/{mailbox}/mailboxSettings", payload)
    return _ok("shared_mailbox", {
        "message": f"{name} granted {permission} to {mailbox}",
        "days": days, "real": True
    }) if "error" not in r else _fail("shared_mailbox", r.get("error"))


def get_user_sign_in_activity(upn: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return {"lastSignIn": "2025-04-01T10:23:00Z", "simulated": True}
    r = _graph("GET", f"/users/{upn}?$select=signInActivity")
    return r.get("signInActivity", {})


def get_user_by_upn(upn: str) -> dict:
    USE_REAL = _use_real()
    if not USE_REAL:
        return {"id": "sim-abc123", "displayName": "Simulated User",
                "userPrincipalName": upn, "accountEnabled": True}
    return _graph("GET", f"/users/{upn}?$select=id,displayName,userPrincipalName,department,jobTitle,accountEnabled")


def resolve_azure_object_id(name: str, stored_id: str = None, stored_upn: str = None) -> dict:
    """
    Reliably resolve a real Azure Object ID before offboarding.

    Priority order:
      1. stored_id if it looks real (not sim-*)
      2. stored_upn lookup
      3. displayName search
      4. UPN built from name + tenant domain
      5. Fallback to stored_id (might still work)

    Returns {"id": "<object_id>", "upn": "<upn>", "found": True/False}
    """
    USE_REAL = _use_real()
    if not USE_REAL:
        return {"id": stored_id or "sim-unknown", "upn": stored_upn or "", "found": False, "simulated": True}

    # Strategy 1: stored_id looks like a real UUID
    if stored_id and not stored_id.startswith("sim-") and len(stored_id) > 20:
        r = _graph("GET", f"/users/{stored_id}?$select=id,displayName,userPrincipalName,accountEnabled")
        if "id" in r:
            return {"id": r["id"], "upn": r.get("userPrincipalName", ""), "found": True, "source": "stored_id"}

    # Strategy 2: stored_upn lookup
    if stored_upn and "@" in stored_upn:
        r = _graph("GET", f"/users/{stored_upn}?$select=id,displayName,userPrincipalName,accountEnabled")
        if "id" in r:
            return {"id": r["id"], "upn": r.get("userPrincipalName", ""), "found": True, "source": "stored_upn"}

    # Strategy 3: search by displayName
    if name:
        r = _graph("GET", f"/users?$filter=displayName eq '{name}'&$select=id,displayName,userPrincipalName,accountEnabled&$top=5")
        users = r.get("value", [])
        if users:
            u = users[0]
            return {"id": u["id"], "upn": u.get("userPrincipalName", ""), "found": True, "source": "display_name_search"}

    # Strategy 4: build UPN from name + tenant domain
    built_upn = _build_upn(name) if name else None
    if built_upn:
        r = _graph("GET", f"/users/{built_upn}?$select=id,displayName,userPrincipalName,accountEnabled")
        if "id" in r:
            return {"id": r["id"], "upn": r.get("userPrincipalName", ""), "found": True, "source": "built_upn"}

    # Strategy 5: first-name search (handles "Alok" → "alok@...")
    if name:
        first = name.split()[0]
        r = _graph("GET", f"/users?$filter=startswith(displayName,'{first}')&$select=id,displayName,userPrincipalName&$top=3")
        for u in r.get("value", []):
            if u.get("displayName", "").lower() == name.lower():
                return {"id": u["id"], "upn": u.get("userPrincipalName", ""), "found": True, "source": "partial_search"}

    return {"id": stored_id, "upn": stored_upn or "", "found": False, "source": "fallback",
            "warning": f"Could not resolve Azure Object ID for '{name}' — offboarding may fail"}


def _build_upn(name: str) -> str:
    domain = os.getenv("AZURE_TENANT_DOMAIN", "yourtenant.onmicrosoft.com")
    clean = name.lower().replace(" ", ".").replace("'", "").replace("-", "")
    return f"{clean}@{domain}"


def _temp_password() -> str:
    return f"Tc@{''.join(random.choices(string.ascii_letters + string.digits, k=8))}!"


def _ok(step: str, data: dict) -> dict:
    return {"step": step, "status": "success", "real": _use_real(),
            "timestamp": datetime.utcnow().isoformat(), **data}


def _fail(step: str, error) -> dict:
    return {"step": step, "status": "failed", "real": _use_real(),
            "error": str(error), "timestamp": datetime.utcnow().isoformat()}

def delete_azure_user(azure_object_id: str, username: str) -> dict:
    """
    Delete user from Azure AD.
    Step 1: Soft-delete  → DELETE /users/{id}         (30-day recycle bin)
    Step 2: Hard-delete  → DELETE /directory/deletedItems/{id}  (permanent)
    Requires: User.ReadWrite.All + Directory.ReadWrite.All (Admin Consent)
    """
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("delete_user", {"message": f"[SIM] User {username} permanently deleted from Azure AD"})

    # Step 1: Soft-delete
    r = _graph("DELETE", f"/users/{azure_object_id}")
    if "error" in r:
        code = r.get("code", 0)
        err  = r.get("error", "Unknown error")
        if code == 404:
            # Already soft-deleted — attempt hard delete from recycle bin
            hd = _graph("DELETE", f"/directory/deletedItems/{azure_object_id}")
            if "error" not in hd:
                return _ok("delete_user", {"message": f"{username} permanently removed from Azure AD recycle bin."})
            return _ok("delete_user", {"message": f"{username} was already deleted from Azure AD."})
        if code == 403:
            return _fail("delete_user",
                "Permission denied (403). Ensure your App Registration has "
                "User.ReadWrite.All + Directory.ReadWrite.All with Admin Consent granted.")
        return _fail("delete_user", f"Delete failed (HTTP {code}): {err}")

    # Step 2: Hard-delete immediately from recycle bin
    import time as _time; _time.sleep(1)
    hd = _graph("DELETE", f"/directory/deletedItems/{azure_object_id}")
    if "error" in hd:
        return _ok("delete_user", {
            "message": f"{username} soft-deleted from Azure AD (auto-purges in 30 days). To hard-delete manually: Azure Portal → Deleted users → Permanently delete.",
            "soft_deleted": True
        })
    return _ok("delete_user", {
        "message": f"{username} permanently and irrecoverably deleted from Azure AD.",
        "hard_deleted": True
    })


def archive_mailbox(azure_object_id: str, username: str) -> dict:
    """
    Best-effort mailbox archive — hide from GAL. Non-fatal so deletion proceeds.
    Full litigation hold requires Exchange Online PS (not Graph).
    """
    USE_REAL = _use_real()
    if not USE_REAL:
        return _ok("archive_mailbox", {"message": f"[SIM] Mailbox archived for {username}"})
    r = _graph("PATCH", f"/users/{azure_object_id}", {"showInAddressList": False})
    if r.get("code") == 404:
        return {"step": "archive_mailbox", "status": "warning",
                "message": "User not found in Azure (may be already deleted).",
                "real": True, "timestamp": datetime.utcnow().isoformat()}
    if "error" in r:
        return {"step": "archive_mailbox", "status": "warning",
                "message": f"Mailbox archive skipped (Exchange license required): {r['error']}",
                "real": True, "timestamp": datetime.utcnow().isoformat()}
    return _ok("archive_mailbox", {"message": f"Mailbox hidden from address list for {username}"})


def list_azure_users_full(limit: int = 100) -> list:
    """Fetch full user list from Azure AD including department, jobTitle, accountEnabled."""
    USE_REAL = _use_real()
    if not USE_REAL:
        return list_azure_users(limit)
    r = _graph("GET", f"/users?$select=id,displayName,userPrincipalName,department,jobTitle,accountEnabled,mail,mobilePhone&$top={limit}&$orderby=displayName")
    return r.get("value", [])
