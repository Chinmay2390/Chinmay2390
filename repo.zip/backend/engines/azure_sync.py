"""
azure_sync.py — Sync Azure AD users into SQLite
================================================
When USE_REAL_GRAPH=true, this replaces seed employee data with real
Azure AD users. Called on startup from main.py.

Roles are still seeded from code (not Azure — Azure has no HR roles concept).
Employees come entirely from Entra ID.
"""
import os
from datetime import datetime
from sqlalchemy.orm import Session


DEPT_TO_ROLE = {
    "Engineering":   "developer",
    "IT-Admin":      "admin",
    "IT":            "admin",
    "HR":            "hr_manager",
    "Finance":       "finance",
    "Sales":         "sales",
    "Operations":    "developer",
    "Cybersecurity": "admin",
    "Legal":         "hr_manager",
    "Marketing":     "sales",
    "Internship":    "intern",
}

ROLE_DEFS = [
    {"name": "admin",      "level": "high",     "description": "Full administrator",
     "permissions": {"Active Directory": "full_control", "AWS": "admin", "GitHub": "admin",
                     "Jira": "admin", "HRMS": "admin", "Slack": "admin", "VPN": "admin"}},
    {"name": "developer",  "level": "medium",   "description": "Software developer",
     "permissions": {"GitHub": "write", "AWS": "developer", "Jira": "write",
                     "Slack": "write", "VPN": "read"}},
    {"name": "hr_manager", "level": "medium",   "description": "HR operations",
     "permissions": {"HRMS": "full_access", "Slack": "write"}},
    {"name": "finance",    "level": "high",     "description": "Finance team",
     "permissions": {"Finance System": "full_access", "Slack": "write"}},
    {"name": "sales",      "level": "standard", "description": "Sales team",
     "permissions": {"CRM": "write", "Slack": "write"}},
    {"name": "intern",     "level": "low",      "description": "Intern access",
     "permissions": {"GitHub": "read", "Slack": "read"}},
]

ASSET_SPECS = [
    ("LAPTOP", "Dell XPS 15", f"SN-{str(i).zfill(3)}") for i in range(1, 6)
] + [
    ("PHONE", "iPhone 14", f"PH-{str(i).zfill(3)}") for i in range(1, 4)
]


def seed_roles_and_assets(db):
    """Always run — seeds roles and a few assets (no employees)."""
    from models import Role, RolePermission, Asset

    role_map = {}
    for rd in ROLE_DEFS:
        role = db.query(Role).filter(Role.name == rd["name"]).first()
        if not role:
            role = Role(name=rd["name"], level=rd["level"], description=rd["description"])
            db.add(role)
            db.flush()
            for sys, perm in rd["permissions"].items():
                db.add(RolePermission(role_id=role.id, system=sys, permission=perm))
        role_map[rd["name"]] = role

    for (atype, model, sn) in ASSET_SPECS:
        from models import Asset
        if not db.query(Asset).filter(Asset.serial_no == sn).first():
            tag = f"{atype[:3].upper()}-{sn}"
            db.add(Asset(asset_tag=tag, asset_type=atype, model=model,
                         serial_no=sn, status="available"))

    db.commit()
    return role_map


def sync_azure_users(db):
    """
    Fetch real Azure AD users and upsert them into SQLite employees table.
    Existing employees with azure_object_id are updated; new ones are created.
    Employees in SQLite that no longer exist in Azure are marked accordingly.
    """
    from models import Employee, Role
    from engines.microsoft_graph import list_azure_users_full

    print("[Azure Sync] Fetching users from Azure AD...")
    azure_users = list_azure_users_full(200)
    if not azure_users:
        print("[Azure Sync] No users returned — check Graph permissions.")
        return

    role_map = {r.name: r for r in db.query(Role).all()}
    synced = 0

    for u in azure_users:
        obj_id = u.get("id")
        upn    = u.get("userPrincipalName", "")
        name   = u.get("displayName", "Unknown")
        dept   = u.get("department") or "General"
        title  = u.get("jobTitle", "")
        enabled = u.get("accountEnabled", True)
        email  = u.get("mail") or upn
        phone  = u.get("mobilePhone", "")

        # Determine role from department
        role_name = DEPT_TO_ROLE.get(dept, "developer")
        role = role_map.get(role_name) or role_map.get("developer")

        # Build a unique employee_id
        emp_id_str = f"AZ-{obj_id[:8].upper()}"

        # Try to find existing record
        emp = db.query(Employee).filter(Employee.azure_object_id == obj_id).first()
        if not emp:
            emp = db.query(Employee).filter(Employee.azure_upn == upn).first()
        if not emp:
            emp = db.query(Employee).filter(Employee.email == email).first()

        if emp:
            # Update existing
            emp.name             = name
            emp.department       = dept
            emp.designation      = title
            emp.azure_object_id  = obj_id
            emp.azure_upn        = upn
            emp.ad_username      = upn.split("@")[0]
            emp.phone            = phone or emp.phone
            if not emp.email or "@" not in emp.email:
                emp.email = email
            # Respect local offboarding — if disabled in Azure and not already disabled in our DB
            if not enabled and emp.status == "active":
                emp.status = "disabled"
                emp.disabled_at = emp.disabled_at or datetime.utcnow()
            elif enabled and emp.status not in ("pending_approval", "disabled"):
                emp.status = "active"
            if role:
                emp.role_id = role.id
        else:
            # Create new
            emp = Employee(
                employee_id  = emp_id_str,
                name         = name,
                email        = email,
                department   = dept,
                designation  = title,
                ad_username  = upn.split("@")[0],
                azure_object_id = obj_id,
                azure_upn    = upn,
                phone        = phone,
                status       = "active" if enabled else "disabled",
                location     = "Azure AD",
                role_id      = role.id if role else None,
                joining_date = datetime.utcnow().strftime("%Y-%m-%d"),
                disabled_at  = datetime.utcnow() if not enabled else None,
            )
            db.add(emp)
        synced += 1

    db.commit()
    print(f"[Azure Sync] Synced {synced} users from Azure AD ✅")


def run_startup_sync(db):
    """Called from main.py on application startup."""
    use_real = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
    seed_roles_and_assets(db)
    if use_real:
        try:
            sync_azure_users(db)
        except Exception as e:
            print(f"[Azure Sync] Warning — could not sync: {e}")
    else:
        # Demo mode: seed a few fake employees if none exist
        _seed_demo_employees(db)


def _seed_demo_employees(db):
    """Seed demo employees for simulation mode only."""
    from models import Employee, Role
    if db.query(Employee).count() > 0:
        return
    role_map = {r.name: r for r in db.query(Role).all()}
    demos = [
        ("Rahul Sharma",  "admin",      "IT-Admin",   "rahul.sharma@demo.com"),
        ("Priya Desai",   "hr_manager", "HR",         "priya.desai@demo.com"),
        ("Amit Kulkarni", "finance",    "Finance",    "amit.kulkarni@demo.com"),
        ("Alice Johnson", "sales",      "Sales",      "alice.johnson@demo.com"),
        ("Bob Williams",  "developer",  "Engineering","bob.williams@demo.com"),
    ]
    import uuid
    for (name, role_name, dept, email) in demos:
        role = role_map.get(role_name)
        emp = Employee(
            employee_id = f"DEMO-{str(uuid.uuid4())[:6].upper()}",
            name=name, email=email, department=dept,
            ad_username=email.split("@")[0],
            azure_object_id=f"sim-{str(uuid.uuid4())[:8]}",
            azure_upn=email,
            status="active", location="Demo Office",
            role_id=role.id if role else None,
            joining_date=datetime.utcnow().strftime("%Y-%m-%d"),
        )
        db.add(emp)
    db.commit()
    print("[Seed] Demo employees created for simulation mode.")
