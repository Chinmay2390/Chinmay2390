"""
Enterprise JML Chatbot — Joiner · Mover · Leaver + M365 + Risk
"""
import os, re, json
from sqlalchemy.orm import Session

GROQ_KEY  = os.getenv("GROQ_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "llama-3.3-70b-versatile")

SYSTEM_PROMPT = """You are an enterprise JML (Joiner-Mover-Leaver) AI assistant for TechCorp Solutions.
You manage Azure AD, Microsoft 365, HR operations, and IT provisioning.

Return <ACTION> JSON for executable commands, then a friendly message after it.

JOINER (onboard):
"Create employee Alice as developer in Engineering, Pune"
→ <ACTION>{"type":"onboard","name":"Alice","department":"Engineering","role":"developer","location":"Pune"}</ACTION>

MOVER (transfer):
"Move Rahul from HR to Finance", "Transfer Bob to Engineering as developer"
→ <ACTION>{"type":"move","name":"Rahul","to_department":"Finance","to_role":"finance"}</ACTION>

LEAVER (offboard):
"Offboard Priya", "Deactivate John Smith, last day 2025-07-31"
→ <ACTION>{"type":"offboard","name":"Priya","last_day":"2025-07-31","reason":"resignation"}</ACTION>

SHARED MAILBOX:
"Give Amit temporary shared mailbox access to finance@co.com for 5 days"
→ <ACTION>{"type":"shared_mailbox","name":"Amit","mailbox":"finance@co.com","permission":"FullAccess","days":5}</ACTION>

RISK CHECK:
"Check risk for Alice", "Analyze exit risk for Bob"
→ <ACTION>{"type":"risk_check","name":"Alice"}</ACTION>

STATUS CHECK:
"Check if laptop is returned for John", "What is offboarding status of Priya"
→ <ACTION>{"type":"status_check","name":"John","check":"assets"}</ACTION>

COMPLIANCE:
"Generate access review report for Engineering"
→ <ACTION>{"type":"compliance","department":"Engineering","report":"access_review"}</ACTION>

Valid roles: admin, developer, hr_manager, finance, sales, intern
Valid departments: Engineering, IT-Admin, HR, Finance, Sales, Operations, Cybersecurity, Legal, Marketing, Internship
Valid offboard reasons: resignation, termination, retirement, contract_end

Always answer policy questions and status queries directly without ACTION blocks.
Maintain a professional, concise tone."""


def chat(message: str, db: Session) -> dict:
    context  = _build_context(db)
    response = _call_llm(message, context)
    action   = _extract_action(response)
    display  = _clean(response)
    result   = {"reply": display, "action_detected": action is not None,
                "action": action, "executed": False, "execution_result": None}

    if not action:
        return result

    t = action.get("type")

    if t == "onboard":
        from engines.onboarding import onboard_employee
        res = onboard_employee(db, name=action.get("name",""),
                               department=action.get("department","Engineering"),
                               role_name=action.get("role","intern"),
                               location=action.get("location","Head Office"),
                               performed_by="chatbot")
        result.update({"executed": True, "execution_result": res})

    elif t == "move":
        emp = _find_employee(action.get("name",""), db)
        if emp:
            from engines.mover import move_employee
            res = move_employee(db, emp.id,
                                to_department=action.get("to_department","Engineering"),
                                to_role_name=action.get("to_role","developer"),
                                performed_by="chatbot")
            result.update({"executed": True, "execution_result": res})
        else:
            result["reply"] += f"\n\n⚠️ Employee **{action.get('name')}** not found."

    elif t == "offboard":
        emp = _find_employee(action.get("name",""), db)
        if emp:
            from engines.offboarding import offboard_employee
            res = offboard_employee(db, emp.id,
                                    last_day=action.get("last_day") or _today(),
                                    reason=action.get("reason","resignation"),
                                    performed_by="chatbot")
            result.update({"executed": True, "execution_result": res})
        else:
            result["reply"] += f"\n\n⚠️ Employee **{action.get('name')}** not found."

    elif t == "shared_mailbox":
        emp = _find_employee(action.get("name",""), db)
        if emp:
            from engines.microsoft_graph import grant_shared_mailbox_access
            from models import M365Access
            res = grant_shared_mailbox_access(
                emp.azure_object_id or "sim", emp.name,
                action.get("mailbox",""), action.get("permission","FullAccess"),
                action.get("days"))
            access = M365Access(employee_id=emp.id, access_type="shared_mailbox",
                                resource=action.get("mailbox",""),
                                permission=action.get("permission","FullAccess"),
                                granted_by="chatbot")
            db.add(access); db.commit()
            result.update({"executed": True, "execution_result": res})
        else:
            result["reply"] += f"\n\n⚠️ Employee **{action.get('name')}** not found."

    elif t == "risk_check":
        emp = _find_employee(action.get("name",""), db)
        if emp:
            from engines.risk_analyzer import analyze_risk
            risk = analyze_risk(emp, db)
            result.update({"executed": True, "execution_result": risk,
                           "reply": display + f"\n\n**Risk Score: {risk.get('risk_score')}/100 — {risk.get('risk_level','').upper()}**\n{risk.get('summary','')}"})
        else:
            result["reply"] += f"\n\n⚠️ Employee **{action.get('name')}** not found."

    elif t == "status_check":
        emp = _find_employee(action.get("name",""), db)
        if emp:
            result.update({"executed": True, "execution_result": _get_status(emp, action.get("check",""), db)})
        else:
            result["reply"] += f"\n\n⚠️ Employee **{action.get('name')}** not found."

    elif t == "compliance":
        result.update({"executed": True,
                       "execution_result": _generate_compliance(db, action.get("department",""), action.get("report",""))})

    return result


def _get_status(emp, check: str, db) -> dict:
    from models import ExitChecklist, AssetAssignment
    if "asset" in check:
        assignments = db.query(AssetAssignment).filter(AssetAssignment.employee_id == emp.id).all()
        return {"employee": emp.name, "assets": [
            {"type": a.asset.asset_type, "tag": a.asset.asset_tag,
             "returned": not a.is_active} for a in assignments if a.asset]}
    checklist = db.query(ExitChecklist).filter(ExitChecklist.employee_id == emp.id).all()
    if checklist:
        done = sum(1 for i in checklist if i.is_completed)
        return {"employee": emp.name, "checklist_progress": f"{done}/{len(checklist)}",
                "items": [{"item": i.item, "done": i.is_completed} for i in checklist]}
    return {"employee": emp.name, "status": emp.status, "department": emp.department}


def _generate_compliance(db, department: str, report_type: str) -> dict:
    from models import Employee, EmployeeAccess
    q = db.query(Employee).filter(Employee.status == "active")
    if department:
        q = q.filter(Employee.department == department)
    employees = q.all()
    return {"report_type": report_type, "department": department or "All",
            "total_employees": len(employees),
            "generated_at": _today(),
            "employees": [{"name": e.name, "role": e.role_obj.name if e.role_obj else "N/A",
                           "access_count": len([a for a in e.access_list if a.is_active])}
                          for e in employees[:20]]}


def _find_employee(name: str, db: Session):
    from models import Employee
    if not name: return None
    name_lower = name.lower().strip()
    for e in db.query(Employee).filter(Employee.status.in_(["active","disabled","pending_approval"])).all():
        if e.name.lower() == name_lower or name_lower in e.name.lower() or e.name.lower() in name_lower:
            return e
    return None


def _today():
    from datetime import datetime
    return datetime.utcnow().strftime("%Y-%m-%d")


def _build_context(db: Session) -> str:
    try:
        from rag.rag_engine import build_enriched_context
        return build_enriched_context("general hr query", db)
    except Exception:
        pass
    from models import Employee, AuditLog
    emps = db.query(Employee).limit(30).all()
    lines = ["EMPLOYEES:"] + [f"  • {e.name} | {e.department} | {e.role_obj.name if e.role_obj else 'N/A'} | {e.status}" for e in emps]
    logs = db.query(AuditLog).order_by(AuditLog.timestamp.desc()).limit(10).all()
    lines += ["RECENT ACTIONS:"] + [f"  • {l.action} | {l.employee.name if l.employee else 'sys'} | {l.status}" for l in logs]
    return "\n".join(lines)


def _call_llm(message: str, context: str) -> str:
    full_system = f"{SYSTEM_PROMPT}\n\n--- LIVE CONTEXT ---\n{context}"
    if GROQ_KEY:
        try:
            from groq import Groq
            resp = Groq(api_key=GROQ_KEY).chat.completions.create(
                model=LLM_MODEL,
                messages=[{"role":"system","content":full_system},{"role":"user","content":message}],
                temperature=0.3, max_tokens=900)
            return resp.choices[0].message.content
        except Exception as e:
            return _rule_based(message) + f"\n\n_(LLM error: {e})_"
    return _rule_based(message)


def _rule_based(msg: str) -> str:
    m = msg.lower()
    if any(w in m for w in ["offboard","deactivate","terminate","exit","leaver"]):
        nm = re.search(r"(?:offboard|deactivate|terminate|exit)\s+([a-z][a-z\s]+?)(?:\s*,|\s+last|\s+reason|$)",m,re.I)
        ld = re.search(r"last\s+day\s+(\d{4}-\d{2}-\d{2})",m,re.I)
        name = nm.group(1).strip().title() if nm else "Unknown"
        last = ld.group(1) if ld else _today()
        return f'<ACTION>{{"type":"offboard","name":"{name}","last_day":"{last}","reason":"resignation"}}</ACTION>\nProcessing offboarding for **{name}**.'
    if any(w in m for w in ["move","transfer","mover"]):
        nm = re.search(r"(?:move|transfer)\s+([a-z][a-z\s]+?)\s+(?:from|to)",m,re.I)
        td = re.search(r"to\s+([A-Za-z\-]+)(?:\s+as\s+(\w+))?",m,re.I)
        name = nm.group(1).strip().title() if nm else "Unknown"
        dept = td.group(1).strip().title() if td else "Engineering"
        role = td.group(2).lower() if td and td.group(2) else "developer"
        return f'<ACTION>{{"type":"move","name":"{name}","to_department":"{dept}","to_role":"{role}"}}</ACTION>\nMoving **{name}** to **{dept}**.'
    if any(w in m for w in ["onboard","create","hire","add","joiner"]):
        nm = re.search(r"(?:onboard|create|hire|add)\s+([a-z][a-z\s]+?)\s+(?:as|in|for)",m,re.I)
        rl = re.search(r"\bas\s+(admin|developer|hr_manager|finance|sales|intern)\b",m,re.I)
        dp = re.search(r"\bin\s+([A-Za-z\-]+(?:\s+[A-Za-z]+)?)\b",m,re.I)
        name = nm.group(1).strip().title() if nm else "New Employee"
        role = rl.group(1).lower() if rl else "intern"
        dept = dp.group(1).strip().title() if dp else "Engineering"
        return f'<ACTION>{{"type":"onboard","name":"{name}","department":"{dept}","role":"{role}"}}</ACTION>\nOnboarding **{name}** as **{role}** in **{dept}**.'
    if "shared mailbox" in m:
        return '<ACTION>{"type":"shared_mailbox","name":"Unknown","mailbox":"shared@company.com","permission":"FullAccess","days":null}</ACTION>\nPlease specify employee name and mailbox address.'
    return ("👋 I'm your JML AI Assistant. I can:\n"
            "• **Onboard** — _\"Create Alice as developer in Engineering, Pune\"_\n"
            "• **Move** — _\"Transfer Bob from HR to Finance as finance analyst\"_\n"
            "• **Offboard** — _\"Deactivate Priya Sharma\"_\n"
            "• **Shared Mailbox** — _\"Give Amit access to finance@co.com for 5 days\"_\n"
            "• **Risk Check** — _\"Check risk for John\"_\n"
            "• **Compliance** — _\"Generate access review for Engineering\"_")


def _extract_action(text: str):
    match = re.search(r"<ACTION>\s*(\{.*?\})\s*</ACTION>", text, re.DOTALL)
    if not match: return None
    try:    return json.loads(match.group(1))
    except: return None


def _clean(text: str) -> str:
    return re.sub(r"<ACTION>.*?</ACTION>", "", text, flags=re.DOTALL).strip()
