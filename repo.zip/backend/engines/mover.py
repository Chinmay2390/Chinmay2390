"""Mover Engine — Department Transfer"""
from datetime import datetime
from sqlalchemy.orm import Session
from models import Employee, Role, AuditLog, MoverEvent, EmployeeAccess, M365Access
from engines.microsoft_graph import update_user_department, transfer_groups, add_to_teams, assign_sharepoint_access
from engines.email_engine import send_email


def move_employee(db, employee_id, to_department, to_role_name,
                  to_manager=None, effective_date=None,
                  reason="Internal transfer", performed_by="hr_system"):
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        return {"error": f"Employee {employee_id} not found"}
    if emp.status != "active":
        return {"error": f"{emp.name} is not active"}
    new_role = db.query(Role).filter(Role.name == to_role_name.lower()).first()
    if not new_role:
        return {"error": f"Role '{to_role_name}' not found"}

    from_dept = emp.department; from_role = emp.role_obj.name if emp.role_obj else "unknown"

    event = MoverEvent(
        employee_id=emp.id, from_department=from_dept, to_department=to_department,
        from_role=from_role, to_role=to_role_name, from_manager=emp.manager,
        to_manager=to_manager or emp.manager, effective_date=effective_date or datetime.utcnow().strftime("%Y-%m-%d"),
        reason=reason, status="in_progress", performed_by=performed_by)
    db.add(event); db.flush()

    steps = []
    # Revoke old access
    old = db.query(EmployeeAccess).filter(EmployeeAccess.employee_id == emp.id, EmployeeAccess.is_active == True).all()
    for a in old: a.is_active = False
    old_m365 = db.query(M365Access).filter(M365Access.employee_id == emp.id, M365Access.is_active == True).all()
    for a in old_m365: a.is_active = False
    steps.append({"step": "revoke_old_access", "status": "success", "message": f"Revoked {len(old)} old permissions"})

    # Azure AD update
    if emp.azure_object_id:
        steps += [
            update_user_department(emp.azure_object_id, emp.name, to_department, to_role_name),
            transfer_groups(emp.azure_object_id, emp.name, from_dept, to_department),
            add_to_teams(emp.azure_object_id, emp.name, to_department),
            assign_sharepoint_access(emp.azure_object_id, emp.name, to_department),
        ]
    else:
        steps.append({"step": "azure_update", "status": "skipped", "message": "No azure_object_id"})

    # Grant new access
    from engines.rbac import provision_access
    provisioned = provision_access(db, emp, new_role, performed_by)
    steps.append({"step": "grant_new_access", "status": "success", "message": f"Granted {len(provisioned)} new permissions"})

    emp.department = to_department; emp.role_id = new_role.id
    if to_manager: emp.manager = to_manager
    event.status = "completed"; event.completed_at = datetime.utcnow()
    event.old_access_revoked = True; event.new_access_granted = True

    # Notify
    send_email(db, emp.email, f"Transfer Confirmation — {emp.name}",
               f"You have been transferred from {from_dept} to {to_department}.", emp.name)
    _log(db, emp.id, "MOVER_COMPLETE", "HR System", performed_by, "success",
         f"{emp.name}: {from_dept}/{from_role} → {to_department}/{to_role_name}")
    db.commit()
    return {"status": "success", "employee_id": emp.employee_id, "name": emp.name,
            "from_department": from_dept, "to_department": to_department,
            "from_role": from_role, "to_role": to_role_name,
            "steps": steps, "access_granted": len(provisioned)}


def get_mover_history(db, employee_id=None):
    q = db.query(MoverEvent)
    if employee_id: q = q.filter(MoverEvent.employee_id == employee_id)
    events = q.order_by(MoverEvent.created_at.desc()).limit(50).all()
    return [{"id": e.id, "employee_id": e.employee.employee_id if e.employee else None,
             "name": e.employee.name if e.employee else "Unknown",
             "from_department": e.from_department, "to_department": e.to_department,
             "from_role": e.from_role, "to_role": e.to_role,
             "effective_date": e.effective_date, "status": e.status,
             "created_at": e.created_at.isoformat()} for e in events]


def _log(db, emp_id, action, system, by, status, details):
    db.add(AuditLog(employee_id=emp_id, action=action, system=system,
                    performed_by=by, status=status, details=details))
