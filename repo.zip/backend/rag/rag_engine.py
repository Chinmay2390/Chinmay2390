"""
RAG (Retrieval-Augmented Generation) Engine
--------------------------------------------
Embeds company policy documents into a FAISS vector store.
On each chatbot query, retrieves the top-3 most relevant policy
chunks and injects them into the LLM system prompt.

CAG (Cache-Augmented Generation)
---------------------------------
Injects live employee list + recent audit logs directly into
the LLM context as structured text — zero embedding cost.

Both work together in build_enriched_context().
"""
import os
import json
import re
from typing import List, Tuple
from loguru import logger

try:
    import numpy as np
    import faiss
    from sentence_transformers import SentenceTransformer
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False
    logger.warning("[RAG] faiss-cpu or sentence-transformers not installed — RAG disabled. Chatbot still works via CAG.")

DATA_FILE = os.path.join(os.path.dirname(__file__), "../../data/dummy_data.json")


class RAGEngine:
    """
    Loads company policies → chunks → embeds → FAISS index.
    retrieve(query) returns top-k relevant chunks.
    """

    def __init__(self):
        self.model      = None
        self.index      = None
        self.chunks:     List[str]  = []
        self.chunk_meta: List[dict] = []

        if not RAG_AVAILABLE:
            return

        try:
            logger.info("[RAG] Loading sentence-transformer model (all-MiniLM-L6-v2)...")
            self.model = SentenceTransformer("all-MiniLM-L6-v2")
            self._build_index()
            logger.info(f"[RAG] Index ready — {len(self.chunks)} chunks from {self._policy_count()} policies")
        except Exception as e:
            logger.error(f"[RAG] Initialisation failed: {e}")

    def _policy_count(self):
        try:
            with open(DATA_FILE) as f:
                return len(json.load(f).get("policies", []))
        except Exception:
            return 0

    def _load_policies(self) -> List[dict]:
        try:
            with open(DATA_FILE) as f:
                return json.load(f).get("policies", [])
        except Exception as e:
            logger.error(f"[RAG] Cannot load policies: {e}")
            return []

    def _chunk_text(self, text: str, chunk_size: int = 200, overlap: int = 30) -> List[str]:
        words  = text.split()
        chunks = []
        step   = chunk_size - overlap
        for i in range(0, len(words), step):
            chunk = " ".join(words[i: i + chunk_size])
            if chunk.strip():
                chunks.append(chunk)
        return chunks

    def _build_index(self):
        policies = self._load_policies()
        if not policies:
            return

        all_chunks, all_meta = [], []
        for policy in policies:
            for chunk in self._chunk_text(policy["content"]):
                all_chunks.append(chunk)
                all_meta.append({"id": policy["id"], "title": policy["title"]})

        if not all_chunks:
            return

        embeddings = self.model.encode(all_chunks, show_progress_bar=False)
        embeddings = np.array(embeddings, dtype=np.float32)
        faiss.normalize_L2(embeddings)

        dim        = embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)
        self.index.add(embeddings)
        self.chunks     = all_chunks
        self.chunk_meta = all_meta

    def retrieve(self, query: str, top_k: int = 3) -> List[Tuple[str, str, float]]:
        """
        Returns list of (chunk_text, policy_title, relevance_score).
        Returns [] if RAG not available or no relevant chunks found.
        """
        if not RAG_AVAILABLE or self.index is None or self.model is None:
            return []
        try:
            q_vec = self.model.encode([query], show_progress_bar=False)
            q_vec = np.array(q_vec, dtype=np.float32)
            faiss.normalize_L2(q_vec)

            scores, indices = self.index.search(q_vec, top_k)
            results = []
            for score, idx in zip(scores[0], indices[0]):
                if idx >= 0 and float(score) > 0.2:
                    results.append((
                        self.chunks[idx],
                        self.chunk_meta[idx]["title"],
                        float(score)
                    ))
            return results
        except Exception as e:
            logger.error(f"[RAG] retrieve() failed: {e}")
            return []


class CAGCache:
    """
    Cache-Augmented Generation: injects live DB context into LLM prompts.
    No embeddings needed — structured text is injected directly.
    """

    def build_employee_context(self, db) -> str:
        try:
            from models import Employee
            employees = db.query(Employee).filter(
                Employee.status == "active"
            ).limit(60).all()

            lines = [f"ACTIVE EMPLOYEES ({len(employees)} total):"]
            for e in employees:
                role = e.role_obj.name if e.role_obj else "N/A"
                lines.append(
                    f"  • {e.name} | ID:{e.employee_id} | {e.department} "
                    f"| Role:{role} | {e.location}"
                )
            return "\n".join(lines)
        except Exception as e:
            logger.error(f"[CAG] build_employee_context failed: {e}")
            return "Employee data unavailable."

    def build_recent_logs_context(self, db, limit: int = 25) -> str:
        try:
            from models import AuditLog
            logs = db.query(AuditLog).order_by(
                AuditLog.timestamp.desc()
            ).limit(limit).all()

            lines = [f"\nRECENT ACTIONS (last {limit}):"]
            for l in logs:
                emp = l.employee.name if l.employee else "System"
                lines.append(
                    f"  • [{l.timestamp.strftime('%d-%b %H:%M')}] "
                    f"{l.action} | {emp} | {l.system} | {l.status}"
                )
            return "\n".join(lines)
        except Exception as e:
            logger.error(f"[CAG] build_recent_logs_context failed: {e}")
            return "Log data unavailable."

    def build_policy_summary(self) -> str:
        try:
            with open(DATA_FILE) as f:
                policies = json.load(f).get("policies", [])
            lines = ["\nCOMPANY POLICIES (summary):"]
            for p in policies:
                snippet = p["content"][:160].replace("\n", " ")
                lines.append(f"  [{p['title']}]: {snippet}...")
            return "\n".join(lines)
        except Exception:
            return ""


# ── Singletons ──────────────────────────────────────────────────────────────
_rag_instance   = None
_cache_instance = CAGCache()


def get_rag() -> RAGEngine:
    global _rag_instance
    if _rag_instance is None:
        _rag_instance = RAGEngine()
    return _rag_instance


def build_enriched_context(query: str, db) -> str:
    """
    Combines RAG (policy retrieval) + CAG (live DB context).
    Called before every LLM request.
    """
    cache = _cache_instance
    parts = []

    # CAG: live employee list
    parts.append(cache.build_employee_context(db))

    # CAG: recent audit log actions
    parts.append(cache.build_recent_logs_context(db))

    # CAG: policy summaries (always included as fallback)
    parts.append(cache.build_policy_summary())

    # RAG: semantic retrieval of relevant policy chunks
    rag    = get_rag()
    chunks = rag.retrieve(query, top_k=3)
    if chunks:
        policy_ctx = "\nSEMANTICALLY RELEVANT POLICY SECTIONS:"
        for text, title, score in chunks:
            policy_ctx += f"\n\n  [{title}  — relevance: {score:.2f}]\n  {text}"
        parts.append(policy_ctx)

    return "\n\n".join(parts)
