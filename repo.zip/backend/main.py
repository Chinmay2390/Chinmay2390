import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
load_dotenv()

from database import engine, Base
import models
Base.metadata.create_all(bind=engine)

from engines.azure_sync import run_startup_sync
from database import SessionLocal
db = SessionLocal()
try:
    run_startup_sync(db)
finally:
    db.close()

from routers import employees, onboard, approvals, logs, chatbot, assets, roles
from routers import offboard, system_status, azure_ad, mover, leaver

app = FastAPI(title="JML Enterprise Platform", version="3.1.0",
              description="Joiner-Mover-Leaver — Azure AD + M365")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

app.include_router(employees.router,     prefix="/api")
app.include_router(onboard.router,       prefix="/api")
app.include_router(approvals.router,     prefix="/api")
app.include_router(logs.router,          prefix="/api")
app.include_router(chatbot.router,       prefix="/api")
app.include_router(assets.router,        prefix="/api")
app.include_router(roles.router,         prefix="/api")
app.include_router(offboard.router,      prefix="/api")
app.include_router(system_status.router, prefix="/api")
app.include_router(azure_ad.router,      prefix="/api")
app.include_router(mover.router,         prefix="/api")
app.include_router(leaver.router,        prefix="/api")

@app.get("/health")
def health():
    return {"status": "ok", "version": "3.1.0", "platform": "JML Enterprise"}

@app.get("/")
def root():
    return {"message": "JML Enterprise Platform v3.1.0 — /docs for API reference"}

@app.post("/api/sync-azure")
def manual_sync():
    """Manually re-sync Azure AD users into SQLite."""
    db2 = SessionLocal()
    try:
        from engines.azure_sync import sync_azure_users
        sync_azure_users(db2)
        return {"status": "ok", "message": "Azure AD sync complete"}
    except Exception as e:
        return {"status": "error", "error": str(e)}
    finally:
        db2.close()
