# API Keys & Integration Guide
## HR Onboarding & Offboarding Automation System

---

## How to know if you're on Dummy DB or Real AD

### Live Status Bar (easiest way)
Look at the **bottom of the sidebar** in the app.
Each integration shows:
- 🟢 `LIVE` — Connected to real system
- ⚫ `SIM` — Running in simulation mode (dummy)

### API endpoint
```
GET http://localhost:8000/api/status/
```
Returns JSON like:
```json
{
  "database":          { "mode": "SQLite (Dummy DB)",   "real": false },
  "active_directory":  { "mode": "Simulated (Dummy)",   "real": false },
  "microsoft_365":     { "mode": "Simulated (Dummy)",   "real": false },
  "email":             { "mode": "Simulated (DB only)", "real": false },
  "llm_chatbot":       { "mode": "Groq Llama 3.3 70B",  "real": true  }
}
```

---

## API Keys — Where to Add Them

All keys go in `backend/.env`

### 1. GROQ_API_KEY — AI Chatbot & Risk Scoring
- **Status:** Optional (fallback works without it)
- **Get free key:** https://console.groq.com → Sign Up → API Keys → Create Key
- **Add to .env:**
  ```
  GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxx
  ```
- **What it enables:** Natural language chatbot ("Onboard Rahul as developer"),
  LLM-powered risk scoring during offboarding

---

### 2. Gmail SMTP — Real Email Sending
- **Status:** Optional (emails stored in DB by default)
- **Setup steps:**
  1. Enable 2FA on your Gmail account
  2. Go to: https://myaccount.google.com/apppasswords
  3. Click "Create App Password" → name it "HR System"
  4. Copy the 16-character password (looks like: `abcd efgh ijkl mnop`)
- **Add to .env:**
  ```
  USE_REAL_EMAIL=true
  GMAIL_ADDRESS=yourname@gmail.com
  GMAIL_APP_PASSWORD=abcd efgh ijkl mnop
  SECURITY_TEAM_EMAIL=security@yourcompany.com
  ```
- **What it enables:** Real welcome emails to new employees,
  real offboard emails, real security alerts for high-risk offboardings

---

### 3. Microsoft Graph / Azure — Real M365 Integration
- **Status:** Optional (M365 steps simulated by default)
- **Setup steps:**
  1. Go to https://portal.azure.com
  2. Azure Active Directory → App Registrations → New Registration
  3. Name: "HR Automation System" → Register
  4. Copy the **Application (client) ID** → `AZURE_CLIENT_ID`
  5. Copy the **Directory (tenant) ID** → `AZURE_TENANT_ID`
  6. Certificates & Secrets → New Client Secret → Copy value → `AZURE_CLIENT_SECRET`
  7. API Permissions → Add:
     - `User.ReadWrite.All`
     - `Directory.ReadWrite.All`
     - `Mail.ReadWrite`
     - `DeviceManagementManagedDevices.PrivilegedOperations.All`
  8. Click "Grant Admin Consent"
- **Add to .env:**
  ```
  USE_REAL_GRAPH=true
  AZURE_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
  AZURE_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
  AZURE_CLIENT_SECRET=your~secret~value~here
  ```
- **What it enables:** Blocking real M365 sign-in, revoking real sessions,
  removing real MFA devices, setting real out-of-office replies

---

### 4. Active Directory (Windows DC) — Real AD Integration
- **Status:** Optional (fully simulated by default)
- **Requirements:** Windows Server with Active Directory + WinRM enabled
- **Setup steps:**
  1. On your Windows DC, run PowerShell as Administrator:
     ```powershell
     winrm quickconfig
     Enable-PSRemoting -Force
     ```
  2. Fill in your DC details:
- **Add to .env:**
  ```
  USE_REAL_AD=true
  AD_SERVER=dc01.yourcompany.local
  AD_USERNAME=administrator
  AD_PASSWORD=your_admin_password
  AD_DOMAIN=YOURCOMPANY
  ```
- **What it enables:** Real AD account creation/disabling, real group removal,
  real OU moves, real session clearing

---

## Current State Summary

| Integration | Default Mode | Set to REAL |
|-------------|-------------|-------------|
| Database    | SQLite dummy | Change DATABASE_URL to PostgreSQL |
| AI Chatbot  | Rule-based   | Add GROQ_API_KEY |
| Email       | DB simulator | Set USE_REAL_EMAIL=true + Gmail |
| Active Dir  | Simulated    | Set USE_REAL_AD=true + AD creds |
| Microsoft 365 | Simulated  | Set USE_REAL_GRAPH=true + Azure |

**You can enable any one independently** — e.g. use real email + simulated AD,
or real Groq + simulated everything else. They're fully independent.

---

## Quick Test — Verify Everything Works

```bash
# 1. Check status endpoint
curl http://localhost:8000/api/status/

# 2. Check active employees (should show 6 seeded employees)
curl http://localhost:8000/api/offboard/active

# 3. Check API docs
open http://localhost:8000/docs
```

