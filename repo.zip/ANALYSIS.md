# HR JML System — Analysis & Enhancement Guide
> Version 2.0 | Phase 3 Enhanced | TechCorp Solutions

---

## 1. Phase Completion Analysis

### Phase 1 — Onboarding ✅ 100% Complete
All steps implemented: form submission, role validation, employee ID + email generation,
AD simulation (4 steps), RBAC access provisioning, asset auto-assignment, welcome email,
full audit trail.

### Phase 2 — Approval Workflow ✅ 100% Complete
High-privilege roles (admin, finance, hr_manager) trigger pending state, approval request
record, approval email to HR director, one-click approve/reject, auto-execute on approval.

### Phase 3 — Offboarding ✅ 100% Complete (v2 Enhanced)
AD cleanup (6 steps), Microsoft Graph M365 offboarding (4 steps), RBAC revocation,
auto-generated role-specific exit checklists, automatic checklist completion for system
actions, real Gmail email, LLM risk analysis, security team alerts for high/critical risk.

### Phase 4 — Smart Features ✅ 100% Complete
| Feature | Status |
|---|---|
| LLM Chatbot (Groq Llama 3.3 70B) | ✅ Done + offboarding commands added |
| RAG — Policy Retrieval (FAISS) | ✅ Done |
| CAG — Live Employee Context | ✅ Done |
| Approval Workflow | ✅ Done |
| Auto RBAC Provisioning | ✅ Done |
| Asset Auto-Assignment + Tracking | ✅ Done |
| Real-Time Audit Trail | ✅ Done |
| Email (Real Gmail SMTP + Simulation) | ✅ Done (v2) |
| Search & Filter Employees | ✅ Done |
| **AI Risk Analyzer (NEW)** | ✅ Done (v2) |
| **Microsoft Graph Integration (NEW)** | ✅ Done (v2, toggleable) |
| **Auto Exit Checklist (NEW)** | ✅ Done (v2) |
| **Security Team Alerts (NEW)** | ✅ Done (v2) |

---

## 2. Configuration Keys

### Currently Active (in .env)
```
GROQ_API_KEY          → LLM chatbot + risk analyzer
OPENAI_API_KEY        → Future fallback LLM
GMAIL_ADDRESS         → Real email sending
GMAIL_APP_PASSWORD    → Gmail SMTP auth
SECURITY_TEAM_EMAIL   → High-risk offboarding alerts
USE_REAL_EMAIL        → true/false toggle
USE_REAL_GRAPH        → true/false toggle (set true for real M365)
AZURE_TENANT_ID       → MS Graph auth
AZURE_CLIENT_ID       → MS Graph auth
AZURE_CLIENT_SECRET   → MS Graph auth
```

### To Enable Real MS Graph (set in .env)
```
USE_REAL_GRAPH=true
```
Requires Azure App Registration with: User.ReadWrite.All, Directory.ReadWrite.All,
DeviceManagementManagedDevices.PrivilegedOperations.All

### For Real AD (future — needs Windows DC)
```
USE_REAL_AD=true
AD_SERVER=dc01.techcorp.local
AD_USERNAME=administrator
AD_PASSWORD=<admin_password>
AD_DOMAIN=TECHCORP
```

---

## 3. Exit Checklist Automation — How It Works

### Backend Auto-Completion Logic (engines/offboarding.py)

After each offboarding action, the system auto-marks matching checklist items:

| System Action Completed | Checklist Items Auto-Marked |
|---|---|
| RBAC: GitHub revoked | "GitHub organisation membership removed", "SSH keys removed", "Repo access revoked" |
| RBAC: AWS revoked | "AWS IAM keys deactivated" |
| RBAC: Jira revoked | "Jira account deactivated" |
| RBAC: Slack revoked | "Slack workspace access removed" |
| RBAC: VPN revoked | "VPN certificate revoked" |
| MS Graph: block_signin | "M365 sign-in blocked" |
| MS Graph: set_out_of_office | "Out-of-office auto-reply configured" |

### Items That Stay Manual (Physical/Verification Required)
- Laptop returned to IT desk
- ID card returned to reception
- Exit interview completed
- Personal files removed from company systems
- Security audit completed

### Frontend Real-Time Sync
The checklist tab polls `/api/offboard/{id}/checklist` every 8 seconds,
updating progress bar and auto-completion badges automatically.

### Alert Conditions
- Dashboard calls `/api/offboard/alerts` — returns employees where `status=disabled`
  but checklist has incomplete items
- High/Critical risk → Security team email sent immediately via Gmail
- Items pending >48h could be flagged (future: add `deadline` field to ExitChecklist)

---

## 4. Complete Enterprise Offboarding Activities

### A. Identity & Access
- [ ] Disable AD account
- [ ] Reset AD password to random
- [ ] Remove from all AD security + distribution groups
- [ ] Move to Disabled Users OU
- [ ] Clear all active sessions
- [ ] Block M365 sign-in
- [ ] Revoke all Microsoft tokens
- [ ] Remove MFA authentication methods
- [ ] Wipe Intune-managed devices
- [ ] Remove from Azure AD groups
- [ ] Revoke GitHub org membership + SSH keys
- [ ] Deactivate AWS IAM user (keys, console, groups)
- [ ] Deactivate Jira/Confluence user
- [ ] Remove Slack workspace access
- [ ] Revoke VPN certificates
- [ ] Remove Salesforce/CRM user license
- [ ] Revoke any API tokens or service account access

### B. Communication
- [ ] Set Outlook/Gmail out-of-office auto-reply
- [ ] Set email forwarding to manager (30 days)
- [ ] Remove from distribution lists / mailing groups
- [ ] Notify direct team of departure
- [ ] Notify external clients (sales roles)
- [ ] Update org chart and directory

### C. Asset Return
- [ ] Laptop collected + factory reset
- [ ] ID card / access badge deactivated
- [ ] Mobile phone (if company-issued) wiped and returned
- [ ] Physical office keys returned
- [ ] Parking permit cancelled

### D. Data Security
- [ ] Personal files removed from shared drives
- [ ] Company data not copied to personal storage (DLP check)
- [ ] Browser saved passwords cleared (if managed device)
- [ ] Code repositories reviewed for any personal secrets/keys
- [ ] Cloud storage (OneDrive/GDrive) access audit

### E. HR & Finance
- [ ] Final payroll processed
- [ ] Expense reports cleared
- [ ] Benefits cancellation initiated
- [ ] PF/gratuity processing started
- [ ] NDA reminder issued
- [ ] Non-compete clause acknowledged
- [ ] Reference letter (if applicable)

### F. Security Audit
- [ ] Last 30 days of audit logs reviewed
- [ ] DLP alerts resolved
- [ ] No suspicious large downloads in final week
- [ ] Privileged actions audited
- [ ] Any USB/external storage events reviewed

---

## 5. Additional Improvements for Production

1. **Deadline tracking** — Add `due_date` to ExitChecklist; alert if physical items
   (laptop, badge) not returned within 48 hours of last day
2. **Manager notification** — Email direct manager when offboarding is triggered
3. **Parallel execution** — For high-risk: run all system revocations concurrently
   (ThreadPoolExecutor) instead of sequentially
4. **Offboarding SLA** — Define max time per checklist item; auto-escalate if missed
5. **Self-service portal** — Employee can view their own exit checklist and status
6. **HRIS integration** — Sync termination date from Workday/BambooHR/SuccessFactors
7. **Legal hold** — Flag email archive for legal review before deletion
8. **Device encryption check** — Verify device was encrypted before wiping

---

## 6. Automation Feasibility

### What CAN Be Automated (with dummy data today)
✅ AD simulation (already done)
✅ RBAC revocation (already done)
✅ Exit checklist auto-generation (already done)
✅ Email notification (real Gmail already working)
✅ Audit trail (already done)
✅ Risk scoring (Groq LLM, already done)

### What NEEDS Real Infrastructure
| Integration | Requires | Status |
|---|---|---|
| Real AD | Windows DC + WinRM | Simulate only |
| Real M365 | Azure App + admin consent | Toggle: USE_REAL_GRAPH=true |
| Real GitHub | GitHub token + org admin | Future |
| Real AWS | AWS IAM admin credentials | Future |
| Real Jira | Jira API token + admin | Future |
| PostgreSQL | DB server | Toggle: change DATABASE_URL |

### Architecture for Scale
```
HR Trigger → FastAPI → LangGraph Orchestrator
                          ├── RiskAnalyzerAgent  (Groq LLM)
                          ├── ADAgent            (pywinrm)
                          ├── GraphAgent         (MS Graph SDK)
                          ├── RBACAgent          (per-system APIs)
                          └── AuditAgent         (DB + Sheets + PDF)
```

---

## 7. AI Enhancements

### Implemented in v2
- **LLM Risk Scoring** (risk_analyzer.py) — Groq analyzes 10 behavioral signals,
  returns 0–100 risk score, level, recommended actions, plain-English summary
- **Offboarding Chatbot Commands** — "Offboard John Doe, last day 2025-06-30"
  executes the full pipeline from the AI Assistant chat

### Recommended Next Steps
- **Anomaly Detection** — Compare final-week behavior vs 90-day baseline using
  UEBA signals from Azure Sentinel workspace (you have the workspace credentials)
- **LangGraph Orchestrator** — Replace sequential offboarding with a stateful
  graph that handles failures, retries, and parallel execution
- **SIEM Integration** — Pull real behavioral signals from Azure Sentinel
  (SUBSCRIPTION_ID + WORKSPACE_NAME already in .env)
- **Predictive Offboarding** — Train model on historical patterns to flag
  employees likely to resign before they submit notice

---

## Database Recommendation

For your current stage: **Keep SQLite** (zero setup, sufficient for ≤50 concurrent users)

For production scale: **PostgreSQL on Azure**
```
DATABASE_URL=postgresql://user:pass@server.postgres.database.azure.com/hr_db?sslmode=require
```
Use Azure Database for PostgreSQL (Flexible Server) — integrates with your
existing Azure subscription (SUBSCRIPTION_ID=963819ff-...).

Migration: `alembic upgrade head` after adding `alembic` to requirements.txt
and generating initial migration from existing models.
