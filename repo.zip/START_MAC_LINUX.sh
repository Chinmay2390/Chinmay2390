#!/bin/bash
echo "============================================"
echo " HR Onboarding System — Startup Script"
echo "============================================"

# Backend setup
echo "[1/4] Setting up Python virtual environment..."
cd backend
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate

echo "[2/4] Installing Python dependencies..."
pip install -r requirements.txt -q

echo "[3/4] Starting Backend on port 8000..."
uvicorn main:app --reload --port 8000 &
BACKEND_PID=$!
echo "Backend PID: $BACKEND_PID"

# Frontend setup
echo "[4/4] Setting up and starting Frontend..."
cd ../frontend
if [ ! -d "node_modules" ]; then
    echo "Installing npm packages (first time only)..."
    npm install
fi
npm run dev &
FRONTEND_PID=$!

echo ""
echo "============================================"
echo " STARTED SUCCESSFULLY"
echo "============================================"
echo " Backend:  http://localhost:8000"
echo " API Docs: http://localhost:8000/docs"
echo " Frontend: http://localhost:5173"
echo "============================================"
echo ""
echo "Press Ctrl+C to stop all servers"

# Wait and cleanup on exit
trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit" INT
wait
