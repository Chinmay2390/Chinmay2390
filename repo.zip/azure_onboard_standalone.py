#!/usr/bin/env python3
"""
azure_onboard_standalone.py
===========================
Standalone script to onboard a user into Azure AD.
Does NOT need the FastAPI backend or database to be running.

Usage:
  python azure_onboard_standalone.py                  # demo mode (simulated)
  python azure_onboard_standalone.py --real           # real Azure AD calls
  python azure_onboard_standalone.py --real --test    # just test the connection

Setup:
  1. pip install python-dotenv
  2. Set your credentials in backend/.env (or export as env vars)
  3. Set USE_REAL_GRAPH=true in .env to make real API calls

Required .env keys:
  AZURE_TENANT_ID      = b6c82010-f7aa-4640-9dfd-8e3177758cd9
  AZURE_CLIENT_ID      = f48cd7fd-6763-49ef-8c1b-04bebae83745
  AZURE_CLIENT_SECRET  = VP38Q~...
  AZURE_TENANT_DOMAIN  = yourtenant.onmicrosoft.com
  USE_REAL_GRAPH       = true   (or false for simulation)
"""
import os, sys, json, argparse
from pathlib import Path

# ── Load .env from backend/ ────────────────────────────────────
env_path = Path(__file__).parent / "backend" / ".env"
if env_path.exists():
    from dotenv import load_dotenv
    load_dotenv(env_path)
    print(f"✅ Loaded .env from {env_path}")
else:
    print(f"⚠️  .env not found at {env_path} — using environment variables")

# ── CLI args ───────────────────────────────────────────────────
parser = argparse.ArgumentParser(description="Azure AD Onboarding CLI")
parser.add_argument("--real",   action="store_true", help="Use real Azure AD (USE_REAL_GRAPH=true)")
parser.add_argument("--test",   action="store_true", help="Only test connection, don't create user")
parser.add_argument("--name",   default="Alice Johnson",    help="Full name")
parser.add_argument("--email",  default="",                 help="Email (auto-generated if blank)")
parser.add_argument("--dept",   default="Engineering",      help="Department")
parser.add_argument("--role",   default="developer",        help="Role: admin/developer/hr_manager/finance/sales/intern")
parser.add_argument("--manager",default="TBD",              help="Manager display name in Azure AD")
parser.add_argument("--phone",  default="",                 help="Mobile phone")
args = parser.parse_args()

# Override USE_REAL_GRAPH from CLI
if args.real:
    os.environ["USE_REAL_GRAPH"] = "true"

# Validate credentials if real mode
USE_REAL = os.getenv("USE_REAL_GRAPH", "false").lower() == "true"
TENANT   = os.getenv("AZURE_TENANT_ID", "")
CLIENT   = os.getenv("AZURE_CLIENT_ID", "")
SECRET   = os.getenv("AZURE_CLIENT_SECRET", "")
DOMAIN   = os.getenv("AZURE_TENANT_DOMAIN", "")

print("\n" + "="*60)
print("  Azure AD Automated Onboarding System")
print("="*60)
print(f"  Mode:          {'🔴 REAL Azure AD calls' if USE_REAL else '🟡 SIMULATED (safe demo)'}")
print(f"  Tenant ID:     {TENANT[:8]}..." if TENANT else "  Tenant ID:     ❌ NOT SET")
print(f"  Client ID:     {CLIENT[:8]}..." if CLIENT else "  Client ID:     ❌ NOT SET")
print(f"  Tenant Domain: {DOMAIN}" if DOMAIN else "  Tenant Domain: ❌ NOT SET (set AZURE_TENANT_DOMAIN)")
print("="*60)

if USE_REAL and (not TENANT or not CLIENT or not SECRET):
    print("\n❌ Missing Azure credentials. Set in backend/.env:")
    print("   AZURE_TENANT_ID=...")
    print("   AZURE_CLIENT_ID=...")
    print("   AZURE_CLIENT_SECRET=...")
    sys.exit(1)

# ── Add backend to path so we can import engines ───────────────
sys.path.insert(0, str(Path(__file__).parent / "backend"))

# ── Connection test ────────────────────────────────────────────
if args.test:
    print("\n🔍 Testing Azure AD connection...")
    if not USE_REAL:
        print("ℹ️  USE_REAL_GRAPH=false — pass --real to test real connection")
        sys.exit(0)
    try:
        from engines.microsoft_graph import _get_token
        token = _get_token()
        print(f"✅ Token acquired successfully!")
        print(f"   Token preview: {token[:30]}...")
        print("\n🔍 Listing first 5 users in tenant...")
        from engines.microsoft_graph import list_azure_users
        users = list_azure_users(5)
        for u in users:
            print(f"   • {u.get('displayName'):30} {u.get('userPrincipalName')}")
        print("\n✅ Azure AD connection is fully working!")
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        print("\nCommon fixes:")
        print("  1. Check AZURE_CLIENT_SECRET hasn't expired in Azure Portal")
        print("  2. Verify API permissions have admin consent granted")
        print("  3. Confirm AZURE_TENANT_ID and AZURE_CLIENT_ID are correct")
    sys.exit(0)

# ── Onboarding ─────────────────────────────────────────────────
print(f"\n👤 Onboarding: {args.name}")
print(f"   Department:  {args.dept}")
print(f"   Role:        {args.role}")
print(f"   Manager:     {args.manager}")
print()

from engines.microsoft_graph import run_full_ad_onboarding

try:
    result = run_full_ad_onboarding(
        name=args.name,
        email=args.email or "",
        department=args.dept,
        role=args.role,
        manager=args.manager,
        phone=args.phone,
    )
except Exception as e:
    print(f"❌ Error: {e}")
    sys.exit(1)

# ── Print results ──────────────────────────────────────────────
print("─"*60)
print(f"  Status:           {result.get('status','?').upper()}")
print(f"  Azure Object ID:  {result.get('azure_object_id', 'N/A')}")
print(f"  UPN (login):      {result.get('upn', 'N/A')}")
print(f"  Temp Password:    {result.get('temp_password', 'N/A')}")
print(f"  Steps completed:  {result.get('completed', 0)}")
print(f"  Failed steps:     {result.get('failed_count', 0)}")
print(f"  Real API calls:   {result.get('real', False)}")
print("─"*60)

print("\n📋 Step-by-step results:")
for step in result.get("steps", []):
    icon = "✅" if step["status"] == "success" else "❌"
    name = step.get("step", "?").replace("_", " ").title()
    msg  = step.get("message") or step.get("error", "")
    real = " [REAL]" if step.get("real") else " [SIM]"
    print(f"  {icon} {name:25}{real}  {msg}")

if result.get("status") == "success":
    print(f"""
╔══════════════════════════════════════════════════════╗
  ✅ ONBOARDING COMPLETE

  The user has been created in Azure AD.

  Next steps for the new employee:
  1. Log in at: https://myapps.microsoft.com
  2. Use UPN:   {result.get('upn', 'N/A')}
  3. Temp PW:   {result.get('temp_password', 'N/A')}  (must change on first login)

  Check in Azure Portal:
  → Azure Active Directory → Users → {args.name}
╚══════════════════════════════════════════════════════╝""")
elif result.get("failed_count", 0) > 0:
    print(f"\n⚠️  Onboarding completed with {result.get('failed_count')} failed step(s).")
    print("   Check Azure Portal to verify user was created and fix manually if needed.")

# Save result to JSON
out = Path("azure_onboard_result.json")
out.write_text(json.dumps(result, indent=2, default=str))
print(f"\n💾 Full result saved to: {out.resolve()}")
